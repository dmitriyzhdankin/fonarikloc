<?php

return array(
    'code' => 'MDL',
    'sign' => 'leu',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Moldovan leu',
    'name' => array(
        array('leu', 'lei'),
    ),
    'frac_name' => array(
        array('ban', 'bani'),
    )
);