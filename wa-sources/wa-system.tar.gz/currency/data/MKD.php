<?php

return array(
    'code' => 'MKD',
    'sign' => 'ден',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Macedonian denar',
    'name' => array(
        array('denar', 'denari'),
    ),
    'frac_name' => array(
        'deni',
    )
);