<?php

return array(
    'code' => 'UAH',
    'sign' => 'грн.',
    'title' => 'Ukrainian hryvnia',
    'name' => array(
        array('hryvnia', 'hryvnias'),
        'hrn',
    ),
    'frac_name' => array(
        array('kopiyka', 'kopiykas'),
    )
);