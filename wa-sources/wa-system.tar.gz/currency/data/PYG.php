<?php

return array(
    'code' => 'PYG',
    'sign' => '₲',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Paraguayan guarani',
    'name' => array(
        array('guarani', 'guaranies'),
    ),
    'frac_name' => array(
    )
);