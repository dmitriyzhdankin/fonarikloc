<?php 

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'icon' => 'img/webasyst.gif',
    'analytics' => true,
    'version' => '1.2.2',
    'critical'=>'1.2.0',
    'vendor' => 'webasyst',
);
