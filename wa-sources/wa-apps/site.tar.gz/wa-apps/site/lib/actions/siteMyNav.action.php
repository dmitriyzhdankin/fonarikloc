<?php

class siteMyNavAction extends waMyNavAction
{
}