<?php
return array(
	'app.installer'=>array(
		'version'=>'latest',
		'strict' => true
	),
);
//EOF