<?php

class shopProductsDeleteListController extends waJsonController
{
    public function execute()
    {
        $this->getStorage()->close();

        $hash = waRequest::post('hash');
        if ($hash) {
            $remove = waRequest::post('remove', array());
            if (count($remove) == 1 && $remove[0] == 'list') {
                if ($model = $this->getModel($hash[0])) {
                    $model->delete($hash[1]);
                }
            } else {
                $count = waRequest::post('count', null, waRequest::TYPE_INT);
                $this->delete($hash, $count, count($remove) == 2);
            }
        } else {
            $this->deleteProducts(waRequest::post('product_id', array(), waRequest::TYPE_ARRAY_INT));
            if (waRequest::post('get_lists')) {
                $this->response['lists'] = $this->getLists();
            }
        }
    }

    private function delete($hash, $count, $del_list = false) {
        $collection = new shopProductsCollection(implode('/', $hash));
        if ($count) {
            $product_ids = array_keys($collection->getProducts('id', 0, $count, false));
            $this->deleteProducts($product_ids);
        }
        $rest_count = $collection->count();
        $this->response['rest_count'] = $rest_count;
        $this->response['count'] = $count;
        if ($rest_count == 0) {
            $this->response['lists'] = $this->getLists();
            if ($del_list && $model = $this->getModel($hash[0])) {
                return $model->delete($hash[1]);
            }
        }
        return true;
    }

    public function deleteProducts(array $product_ids)
    {
        if ($product_ids) {
            $product_model = new shopProductModel();
            return $product_model->delete($product_ids);
        }
        return false;
    }

    public function getModel($type)
    {
        static $model = array();
        if (!isset($model[$type])) {
            if ($type == 'category') {
                $model[$type] = new shopCategoryModel();
            } else if ($type == 'set') {
                $model[$type] = new shopSetModel();
            } else {
                $model[$type] = null;
            }
        }
        return $model[$type];
    }

    public function getProductsModel($type)
    {
        static $model = array();
        if (!isset($model[$type])) {
            if ($type == 'category') {
                $model[$type] = new shopCategoryProductsModel();
            } else if ($type == 'set') {
                $model[$type] = new shopSetProductsModel();
            } else {
                $model[$type] = null;
            }
        }
        return $model[$type];
    }

    public function getLists()
    {
        $category_model = $this->getModel('category');
        $set_model = $this->getModel('set');
        return array(
            'category' => $category_model->getAll('id'),
            'set' => $set_model->getAll('id')
        );
    }
}