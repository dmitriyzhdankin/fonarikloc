<?php

class shopProductsDeleteListFromSetController extends waJsonController
{
    public function execute()
    {
        $model = new shopSetProductsModel();
        $hash = waRequest::post('hash');
        if ($hash) {
            $model->clearSet(waRequest::get('id'));
        } else {
            $model->deleteProducts(
                waRequest::get('id'),
                waRequest::post('product_id', array(), waRequest::TYPE_ARRAY_INT)
            );
        }
    }
}