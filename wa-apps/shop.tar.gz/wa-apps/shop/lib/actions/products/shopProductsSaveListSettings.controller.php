<?php

class shopProductsSaveListSettingsController extends waJsonController
{
    private $model;

    public function execute()
    {
        $hash = $this->getHash();        // hash that identify 'destination' list (settings of which is changing)
        if (!$hash) {
            throw new waException("Unknown type of list");
        }
        $data = $this->getData($hash[0]);
        $id = $this->saveSettings($hash, $data);

        if ($id) {
            if ($hash[0] == 'set') {    // now supported for sets only
                $this->addProducts($id, $hash[0]);
            }
            $this->response = $this->getModel($hash[0])->getById($id);
            $this->response['name'] = htmlspecialchars($this->response['name']);
        }
    }

    private function saveSettings($hash, &$data)
    {
        if ($hash[0] == 'category') {
            if (isset($data['id'])) {
                unset($data['id']);
            }
            return $this->saveCategorySettings((int)$hash[1], $data);
        }
        if ($hash[0] == 'set') {
            return $this->saveSetSettings($hash[1], $data);
        }
    }

    private function saveCategorySettings($id, &$data)
    {
        $this->model = new shopCategoryModel();
        if (!$id) {
            if (empty($data['url'])) {
                $url = shopHelper::transliterate($data['name'], false);
                if ($url) {
                    $data['url'] = $this->model->suggestUniqueUrl($url);
                }
            } else {
                $data['url'] = $this->model->suggestUniqueUrl($data['url']);
            }
            if (empty($data['name'])) {
                $data['name'] = _w('(no-name)');
            }
            $id = $this->model->add($data, $data['parent_id']);
        } else {
            $category = $this->model->getById($id);
            if (!$this->categorySettingsValidate($category, $data)) {
                return false;
            }
            if (empty($data['name'])) {
                $data['name'] = $category['name'];
            }
            if (empty($data['url'])) {
                $data['url'] = $this->model->suggestUniqueUrl(shopHelper::transliterate($data['name']), $id, $category['parent_id']);
            }
            unset($data['parent_id']);
            $data['edit_datetime'] = date('Y-m-d H:i:s');
            $this->model->update($id, $data);
        }
        if ($id) {
            $category_params_model = new shopCategoryParamsModel();
            $category_params_model->set($id, !empty($data['params']) ? $data['params'] : null);
        }
        return $id;

    }

    private function categorySettingsValidate($category, $data)
    {
        if (!empty($data['url'])) {
            if ($this->model->urlExists($data['url'], $category['id'], $category['parent_id'])) {
                $this->errors['url'] = _w('Url is in use');
            }
        }
        return empty($this->errors);
    }

    private function saveSetSettings($id, &$data)
    {
        $this->model = new shopSetModel();
        if (!$id) {
            if (empty($data['id'])) {
                $id = str_replace('-', '_', shopHelper::transliterate($data['name']));
                $data['id'] = $this->model->suggestUniqueId($id);
            } else {
                $data['id'] = $this->model->suggestUniqueId($data['id']);
            }
            if (!$this->setSettingsValidate(null, $data)) {
                return false;
            }
            if (empty($data['name'])) {
                $data['name'] = _w('(no-name)');
            }
            $id = $this->model->add($data);
        } else {
            $set = $this->model->getById($id);
            if (!$this->setSettingsValidate($set, $data)) {
                return false;
            }
            if (empty($data['name'])) {
                $data['name'] = $set['name'];
            }
            if (!empty($data['id'])) {
                $id = $data['id'];
            } else {
                $id = shopHelper::transliterate($data['name']);
                if ($id == $set['id']) {
                    $id = $set['id'];
                } else {
                    $id = $this->model->suggestUniqueId($id);
                }
            }
            $data['edit_datetime'] = date('Y-m-d H:i:s');
            $this->model->update($set['id'], $data);
        }
        return $id;
    }

    private function setSettingsValidate($set = null, $data)
    {
        if (!preg_match("/^[a-z0-9\._]+$/i", $data['id'])) {
            $this->errors['id'] = _w('Only latin characters, numbers and underscore symbol are allowed');
        } else if ($set) {
            if (!empty($data['id']) && $set['id'] != $data['id']) {
                if ($this->model->idExists($data['id'])) {
                    $this->errors['id'] = _w('ID is in use');
                }
            }
        }
        return empty($this->errors);
    }

    private function getModel($type)
    {
        static $model = array();
        if (!isset($model[$type])) {
            if ($type == 'category') {
                $model[$type] = new shopCategoryModel();
            } elseif ($type == 'set') {
                $model[$type] = new shopSetModel();
            } else {
                $model[$type] = null;
            }
        }
        return $model[$type];
    }

    private function getProductsModel($type)
    {
        static $model = array();
        if (!isset($model[$type])) {
            if ($type == 'category') {
                $model[$type] = new shopCategoryProductsModel();
            } elseif ($type == 'set') {
                $model[$type] = new shopSetProductsModel();
            } else {
                $model[$type] = null;
            }
        }
        return $model[$type];
    }

    private function addProducts($id, $type)
    {
        $model = $this->getProductsModel($type);
        $hash = waRequest::post('hash');    // hash of source list (which provides products)
        if (!$hash) {
            $product_ids = waRequest::post('product_id', array(), waRequest::TYPE_ARRAY_INT);
            if (!$product_ids) {
                return;
            }
            $model->add($product_ids, $id);
        } else {
            $collection = new shopProductsCollection(implode('/', $hash));
            $offset = 0;
            $count = 100;
            $total_count = $collection->count();
            while ($offset < $total_count) {
                $product_ids = array_keys($collection->getProducts('*', $offset, $count));
                $model->add($product_ids, $id);
                $offset += count($product_ids);
            }
        }
    }

    private function getHash()
    {
        $category_id = waRequest::get('category_id', null, waRequest::TYPE_INT);
        if ($category_id !== null) {
            return array('category', $category_id);
        }
        $set_id = waRequest::get('set_id', null, waRequest::TYPE_STRING_TRIM);
        if ($set_id !== null) {
            return array('set', $set_id);
        }
        return null;
    }

    private function getData($list_type)
    {
        $type = waRequest::post('type', 0, waRequest::TYPE_INT);
        $data = array(
            'name' => waRequest::post('name', '', waRequest::TYPE_STRING_TRIM),
            'url' =>  waRequest::post('url', '', waRequest::TYPE_STRING_TRIM),
            'description' => waRequest::post('description', '', waRequest::TYPE_STRING_TRIM),
            'meta_title' => waRequest::post('meta_title', '', waRequest::TYPE_STRING_TRIM),
            'meta_keywords' => waRequest::post('meta_keywords', '', waRequest::TYPE_STRING_TRIM),
            'meta_description' => waRequest::post('meta_description', '', waRequest::TYPE_STRING_TRIM),
            'params' => waRequest::post('params', '', waRequest::TYPE_STRING_TRIM),
            'parent_id' => waRequest::get('parent_id', 0, waRequest::TYPE_INT),
            'type' => $type
        );
        $params = array();
        if (!empty($data['params'])) {
            foreach (explode("\n", $data['params']) as $param_str) {
                $param = explode('=', $param_str);
                if (count($param) > 1) {
                    $params[$param[0]] = trim($param[1]);
                }
            }
        }
        $data['params'] = $params;

        if ($list_type == 'category') {
            $data['filter'] = $this->getFilter();
            if ($type == shopCategoryModel::TYPE_DYNAMIC) {
               $data['conditions'] = $this->getConditions();
            }
            $data['sort_products'] = waRequest::post('sort_products', null, waRequest::TYPE_STRING_TRIM);
            $data['sort_products'] = !empty($data['sort_products']) ? $data['sort_products'] : null;
        }

        if ($list_type == 'set') {
            $data['id'] = waRequest::post('id', null, waRequest::TYPE_STRING_TRIM);
            if ($type == shopSetModel::TYPE_DYNAMIC) {
                $data['rule']  = waRequest::post('rule', null, waRequest::TYPE_STRING);
                $data['rule'] = !empty($data['rule']) ? $data['rule'] : null;
                $data['count'] = waRequest::post('count', 100, waRequest::TYPE_INT);
            }
        }
        return $data;
    }

    private function getFilter()
    {
        $filter = array();
        if (waRequest::post('allow_filter')) {
            foreach (waRequest::post('filter', array()) as $value) {
                $filter[] = trim($value);
            }
        }
        return !empty($filter) ? implode(',', $filter) : null;
    }

    private function getConditions()
    {
        $raw_condition = waRequest::post('condition');
        $raw_condition = array_fill_keys((array)$raw_condition, false);

        $conditions = array();
        if (isset($raw_condition['rate'])) {
            $raw_condition['rate'] = waRequest::post('rate');
            $conditions[] = 'rate' . $raw_condition['rate'][0] . $raw_condition['rate'][1];
        }
        if (isset($raw_condition['tag'])) {
            $tags = (array)waRequest::post('tag', array());
            if (!empty($tags)) {
                $conditions[] = 'tag=' . implode('||', $tags);
            }
        }
        $conditions = implode('&', $conditions);
        return $conditions;
    }
}