<?php

class shopProductPageEditAction extends waViewAction
{
    private $model;

    public function execute()
    {
        $product_id = waRequest::get('product_id', null, waRequest::TYPE_INT);
        if (!$product_id) {
            throw new waException(_w("Unknown product"));
        }
        $id = waRequest::get('id', null, waRequest::TYPE_INT);
        $page = $this->getPage($id);
        $this->view->assign(array(
            'url' => !empty($page['url']) ? wa()->getRouteUrl('', array(), true) : '',
            'preview_hash' => $this->getPreviewHash(),
            'page' => $page,
            'lang' => substr(wa()->getLocale(), 0, 2),
            'product_id' => $product_id
        ));
    }

    private function getPage($id)
    {
        $page = null;
        if ($id) {
            $model = new shopProductPagesModel();
            $page = $model->get($id);
        }
        return $page ? $page : array();
    }

    protected function getPreviewHash()
    {
        $hash = $this->appSettings('preview_hash');
        if ($hash) {
            $hash_parts = explode('.', $hash);
            if (time() - $hash_parts[1] > 14400) {
                $hash = '';
            }
        }
        if (!$hash) {
            $hash = uniqid().'.'.time();
            $app_settings_model = new waAppSettingsModel();
            $app_settings_model->set($this->getAppId(), 'preview_hash', $hash);
        }

        return md5($hash);
    }
}