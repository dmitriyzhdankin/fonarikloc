<?php

class shopProductImageSetBadgeController extends waJsonController
{
    public function execute()
    {
        $image_id = waRequest::get('id', null, waRequest::TYPE_INT);
        if (!$image_id) {
            $this->errors[] = _w("Unknown image");
            return;
        }
        $type = waRequest::post('type', null, waRequest::TYPE_INT);
        if ($type === null) {
            $this->errors[] = _w("Unknown type");
            return;
        }

        $data = array();

        if (shopProductImagesModel::isCustomBadgeType($type)) {
            $code = waRequest::post('code');
            if (!$code) {
                $this->errors[] = _w("Empty code");
                return;
            }
            $product_image_model = new shopProductImagesModel();
            $data = array('badge_type' => $type, 'badge_code' => $code);
            if (!$product_image_model->updateById($image_id, $data)) {
                $this->errors[] = _w("Error when updating");
            }
        } else {
            $product_image_model = new shopProductImagesModel();
            $data = array('badge_type' => $type, 'badge_code' => null);
            if (!$product_image_model->updateById($image_id, $data)) {
                $this->errors[] = _w("Error when updating");
            }
        }

        $this->response = array(
            'type' => $type,
            'code' => shopHelper::getImageBadgeHtml($data)
        );
    }
}