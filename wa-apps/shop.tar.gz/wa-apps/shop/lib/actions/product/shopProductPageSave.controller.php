<?php

class shopProductPageSaveController extends waJsonController
{
    private $param_names = array('description', 'keywords');
    public function execute()
    {
        $id = waRequest::get('id', null, waRequest::TYPE_INT);
        $product_pages_model = new shopProductPagesModel();

        $data = $this->getData($id);
        if ($id) {
            if (!$product_pages_model->update($id, $data)) {
                $this->errors[] = _w('Error saving product page');
                return;
            }
        } else {
            $id = $product_pages_model->add($data);
            if (!$id) {
                $this->errors[] = _w('Error saving product page');
                return;
            }
        }
        $data['id'] = $id;
        $data['name'] = htmlspecialchars($data['name']);
        $this->response = $data;
    }

    public function getData($id)
    {
        $data = waRequest::post('info');
        if (!$id) {
            $product_id = waRequest::get('product_id', null, waRequest::TYPE_INT);
            if (!$product_id) {
                throw new waException(_w("Unknown product"));
            }
            $data['product_id'] = $product_id;
        }
        $data['url'] = trim($data['url'], '/');
        if (!$id && !$data['url']) {
            $data['url'] = shopHelper::transliterate($data['name']);
        }
        if (empty($data['name'])) {
            $data['name'] = '('._ws('no-title').')';
        }
        $data['status'] = isset($data['status']) ? 1 : 0;
        $data['params'] = $this->getParams();
        return $data;
    }

    public function getParams()
    {
        $params = array();
        foreach ((array)waRequest::post('params', array()) as $name => $value) {
            if ($value && in_array($name, $this->param_names)) {
                $params[$name] = $value;
            }
        }
        return $params;
    }
}