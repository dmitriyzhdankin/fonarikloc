<?php

class shopProductImageDeleteBadgeController extends waJsonController
{
    public function execute()
    {
        $image_id = waRequest::get('id', null, waRequest::TYPE_INT);
        if (!$image_id) {
            $this->errors[] = _w("Unknown image");
            return;
        }
        $product_image_model = new shopProductImagesModel();
        $product_image_model->updateById($image_id, array('badge_type' => null, 'badge_code' => null));
    }
}