<?php

class shopStocksAction extends waViewAction
{
    public function execute()
    {
        $offset = waRequest::get('offset', 0, waRequest::TYPE_INT);
        $total_count = waRequest::get('total_count', 0, waRequest::TYPE_INT);
        $order = waRequest::get('order', 'desc') == 'desc' ? 'desc' : 'asc';

        $product_model = new shopProductModel();
        if (!$total_count) {
            $total_count = $product_model->countProductStocks();
        }

        $data = $product_model->getProductStocks($offset, $this->getConfig()->getOption('products_per_page'), $order);
        $count = count($data);
        if ($offset === 0) {
            $stock_model = new shopStockModel();
            $this->response(array(
                'product_stocks' => $data,
                'total_count' => $total_count,
                'count' => $count,
                'stocks' => $stock_model->getAll(),
                'order' => $order
            ));
        } else {
            $product_model = new shopProductModel();
            $this->response(array(
                'product_stocks' => $data,
                'total_count' => $total_count,
                'count' => $count,
                'order' => $order,
                'progress' => array(
                    'loaded' => _w('%d product','%d products', $offset + $count),
                    'of' => sprintf(_w('of %d'), $total_count),
                    'chunk' => _w('%d product','%d products', max(0, min($total_count - ($offset + $count), $count))),
                )
            ), true);
        }
    }

    public function response($data, $json = false) {
        if (!$json) {
            $this->view->assign($data);
        } else {
            echo json_encode(array('status' => 'ok', 'data' => $data)); exit;
        }
    }
}