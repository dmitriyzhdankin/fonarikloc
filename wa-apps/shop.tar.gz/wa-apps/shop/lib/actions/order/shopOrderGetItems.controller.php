<?php

class shopOrderGetItemsController extends waJsonController
{
    /**
     * @var shopOrderItemsModel
     */
    private $model;

    public function execute()
    {
        $id = waRequest::get('id', 0, waRequest::TYPE_INT);
        if (!$id) {
            $this->errors[] = _w("Unknow order");
            return;
        }
        if ($id) {
            $data = $this->getModel()->getItems($id, true);
            foreach ($data as &$item) {
                $this->workup($item);
            }
            $this->response = $data;
        }
    }

    public function workup(&$product)
    {
        if (empty($product['image_id'])) {
            $product['url_crop_small'] = null;
        } else {
            $product['url_crop_small'] = shopImage::getUrl(
                array('id' => $product['image_id'], 'product_id' => $product['id'], 'ext' => $product['ext']),
                $this->getConfig()->getImageSize('crop_small')
            );
        }
    }

    public function getModel()
    {
        if (!$this->model) {
            $this->model = new shopOrderItemsModel();
        }
        return $this->model;
    }
}