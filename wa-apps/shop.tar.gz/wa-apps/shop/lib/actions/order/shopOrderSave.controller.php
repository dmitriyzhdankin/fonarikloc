<?php

class shopOrderSaveController extends waJsonController
{
    private $models = array();

    public function execute()
    {
        $id = waRequest::get('id', null, waRequest::TYPE_INT);
        $customer_id = waRequest::post('customer_id', null, waRequest::TYPE_INT);
        $contact = new waContact($customer_id);

        $form = shopHelper::getCustomerForm($customer_id);
        if (!$form->isValid($contact)) {
            $this->errors['customer']['html'] = $form->html();
        }

        $data = $this->getData($id);
        $data['tax'] = 0;

        if (!$data) {
            $this->errors['order'] = _w('There is not one product for order');
        }
        if ($this->errors) {
            return ;
        }

        foreach($form->post() as $fld_id => $fld_data) {
            if (!$fld_data) {
                continue;
            }
            if (is_array($fld_data) && !empty($fld_data[0])) {
                foreach($fld_data as $v) {
                    $contact[$fld_id] = $v;
                }
            } else {
                $contact[$fld_id] = $fld_data;
            }
        }

        if ($errors = $contact->save(array(), true)) { // !!! FIXME: when this returns an error, JS fails to show it
            $this->errors['customer'] = $errors;
            return;
        }

        $workflow = new shopWorkflow();
        $data['contact'] = $contact;

        $this->getParams($data);

        if (!$id) {
            $id = $workflow->getActionById('create')->run($data);
        } else {
            $data['id'] = $id;
            $workflow->getActionById('edit')->run($data);
        }

        $this->response['order'] = $this->workupOrder($this->getModel()->getOrder($id));
    }

    private function getParams(&$data)
    {
        // shipping
        if ($shipping_id = waRequest::post('shipping_id')) {
            list($shipping_id, $rate_id) = explode('.', $shipping_id);
            $data['params']['shipping_id'] = $shipping_id;
            $data['params']['shipping_rate_id'] = $rate_id;
            $plugin = shopShipping::getPlugin(null, $shipping_id);
            $rates = $plugin->getRates(array());
            $rate = $rates[$rate_id];
            $data['params']['shipping_plugin'] = $plugin->getId();
            $data['params']['shipping_name'] = $plugin->getName().(!empty($rate['name']) ? ' ('.$rate['name'].')' : '');
            $data['params']['shipping_est_delivery'] = $rate['est_delivery'];
        }
        // payment
        if ($payment_id = waRequest::post('payment_id')) {
            $data['params']['payment_id'] = $payment_id;
            $plugin = shopPayment::getPlugin(null, $payment_id);
            $data['params']['payment_plugin'] = $plugin->getId();
            $data['params']['payment_name'] = $plugin->getName();
        }
        // shipping and billing addreses
        foreach (array('shipping', 'billing') as $ext) {
            $address = $data['contact']->getFirst('address.'.$ext);
            if (!$address) {
                $address = $data['contact']->getFirst('address');
            }
            foreach ($address['data'] as $k => $v) {
                $data['params'][$ext.'_address.'.$k] = $v;
            }
        }
    }

    private function getData($id)
    {
        return $id ? $this->_getEditData() : $this->_getAddData();
    }

    private function _getEditData()
    {

        $items = waRequest::post('item', array());
        $products = waRequest::post('product', array());
        $skus = waRequest::post('sku', array());
        $services = waRequest::post('service', array());
        $variants = waRequest::post('variant', array());
        $names = waRequest::post('name', array());
        $prices = waRequest::post('price', array());
        $quantities = waRequest::post('quantity', array());

        $product_ids = array();
        $sku_ids = array();
        $service_ids = array();
        $variant_ids = array();

        $data = array(
            'items' => array()
        );
        $data['shipping'] = waRequest::post('shipping', 0);
        $data['discount'] = waRequest::post('discount', 0);
        foreach ($items as $index => $item_id) {
            $product_ids[] = $products[$item_id];
            $sku_ids[] = $skus[$item_id];

            $data['items'][] = array(
                'id' => $item_id,
                'product_id' => $products[$item_id],
                'sku_id' => $skus[$item_id],
                'service_id' => null,
                'service_variant_id' => null,
                'price' => $prices[$item_id],
                'quantity' => $quantities[$item_id]
            );

            if (!empty($services[$index])) {
                foreach ($services[$index] as $group => $services_grouped) {
                    foreach ($services_grouped as $k => $service_id) {
                        $service_ids[] = $service_id;
                        $pitem = &$data['items'][];
                        $pitem = array(
                            'product_id' => $products[$item_id],
                            'sku_id' => $skus[$item_id],
                            'service_id' => $service_id,
                            'price' => $prices[$group][$k],
                            'quantity' => $quantities[$group][$k],
                            'service_variant_id' => null
                        );
                        if ($group == 'item') {        // it's item for update: $k is ID of item
                            $pitem['id'] = $k;
                        } else {
                            $pitem['parent_id'] = $item_id;
                            $pitem['type'] = 'service';
                        }

                        if (!empty($variants[$index][$service_id])) {
                            $variant_ids[] = $variants[$index][$service_id];
                            $pitem['service_variant_id'] = $variants[$index][$service_id];
                        }
                        unset($pitems);
                    }
                }
            }
        }

        if ($product_ids) {
            $products = $this->getFields($product_ids, 'product');
            $skus = $this->getFields($sku_ids, 'product_skus');
            $services = $this->getFields($service_ids, 'service');
            $variants = $this->getFields($variant_ids, 'service_variants');

            foreach ($data['items'] as &$item) {
                // items with id mean for updating (old items)
                if (isset($item['id'])) {
                    if ($item['service_id']) {
                        if (isset($names[$item['id']])) {
                            $item['name'] = $names[$item['id']];
                        } else {
                            if ($item['service_variant_id']) {
                                $item['name'] = "{$services[$item['service_id']]['name']} ({$variants[$item['service_variant_id']]['name']})";
                            } else {
                                $item['name'] = "{$services[$item['service_id']]['name']}";
                            }
                        }
                        continue;
                    }

                    if (isset($names[$item['id']])) {
                        $item['name'] = $names[$item['id']];
                    } else {
                        $item['name'] = $products[$item['product_id']]['name'];
                        if ($skus[$item['sku_id']]['name']) {
                            $item['name'] .= ' ('.$skus[$item['sku_id']]['name'].')';
                        }
                    }
                } else {
                    if ($item['service_id']) {
                        if ($item['service_variant_id']) {
                            $item['name'] = "{$services[$item['service_id']]['name']} ({$variants[$item['service_variant_id']]['name']})";
                        } else {
                            $item['name'] = "{$services[$item['service_id']]['name']}";
                        }
                    }
                }
                unset($item);
            }
        }

        //$data['total'] = $this->calcAmount($data);

        return $data;
    }

    private function _getAddData()
    {
        $products = waRequest::post('product', array());
        if (!$products) {
            return array();
        }

        $skus = waRequest::post('sku', array());
        $prices = waRequest::post('price', array());
        $quantities = waRequest::post('quantity', array());
        $services = waRequest::post('service', array());
        $variants = waRequest::post('variant', array());

        $currencies = $this->getCurrencies();
        $primary_currency = $this->getConfig()->getCurrency();

        $product_ids = array();
        $sku_ids = array();
        $service_ids = array();
        $variant_ids = array();

        $data = array(
            'currency' => $primary_currency,
            'rate' => 1,
            'items' => array()
        );

        foreach ($products as $index => $product_id) {
            $product_ids[] = (int)$product_id;

            $sku_id = $skus[$index];
            $sku_ids[] = (int)$sku_id;
            $data['items'][] = array(
                'name' => '',
                'product_id' => $product_id,
                'sku_id' => $sku_id,
                'type' => 'product',
                'service_id' => null,
                'price' => $prices[$index]['product'],
                'currency' => '',
                'quantity' => $quantities[$index]['product'],
                'service_variant_id' => null
            );
            if (!empty($services[$index])) {
                foreach ($services[$index] as $service_id) {
                    $service_ids[] = (int)$service_id;
                    $item = &$data['items'][];
                    $item = array(
                        'name' => '',
                        'product_id' => $product_id,
                        'sku_id' => $skus[$index],
                        'type' => 'service',
                        'service_id' => $service_id,
                        'price' => $prices[$index]['service'][$service_id],
                        'currency' => '',
                        'quantity' => $quantities[$index]['service'][$service_id],
                        'service_variant_id' => null
                    );
                    if (!empty($variants[$index][$service_id])) {
                        $variant_ids[] = (int)$variants[$index][$service_id];
                        $item['service_variant_id'] = $variants[$index][$service_id];
                    }
                    unset($item);
                }
            }
        }
        $data['shipping'] = waRequest::post('shipping', 0);
        $data['discount'] = waRequest::post('discount', 0);
        $data['total'] = $this->calcAmount($data);

        $products = $this->getFields($product_ids, 'product', 'name, currency');
        $skus = $this->getFields($sku_ids, 'product_skus');
        $services = $this->getFields($service_ids, 'service', 'name, currency');
        $variants = $this->getFields($variant_ids, 'service_variants');

        foreach ($data['items'] as &$item) {
            if ($item['service_id']) {
                $name = $services[$item['service_id']]['name'];
                if ($item['service_variant_id']) {
                    $name .= " ({$variants[$item['service_variant_id']]['name']})";
                }
                $currency = $services[$item['service_id']]['currency'];
            } else {
                $name = $products[$item['product_id']]['name'];
                if ($skus[$item['sku_id']]['name']) {
                    $name .= ' ('.$skus[$item['sku_id']]['name'].')';
                }
                $currency = $products[$item['product_id']]['currency'];
            }
            $item['name'] = $name;
            $item['currency'] = $currency;
            unset($item);
        }
        return $data;
    }

    public function calcAmount($data)
    {
        $total = 0;
        foreach ($data['items'] as $item) {
            $total += (float)$item['price']*(int)$item['quantity'];
        }
        // @todo: calc tax
        return $total - $data['discount'] + $data['shipping'];
    }

    public function getCustomerData()
    {
        return waRequest::post('customer');
    }

    public function getFields(array $ids, $model_name, $fields = 'name')
    {
        if (!$ids) {
            return array();
        }
        return $this->getModel($model_name)->select('id, '.$fields)->where("id IN (".implode(',', $ids).")")->fetchAll('id');
    }

    public function getCurrencies()
    {
        return $this->getModel('currency')->getCurrencies();
    }

    /**
     * @param string $name
     * @return shopOrderModel
     */
    public function getModel($name = 'order')
    {
        if (!isset($this->models[$name])) {
            if ($name == 'product') {
                $this->models[$name] = new shopProductModel();
            } else if ($name == 'product_skus') {
                $this->models[$name] = new shopProductSkusModel();
            } else if ($name == 'currency') {
                $this->models[$name] = new shopCurrencyModel();
            } else if ($name == 'order_items') {
                $this->models[$name] = new shopOrderItemsModel();
            } else if ($name == 'service') {
                $this->models[$name] = new shopServiceModel();
            } else if ($name == 'service_variants') {
                $this->models[$name] = new shopServiceVariantsModel();
            } else {
                $this->models[$name] = new shopOrderModel();
            }
        }
        return $this->models[$name];
    }

    public function workupOrder($order)
    {
        if (!empty($order['items'])) {
            foreach ($order['items'] as &$item) {
                $item['name'] = htmlspecialchars($item['name']);
                unset($item);
            }
        }
        $order['contact']['name'] = htmlspecialchars($order['contact']['name']);
        $orders = array($order);
        shopHelper::workupOrders($orders);
        return $orders[0];
    }
}
