<?php

class shopOrderAction extends waViewAction
{
    /**
     * Params of order-list context of order
     * @var array|null
     */
    private $filter_params;
    /**
     * @var shopOrderModel
     */
    private $model;

    public function execute()
    {
        $id = waRequest::get('id', null, waRequest::TYPE_INT);
        if (!$id) {
            throw new waException("Unknown order", 404);
        }
        $order = $this->getOrder($id);
        if (!$order) {
            $id = shopHelper::decodeOrderId($id);
            $order = $this->getOrder($id);
            if (!$order) {
                throw new waException("Unkown order", 404);
            }
        }

        $workflow = new shopWorkflow();
        $actions = $workflow->getStateById($order['state_id'])->getActions();
        $top_buttons = $buttons = array();
        foreach ($actions as $action) {
            /**
             * @var shopWorkflowAction $action
             */
            if ($action->getOption('top')) {
                $top_buttons[] = $action->getButton();
            } else {
                $buttons[] = $action->getButton();
            }
        }

        $config = $this->getConfig();

        $log_model = new shopOrderLogModel();
        $log = $log_model->getLog($order['id']);

        $plugins = $this->getConfig()->getPlugins();
        $printable_docs = array();
        foreach ($plugins as $id => $plugin) {
            if (!empty($plugin['printform'])) {
                $printable_docs[$id] =& $plugins[$id];
            }
        }

        $order_params_model = new shopOrderParamsModel();
        $params = $order_params_model->get($order['id']);

        $settings = wa('shop')->getConfig()->getCheckoutSettings();
        $form_fields = ifset($settings['contactinfo']['fields'], array());

        $formatter = new waContactAddressSeveralLinesFormatter();
        if (isset($form_fields['address.shipping'])) {
            $shipping_address = shopHelper::getOrderAddress($params, 'shipping');
            $shipping_address = $formatter->format(array('data' => $shipping_address));
            $shipping_address = $shipping_address['value'];
        } else {
            $shipping_address = null;
        }

        if (isset($form_fields['address.billing'])) {
            $billing_address = shopHelper::getOrderAddress($params, 'billing');
            $billing_address = $formatter->format(array('data' => $billing_address));
            $billing_address = $billing_address['value'];
        } else {
            $billing_address = null;
        }
        $this->view->assign(array(
            'currency'          => $config->getCurrency(),
            'order'             => $order,
            'params'            => $params,
            'log'               => $log,
            'top_buttons'       => $top_buttons,
            'buttons'           => $buttons,
            'filter_params'     => $this->getParams(),
            'filter_params_str' => $this->getParams(true),
            'count_new'         => $this->getModel()->getStateCounters('new'),
            'timeout'           => $config->getOption('orders_update_list'),
            'printable_docs'    => $printable_docs,
            'billing_address'   => $billing_address,
            'shipping_address'  => $shipping_address,
            'shipping_id'       => ifset($params['shipping_id'], '').'.'.ifset($params['shipping_rate_id'], ''),
        ));
    }

    public function getParams($str = false)
    {
        if ($this->filter_params === null) {
            $params = array();
            $state_id = waRequest::get('state_id', null);
            if ($state_id) {
                $params['state_id'] = $state_id;
            }
            $contact_id = waRequest::get('contact_id', null, waRequest::TYPE_INT);
            if ($contact_id) {
                $params['contact_id'] = $contact_id;
            }
            $this->filter_params = $params;
        }
        if (!$str) {
            return $this->filter_params;
        }
        $params_str = '';
        foreach ($this->filter_params as $p => $v) {
            $params_str .= '&'.$p.'='.$v;
        }
        return substr($params_str, 1);
    }

    /**
     * @return shopOrderModel
     */
    public function getModel()
    {
        if ($this->model === null) {
            $this->model = new shopOrderModel();
        }
        return $this->model;
    }

    public function getOrder($id)
    {
        $order = $this->getModel()->getOrder($id);
        if (!$order) {
            return false;
        }
        $workflow = new shopWorkflow();
        $order['state'] = $workflow->getStateById($order['state_id']);
        return shopHelper::workupOrders($order, true);

    }

    public function getProducts(array $product_ids)
    {
        $data = array();
        foreach ($product_ids as $id) {
            $data[$id] = $this->getProduct($id);
        }
        return $data;
    }

    public function getProduct($product_id)
    {
        $product = new shopProduct($product_id);
        $data = $product->getData();

        $data['price'] = (float) $data['price'];
        $data['max_price'] = (float) $data['max_price'];
        $data['min_price'] = (float) $data['min_price'];
        $data['skus'] = $product->skus;

        $sku_count = count($data['skus']);
        $data['services'] = $product_services_model->getProductServicesFullInfo($product_id, $sku_count > 1 ? $product->sku_id : null);
        if ($sku_count <= 1) {
            unset($data['skus']);
        }

        if (!$data['image_id']) {
            $data['url_crop_small'] = null;
        } else {
            $image = array(
                'id'         => $data['image_id'],
                'product_id' => $data['id'],
                'ext'        => $data['ext'],
            );
            $data['url_crop_small'] = shopImage::getUrl($image, $this->getConfig()->getImageSize('crop_small'));
        }

        return $data;
    }
}
