<?php

class shopOrdersAddAction extends waViewAction
{
    public function execute()
    {
        $this->view->assign('form', shopHelper::getCustomerForm());
    }
}

