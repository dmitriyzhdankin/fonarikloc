<?php

class shopOrdersGetProductController extends waJsonController
{
    /**
     * @var shopOrderItemsModel
     */
    private $model;

    public function execute()
    {
        $order_id = waRequest::get('order_id', 0, waRequest::TYPE_INT);
        if ($order_id) {
            $this->response = $this->getProducts($order_id);
            return;
        }

        $product_id = waRequest::get('product_id', 0, waRequest::TYPE_INT);
        if (!$product_id) {
            $this->errors[] = _w("Unknown product");
            return;
        }

        $sku_id = waRequest::get('sku_id', 0, waRequest::TYPE_INT);
        if ($sku_id) {
            $this->response = $this->getSku($sku_id);
        } else {
            $this->response = $this->getProduct($product_id);
        }
    }

    public function getProducts($order_id)
    {
        $products = $this->getModel()->getProducts($order_id);
        foreach ($products as &$product) {
            $this->workup($product);
        }
        return $products;
    }

    public function getProduct($product_id)
    {
        $product = $this->getModel()->getProduct($product_id);
        $this->workup($product);
        return $product;
    }

    public function workup(&$product)
    {
        if (!$product['image_id']) {
            $product['url_crop_small'] = null;
        } else {
            $product['url_crop_small'] = shopImage::getUrl(
                array('id' => $product['image_id'], 'product_id' => $product['id'], 'ext' => $product['ext']),
                $this->getConfig()->getImageSize('crop_small')
            );
        }
    }

    public function getSku($sku_id)
    {
        return $this->getModel()->getSku($sku_id);
    }

    /**
     * @return shopOrderItemsModel
     */
    public function getModel()
    {
        if (!$this->model) {
            $this->model = new shopOrderItemsModel();
        }
        return $this->model;
    }
}