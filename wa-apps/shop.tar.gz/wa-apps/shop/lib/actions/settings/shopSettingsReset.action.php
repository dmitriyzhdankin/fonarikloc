<?php
class shopSettingsResetAction extends waViewAction
{
    public function execute()
    {
        if (waRequest::post('reset')) {
            $confirm = waRequest::post('confirm');
            if ($confirm !== null) {
                $storage = $this->getStorage();
                if ($confirm == $storage->read('reset_confirm')) {
                    $storage->del('reset_confirm');
                    $this->reset();
                } else {
                    $this->view->assign('error', true);
                    $this->makeConfirm();
                }
            } else {
                $this->makeConfirm();
            }
        }
    }

    private function makeConfirm()
    {

        $confirm = 'YES '.substr(md5(time()), 0, 3);
        $this->getStorage()->write('reset_confirm', $confirm);
        $this->view->assign('confirm', $confirm);
    }

    private function reset()
    {
        //XXX hardcode
        $tables = array(
            'shop_page',
            'shop_page_params',

            'shop_category',
            'shop_category_params',
            'shop_category_products',
            'shop_product',
            'shop_product_features',
            'shop_product_images',
            'shop_product_pages',
            'shop_product_page_params',
            'shop_product_related',
            'shop_product_reviews',
            'shop_product_services',
            'shop_product_skus',
            'shop_product_stocks',
            'shop_product_tags',
            'shop_search_index',
            'shop_search_word',

            'shop_set',
            'shop_set_products',

            'shop_stock',

            'shop_feature',
            'shop_feature_values_dimension',
            'shop_feature_values_double',
            'shop_feature_values_text',
            'shop_feature_values_varchar',

            'shop_type',
            'shop_type_features',
            'shop_type_services',
            'shop_type_upselling',

            'shop_service',
            'shop_service_variants',

            'shop_currency',

            'shop_customer',
            'shop_cart_items',
            'shop_order',
            'shop_order_items',
            'shop_order_log',
            'shop_order_log_params',
            'shop_order_params',

            'shop_tax',
            'shop_tax_regions',
            'shop_tax_zip_codes',
        );
        $model = new waModel();
        foreach ($tables as $table) {
            $model->query(sprintf("TRUNCATE `%s`", $table));
        }
        $sqls = array();
        $sqls[] = 'UPDATE`shop_type` SET`count` = 0';
        $sqls[] = 'UPDATE`shop_set` SET`count` = 0';
        foreach ($sqls as $sql) {
            $model->query($sql);
        }
        $app_settings_model = new waAppSettingsModel();
        $settings = array('currency', 'use_product_currency');
        foreach ($settings as $setting) {
            $app_settings_model->del('shop', $setting);
        }

        $paths = array();

        $paths[] = wa()->getDataPath('products', false, 'shop');
        $paths[] = wa()->getDataPath('products', true, 'shop');

        foreach ($paths as $path) {
            waFiles::delete($path, true);
        }

        $path = wa()->getDataPath('products', true, 'shop');
        waFiles::write($path.'/thumb.php', '<?php
    $file = realpath(dirname(__FILE__)."/../../../../")."/wa-apps/shop/lib/config/data/thumb.php";

        if (file_exists($file)) {
            include($file);
        } else {
            header("HTTP/1.0 404 Not Found");
        }
        ');
        waFiles::copy($this->getConfig()->getAppPath('lib/config/data/.htaccess'), $path.'/.htaccess');
        echo json_encode(array('result' => 'ok', 'redirect' => '?action=welcome'));
        exit;
    }
}
