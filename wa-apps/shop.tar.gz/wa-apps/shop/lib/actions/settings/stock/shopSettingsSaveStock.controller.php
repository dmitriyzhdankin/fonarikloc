<?php

class shopSettingsSaveStockController extends waJsonController
{
    public function execute()
    {
        $model = new shopStockModel();
        foreach ($this->getEditData() as $id => $item) {
            $model->updateById($id, $item);
        }

        foreach ($this->getAddData() as $before_id => $data) {
            $model->add($data, $before_id);
        }
    }

    public function getEditData()
    {
        $data = array();
        $ids = array();
        foreach (waRequest::post('edit', array()) as $name => $items) {
            foreach ($items as $k => $value) {
                if ($name == 'id') {
                    $ids[$k] = (int)$value;
                } else {
                    $data[$k][$name] = $value;
                }
            }
        }
        if (!empty($data)) {
            $data = array_combine($ids, $data);
        }
        $this->correct($data);
        return $data;
    }

    public function getAddData()
    {
        $add = array();
        foreach (waRequest::post('add', array()) as $name => $items) {
            foreach ($items as $k => $value) {
                $add[$k][$name] = $value;
            }
        }
        $this->correct($add);

        // group by before_id values
        $data = array();
        foreach ($add as $item) {
            $before_id = (int)$item['before_id'];
            if (!isset($data[$before_id])) {
                $data[$before_id] = array();
            }
            unset($item['before_id']);
            $data[$before_id][] = $item;
        }
        return $data;
    }

    public function correct(&$data)
    {
        foreach ($data as &$item) {
            if (!is_numeric($item['low_count'])) {
                $low_count = (int)$item['low_count'];
                if (!$low_count) {
                    $low_count = shopStockModel::LOW_DEFAULT;
                }
            } else {
                $low_count = $item['low_count'];
                if ($low_count < 0) {
                    $low_count = shopStockModel::LOW_DEFAULT;
                }
            }
            if (!is_numeric($item['critical_count'])) {
                $critical_count = (int)$item['critical_count'];
                if (!$critical_count) {
                    $critical_count = shopStockModel::CRITICAL_DEFAULT;
                }
            } else {
                $critical_count = $item['critical_count'];
                if ($critical_count < 0) {
                    $critical_count = shopStockModel::CRITICAL_DEFAULT;
                }
            }
            if ($low_count < $critical_count) {
                list ($low_count, $critical_count) = array($critical_count, $low_count);
            }
            $item['low_count'] = $low_count;
            $item['critical_count'] = $critical_count;
        }
        unset($item);
    }
}