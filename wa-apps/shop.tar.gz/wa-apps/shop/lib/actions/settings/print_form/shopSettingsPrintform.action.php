<?php
class shopSettingsPrintformAction extends waViewAction
{
    public function execute()
    {
        $plugins = $this->getConfig()->getPlugins();
        foreach ($plugins as $id => $plugin) {
            if (empty($plugin['printform'])) {
                unset($plugins[$id]);
            }
        }
        $this->view->assign('plugins', $plugins);
    }
}
