<?php

class shopSettingsRegionsAction extends waViewAction
{
    public function execute()
    {
        $cm = new waCountryModel();
        $countries = $cm->all();

        $rm = new waRegionModel();

        $country = waRequest::request('country');

        if (!$country || empty($countries[$country])) {
            // Show the first country with regions by default
            $region_countries = $rm->getCountries();
            $country = reset($region_countries);
        } else {
            $this->saveFromPost($rm, $country);
        }

        $regions = array();
        if ($country) {
            $regions = $rm->getByCountry($country);
        }

        $this->view->assign('countries', $countries);
        $this->view->assign('country', $country);
        $this->view->assign('regions', $regions);
    }

    protected function saveFromPost($rm, $country)
    {
        if (!waRequest::post()) {
            return;
        }

        $region_codes = waRequest::post('region_codes');
        if (!$region_codes || !is_array($region_codes)) {
            $region_codes = array();
        }
        $region_names = waRequest::post('region_names');
        if (!$region_names || !is_array($region_names)) {
            $region_names = array();
        }

        $regions = array();
        foreach($region_codes as $i => $code) {
            $code = trim($code);
            $name = trim(ifempty($region_names[$i], ''));
            if (!$name || !$code) {
                continue;
            }
            $regions[$code] = $name;
        }

        $rm->saveForCountry($country, $regions);
    }
}

