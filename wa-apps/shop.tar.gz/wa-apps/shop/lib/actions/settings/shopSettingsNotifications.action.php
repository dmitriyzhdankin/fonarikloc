<?php
class shopSettingsNotificationsAction extends waViewAction
{

}
