<?php

class shopDialogFieldValuesAction extends waViewAction
{
    public function execute()
    {
        $field = waRequest::get('field', null, waRequest::TYPE_STRING_TRIM);
        if (!$field) {
            throw new waException(_w("Unknown field"));
        }
        $model = new shopContactFieldValuesModel();

        $this->view->assign(array(
            'field' => $field,
            'title' => _w(ucfirst($field)),
            'fields' => $model->getInfo($field)
        ));
    }
}