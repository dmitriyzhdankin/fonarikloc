<?php

class shopFrontendProductAction extends waViewAction
{
    /**
     * @var shopProductReviewsModel
     */
    protected $reviews_model;

    public function __construct($params = null) {
        $this->reviews_model = new shopProductReviewsModel();
        parent::__construct($params);
    }

    public function getBreadcrumbs(shopProduct $product)
    {
        if ($categories = $product->categories) {
            $category = current($categories);
            $category_model = new shopCategoryModel();
            $breadcrumbs = array();
            $path = $category_model->getPath($category['id']);
            foreach ($path as $row) {
                $breadcrumbs[] = array(
                    'url' => wa()->getRouteUrl('/frontend/category', array('category_url' => $row['full_url'])),
                    'name' => $row['name']
                );
            }
            $breadcrumbs[] = array(
                'url' => wa()->getRouteUrl('/frontend/category', array('category_url' => $category['full_url'])),
                'name' => $category['name']
            );
            if ($breadcrumbs && $this->layout) {
                $this->layout->assign('breadcrumbs', $breadcrumbs);
            }
        }
    }

    public function execute()
    {
        $this->setLayout(new shopFrontendLayout());
        $product_model = new shopProductModel();
        $product = $product_model->getByField('url', waRequest::param('product_url'));

        if (!$product) {
            throw new waException('Product not found', 404);
        }

        if ($types = waRequest::param('type_id')) {
            if (!in_array($product['type_id'], $types)) {
                throw new waException('Product not found', 404);
            }
        }


        $product = new shopProduct($product);
        $this->view->assign('product', $product);

        $this->getBreadcrumbs($product);

        // get services
        $type_services_model = new shopTypeServicesModel();
        $services = $type_services_model->getServiceIds($product['type_id']);

        $service_model = new shopServiceModel();
        $product_services_model = new shopProductServicesModel();
        $services = array_merge($services, $product_services_model->getServiceIds($product['id']));
        $services = array_unique($services);

        $services = $service_model->getById($services);

        $variants_model = new shopServiceVariantsModel();
        $rows = $variants_model->getByField('service_id', array_keys($services), true);
        foreach ($rows as $row) {
            if (!$row['price']) {
                $row['price'] = $services[$row['service_id']]['price'];
            }
            $services[$row['service_id']]['variants'][$row['id']] = $row;
        }


        $rows = $product_services_model->getByField('product_id', $product['id'], true);
        $skus_services = array();
        foreach ($product['skus'] as $sku) {
            $skus_services[$sku['id']] = array();
        }
        foreach ($rows as $row) {
            if (!$row['sku_id']) {
                // remove disabled services and variants
                if (!$row['status']) {
                    if ($row['service_variant_id']) {
                        unset($services[$row['service_id']]['variants'][$row['service_variant_id']]);
                    } else {
                        unset($services[$row['service_id']]);
                    }
                } elseif ($row['price'] !== null) {
                    // update price
                    if ($row['service_variant_id']) {
                        $services[$row['service_id']]['variants'][$row['service_variant_id']]['price'] = $row['price'];
                    } else {
                        $services[$row['service_id']]['price'] = $row['price'];
                    }
                }
            } else {
                if (!$row['status']) {
                    if ($row['service_variant_id']) {
                        $skus_services[$row['sku_id']][$row['service_id']][$row['service_variant_id']] = false;
                    } elseif (!isset($services[$row['service_id']]['variants'])) {
                        $skus_services[$row['sku_id']][$row['service_id']] = false;
                    }
                } else {
                    if ($row['service_variant_id']) {
                        $skus_services[$row['sku_id']][$row['service_id']][$row['service_variant_id']] = $row['price'];
                    } elseif (!isset($services[$row['service_id']]['variants'])) {
                        $skus_services[$row['sku_id']][$row['service_id']] = $row['price'];
                    }
                }
            }
        }

        foreach ($skus_services as &$sku_services) {
            foreach ($services as $service_id => $service) {
                if (isset($sku_services[$service_id])) {
                    if ($sku_services[$service_id]) {
                        if (isset($service['variants'])) {
                            foreach ($service['variants'] as $v) {
                                if (!isset($sku_services[$service_id][$v['id']]) || $sku_services[$service_id][$v['id']] === null) {
                                    $sku_services[$service_id][$v['id']] = array($v['name'], $this->getPrice($v['price'], $service['currency']));
                                } elseif ($sku_services[$service_id][$v['id']]) {
                                    $sku_services[$service_id][$v['id']] = array($v['name'], $this->getPrice($sku_services[$service_id][$v['id']], $service['currency']));
                                }
                            }
                        } else {
                            if (!isset($sku_services[$service_id]) || $sku_services[$service_id] === null) {
                                $sku_services[$service_id] = $this->getPrice($service['price'], $service['currency']);
                            } else {
                                $sku_services[$service_id] = $this->getPrice($sku_services[$service_id], $service['currency']);
                            }
                        }
                    }
                } else {
                    if (isset($service['variants'])) {
                        foreach ($service['variants'] as $v) {
                            $sku_services[$service_id][$v['id']] = array($v['name'], $this->getPrice($v['price'], $service['currency']));
                        }
                    } else {
                        $sku_services[$service_id] = $this->getPrice($service['price'], $service['currency']);
                    }
                }
            }
        }
        unset($sku_services);

        // disable service if all variants disabled
        foreach ($skus_services as $sku_id => $sku_services) {
            foreach ($sku_services as $service_id => $service) {
                if (is_array($service)) {
                    $disabled = true;
                    foreach ($service as $v) {
                        if ($v !== false) {
                            $disabled = false;
                            break;
                        }
                    }
                    if ($disabled) {
                        $skus_services[$sku_id][$service_id] = false;
                    }
                }
            }
        }

        $this->view->assign('sku_services', $skus_services);
        $this->view->assign('services', $services);

        $compare = waRequest::cookie('shop_compare', array(), waRequest::TYPE_ARRAY_INT);
        $this->view->assign('compare', in_array($product['id'], $compare) ? $compare : array());

        $this->view->assign('reviews', $this->getTopReviews($product['id']));
        $this->view->assign('reviews_total_count', $this->getReviewsTotalCount($product['id']));

        $title = $product['meta_title'] ? $product['meta_title'] : $product['name'];
        wa()->getResponse()->setTitle($title);
        wa()->getResponse()->setMeta('keywords', $product['meta_keywords']);
        wa()->getResponse()->setMeta('description', $product['meta_description']);

        $this->setThemeTemplate('product.html');
    }

    protected function getPrice($price, $currency)
    {
        return shop_currency($price, $currency);
    }

    protected function getReviewsTotalCount($product_id)
    {
        return $this->reviews_model->count($product_id, false);
    }

    protected function getTopReviews($product_id)
    {
        return $this->reviews_model->getReviews($product_id,
                0, wa()->getConfig()->getOption('reviews_per_page_product'),
                'datetime DESC',
                array('escape' => true)
        );
    }
}