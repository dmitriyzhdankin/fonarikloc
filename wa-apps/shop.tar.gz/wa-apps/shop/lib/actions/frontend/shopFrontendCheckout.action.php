<?php

class shopFrontendCheckoutAction extends waViewAction
{
    public function execute()
    {
        $this->setLayout(new shopFrontendLayout());

        $steps = $this->getConfig()->getCheckoutSettings();

        $current_step = waRequest::param('step');
        if (!$current_step) {
            $current_step = key($steps);
        }

        $title = _w('Checkout');
        if ($current_step == 'success') {
            $order_id = wa()->getStorage()->get('shop/order_id');
            $order_model = new shopOrderModel();
            $order = $order_model->getById($order_id);
            $order_params_model = new shopOrderParamsModel();
            $params = $order_params_model->get($order_id);
            if (!empty($params['payment_id'])) {
                $plugin = shopPayment::getPlugin(null, $params['payment_id']);
                $currency = $plugin->allowedCurrency();
                $total = $order['total'];
                if ($order['currency'] != $currency) {
                    $total = shop_currency($total, $order['currency'], $currency, false);
                }
                $payment = $plugin->payment(null, array(
                    'customer_contact_id' => $order['contact_id'],
                    'currency_id' => $currency,
                    'amount' => $total,
                    'order_id' => $order['id']
                ), null);
            } else {
                $payment = '';
            }
            $order['id'] = shopHelper::encodeOrderId($order_id);
            $this->view->assign('order', $order);
            $this->view->assign('payment', $payment);
        } else {
            $cart = new shopCart();
            if (!$cart->count()) {
                $current_step = 'error';
                $this->view->assign('error', _w('Your shopping cart is empty. Please add some products to cart, and then proceed to checkout.'));
            }

            if ($current_step != 'error') {
                if (waRequest::method() == 'post') {
                    $redirect = false;
                    foreach ($steps as $step_id => $step) {
                        if ($step_id == $current_step) {
                            $step_instance = $this->getStep($step_id);
                            if ($step_instance->execute()) {
                                $redirect = true;
                            }

                        } elseif ($redirect) {
                            $this->redirect(wa()->getRouteUrl('/frontend/checkout', array('step' => $step_id)));
                        }
                    }

                    // last step
                    if ($redirect) {
                        if ($this->createOrder()) {
                            $this->redirect(wa()->getRouteUrl('/frontend/checkout', array('step' => 'success')));
                        }
                    }
                }
                $title .= ' - '.$steps[$current_step]['name'];
                $steps[$current_step]['content'] = $this->getStep($current_step)->display();
                $this->view->assign('checkout_steps', $steps);
            }
        }
        $this->getResponse()->setTitle($title);
        $this->view->assign('checkout_current_step', $current_step);

        $this->setThemeTemplate('checkout.html');
    }

    protected function createOrder()
    {
        $checkout_data = $this->getStorage()->get('shop/checkout');
        $contact = $this->getUser()->isAuth() ? $this->getUser() : $checkout_data['contact'];
        $cart = new shopCart();
        $cart_items = $cart->items();
        $shipping_address = $contact->getFirst('address.shipping');
        if (!$shipping_address) {
            $shipping_address = $contact->getFirst('address');
        }
        $billing_address = $contact->getFirst('address.billing');
        if (!$billing_address) {
            $billing_address = $contact->getFirst('address');
        }
        $taxes = shopTaxes::apply($cart_items, array('shipping' => $shipping_address['data'], 'billing' => $billing_address['data']));
        $tax = $tax_included = 0;
        foreach ($taxes as $t) {
            $tax += $t['sum'];
            $tax_included += $t['sum_included'];
        }
        $items = array();
        foreach ($cart_items as $item) {
            unset($item['id']);
            if (!empty($item['services'])) {
                $services = $item['services'];
                unset($item['services']);
                $items[] = $item;
                foreach ($services as $service_item) {
                    unset($service_item['id']);
                    $items[] = $service_item;
                }
            } else {
                $items[] = $item;
            }
        }

        $total = $cart->total(false);
        $order = array(
            'contact' => $contact,
            'items' => $items,
            'params' => isset($checkout_data['params']) ? $checkout_data['params'] : array(),
            'total' => $total,
            'tax' => $tax_included
        );
        $order['discount'] = shopDiscounts::apply($order);

        if (isset($checkout_data['shipping'])) {
            $order['params']['shipping_id'] = $checkout_data['shipping']['id'];
            $order['params']['shipping_rate_id'] = $checkout_data['shipping']['rate_id'];
            $shipping_step = new shopCheckoutShipping();
            $rate = $shipping_step->getRate($order['params']['shipping_id'], $order['params']['shipping_rate_id']);
            $order['params']['shipping_plugin'] = $rate['plugin'];
            $order['params']['shipping_name'] = $rate['name'];
            $order['params']['shipping_est_delivery'] = $rate['est_delivery'];
            if (!isset($order['shipping'])) {
                $order['shipping'] = $rate['rate'];
            }
        } else {
            $order['shipping'] = 0;
        }

        if (isset($checkout_data['payment'])) {
            $order['params']['payment_id'] = $checkout_data['payment'];
            $plugin = shopPayment::getPlugin(null, $checkout_data['payment']);;
            $order['params']['payment_name'] = $plugin->getName();
            $order['params']['payment_plugin'] = $plugin->getId();
        }

        if ($skock_id = waRequest::post('stock_id')) {
            $order['params']['stock_id'] = $skock_id;
        }

        $routing_url = wa()->getRouting()->getRootUrl();
        $order['params']['storefront'] = wa()->getConfig()->getDomain().($routing_url ? '/'.$routing_url : '');

        foreach (array('shipping', 'billing') as $ext) {
            $address = $contact->getFirst('address.'.$ext);
            if (!$address) {
                $address = $contact->getFirst('address');
            }
            foreach ($address['data'] as $k => $v) {
                $order['params'][$ext.'_address.'.$k] = $v;
            }
        }

        if (isset($checkout_data['comment'])) {
            $order['comment'] = $checkout_data['comment'];
        }

        $order['total'] = $order['total'] - $order['discount'] + $order['shipping'] + $tax;

        $workflow = new shopWorkflow();
        if ($order_id = $workflow->getActionById('create')->run($order)) {
            $cart->clear();
            wa()->getStorage()->remove('shop/checkout');
            wa()->getStorage()->set('shop/order_id', $order_id);
            return true;
        }
    }


    /**
     * @param shopCheckout $step_id
     */
    protected function getStep($step_id)
    {
        static $steps;
        if (!isset($steps[$step_id])) {
            $class_name = 'shopCheckout'.ucfirst($step_id);
            $steps[$step_id] = new $class_name();
        }
        return $steps[$step_id];
    }


}