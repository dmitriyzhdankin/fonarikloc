<?php

class shopFrontendCategoryAction extends shopFrontendAction
{
    public function execute()
    {

        $this->setLayout(new shopFrontendLayout());

        $category_model = new shopCategoryModel();
        $category = $category_model->getByField('full_url', waRequest::param('category_url'));
        if ($category['filter']) {
            $filter_ids = explode(',', $category['filter']);
            $feature_model = new shopFeatureModel();
            $features = $feature_model->getById($filter_ids);
            $features = $feature_model->getValues($features);
            $filters = array();
            foreach ($filter_ids as $fid) {
                if ($fid == 'price') {
                    $filters['price'] = true;
                } elseif (isset($features[$fid])) {
                    $filters[$fid] = $features[$fid];
                }
            }
            $this->view->assign('filters', $filters);
        }

        if (!$category) {
            throw new waException('Category not found', 404);
        }

        $category['subcategories'] = $category_model->getSubcategories($category);

        $this->view->assign('category', $category);

        if ($category['parent_id']) {
            $breadcrumbs = array();
            $path = $category_model->getPath($category['id']);
            foreach ($path as $row) {
                $breadcrumbs[] = array(
                    'url' => wa()->getRouteUrl('/frontend/category', array('category_url' => $row['full_url'])),
                    'name' => $row['name']
                );
            }
            if ($breadcrumbs && $this->layout) {
                $this->layout->assign('breadcrumbs', $breadcrumbs);
            }
        }

        $this->setCollection(new shopProductsCollection('category/'.$category['id']));

        $title = $category['meta_title'] ? $category['meta_title'] : $category['name'];
        wa()->getResponse()->setTitle($title);
        wa()->getResponse()->setMeta('keywords', $category['meta_keywords']);
        wa()->getResponse()->setMeta('description', $category['meta_description']);

        $this->setThemeTemplate('category.html');
    }
}