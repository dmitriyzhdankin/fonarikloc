<?php
class shopFrontendAction extends waViewAction
{
    protected function setCollection(shopProductsCollection $collection)
    {
        $limit = $this->getConfig()->getOption('products_per_page');
        $page = waRequest::get('page', 1, 'int');
        if ($page < 1) {
            $page = 1;
        }
        $offset = ($page - 1) * $limit;

        $products = $collection->getProducts('*', $offset, $limit);
        $count = $collection->count();

        $pages_count = ceil((float)$count / $limit);
        $this->view->assign('pages_count', $pages_count);

        $this->view->assign('products', $products);
    }

    public function execute()
    {
        if (wa()->getRouting()->getCurrentUrl()) {
            throw new waException('Page not found', 404);
        }
        $title = waRequest::param('title');
        if (!$title) {
            $app = wa()->getAppInfo();
            $title = $app['name'];
        }
        $this->getResponse()->setTitle($title);
        $this->getResponse()->setMeta('keywords', waRequest::param('meta_keywords'));
        $this->getResponse()->setMeta('description', waRequest::param('meta_description'));

        $this->setLayout(new shopFrontendLayout());
        $this->setThemeTemplate('home.html');
    }
}
