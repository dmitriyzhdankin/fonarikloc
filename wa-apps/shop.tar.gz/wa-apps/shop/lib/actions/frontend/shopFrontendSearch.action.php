<?php

class shopFrontendSearchAction extends shopFrontendAction
{
    public function execute()
    {
        $query = waRequest::get('query');
        $this->setCollection(new shopProductsCollection('search/query='.$query));

        $query = htmlspecialchars($query);
        $this->view->assign('title', $query);
        $this->getResponse()->setTitle(_w('Search').' - '.$query);

        $this->setLayout(new shopFrontendLayout());
        $this->layout->assign('query', $query);
        $this->setThemeTemplate('search.html');
    }
}