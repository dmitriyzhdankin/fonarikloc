<?php

class shopFrontendCartDeleteController extends waJsonController
{
    public function execute()
    {
        $id = waRequest::post('id');
        if ($id) {
            $cart = new shopCart();
            $cart->deleteItem($id);
        }
        $this->response['total'] = shop_currency($cart->total());
    }
}