<?php

class shopFrontendCartAction extends waViewAction
{
    public function execute()
    {
        if (!waRequest::isXMLHttpRequest()) {
            $this->setLayout(new shopFrontendLayout());
        }

        if (waRequest::method() == 'post') {
            if ($coupon_code = waRequest::post('coupon_code')) {
                $data = wa()->getStorage()->set('shop/checkout', array());
                $data['coupon_code'] = $coupon_code;
                wa()->getStorage()->set('shop/checkout', $data);
                wa()->getStorage()->remove('shop/cart');
            }
        }

        if (waRequest::post('checkout')) {
            $this->redirect(wa()->getRouteUrl('/frontend/checkout'));
        }

        $this->setThemeTemplate('cart.html');

        $cart = new shopCart();
        $code = $cart->getCode();

        $cart_model = new shopCartItemsModel();
        $items = $cart_model->where('code= ?', $code)->order('parent_id')->fetchAll('id');

        $product_ids = $sku_ids = $service_ids = $type_ids = array();
        foreach ($items as $item) {
            $product_ids[] = $item['product_id'];
            $sku_ids[] = $item['sku_id'];
        }

        $product_ids = array_unique($product_ids);
        $sku_ids = array_unique($sku_ids);

        $product_model = new shopProductModel();
        $products = $product_model->getByField('id', $product_ids, 'id');

        $sku_model = new shopProductSkusModel();
        $skus = $sku_model->getByField('id', $sku_ids, 'id');

        foreach ($items as &$item) {
            if ($item['type'] == 'product') {
                $item['product'] = $products[$item['product_id']];
                $sku = $skus[$item['sku_id']];
                $item['sku_name'] = $sku['name'];
                $item['price'] = $sku['price'];
                $item['currency'] = $item['product']['currency'];
                $type_ids[] = $item['product']['type_id'];
            }
        }
        unset($item);

        $type_ids = array_unique($type_ids);

        // get available services for all types of products
        $type_services_model = new shopTypeServicesModel();
        $rows = $type_services_model->getByField('type_id', $type_ids, true);
        $type_services = array();
        foreach ($rows as $row) {
            $service_ids[] = $row['service_id'];
            $type_services[$row['type_id']][$row['service_id']] = true;
        }

        // get services for all products
        $product_services_model = new shopProductServicesModel();
        $rows = $product_services_model->getByProducts($product_ids);

        $product_services = $sku_services = array();
        foreach ($rows as $row) {
            $service_ids[] = $row['service_id'];
            if (!$row['service_variant_id']) {
                if (!$row['sku_id'] && !isset($product_services[$row['product_id']][$row['service_id']])) {
                    $product_services[$row['product_id']][$row['service_id']] = $row;
                }
                if ($row['sku_id'] && !isset($sku_services[$row['sku_id']][$row['service_id']])) {
                    $sku_services[$row['sku_id']][$row['service_id']] = $row;
                }
            } else {
                if (!$row['sku_id']) {
                    $product_services[$row['product_id']][$row['service_id']]['variants'][$row['service_variant_id']] = $row;
                }
                if ($row['sku_id']) {
                    $sku_services[$row['sku_id']][$row['service_id']]['variants'][$row['service_variant_id']] = $row;
                }
            }
        }

        $service_ids = array_unique($service_ids);

        $service_model = new shopServiceModel();
        $variant_model = new shopServiceVariantsModel();
        $services = $service_model->getByField('id', $service_ids, 'id');

        $rows = $variant_model->getByField('service_id', $service_ids, true);
        foreach ($rows as $row) {
            $services[$row['service_id']]['variants'][$row['id']] = $row;
            unset($services[$row['service_id']]['variants'][$row['id']]['id']);
        }

        foreach ($items as $item_id => $item) {
            if ($item['type'] == 'product') {
                $p = $item['product'];
                $item_services = array();
                // services from type settings
                if (isset($type_services[$p['type_id']])) {
                    foreach ($type_services[$p['type_id']] as $service_id => &$s) {
                        $item_services[$service_id] = $services[$service_id];
                        unset($item_services[$service_id]['id']);
                    }
                }
                // services from product settings
                if (isset($product_services[$item['product_id']])) {
                    foreach ($product_services[$item['product_id']] as $service_id => $s) {
                        if ($s['status']) {
                            if (!isset($item_services[$service_id])) {
                                $item_services[$service_id] = $services[$service_id];
                            }
                            // update variants
                            if (isset($services[$service_id]['variants'])) {
                                foreach ($s['variants'] as $variant_id => $v) {
                                    if ($v['status']) {
                                        if ($v['price'] !== null) {
                                            $item_services[$service_id]['variants'][$variant_id]['price'] = $v['price'];
                                        }
                                    } else {
                                        unset($item_services[$service_id]['variants'][$variant_id]);
                                    }
                                }
                            } elseif ($s['price'] !== null) {
                                // update services price
                                $item_services[$service_id]['price'] = $s['price'];
                            }
                        } elseif (isset($item_services[$service_id])) {
                            // remove disabled service
                            unset($item_services[$service_id]);
                        }
                    }
                }
                // services from sku settings
                if (isset($sku_services[$item['sku_id']])) {
                    foreach ($sku_services[$item['sku_id']] as $service_id => $s) {
                        if (!isset($s['status']) || $s['status']) {
                            // update variants
                            if (isset($services[$service_id]['variants'])) {
                                foreach ($s['variants'] as $variant_id => $v) {
                                    if ($v['status']) {
                                        if ($v['price'] !== null) {
                                            $item_services[$service_id]['variants'][$variant_id]['price'] = $v['price'];
                                        }
                                    } else {
                                        unset($item_services[$service_id]['variants'][$variant_id]);
                                    }
                                }
                            } else {
                                if ($s['price'] !== null) {
                                    $item_services[$service_id]['price'] = $s['price'];
                                }
                            }
                        } elseif (isset($item_services[$service_id])) {
                            // remove disabled service
                            unset($item_services[$service_id]);
                        }
                    }
                }
                $items[$item_id]['services'] = $item_services;
            } else {
                $items[$item['parent_id']]['services'][$item['service_id']]['id'] = $item['id'];
                if (isset($item['service_variant_id'])) {
                    $items[$item['parent_id']]['services'][$item['service_id']]['variant_id'] = $item['service_variant_id'];
                }
                unset($items[$item_id]);
            }
        }

        $order = array('total' => $cart->total(false));
        $discount = shopDiscounts::calculate($order);
        $total = $cart->total();
        $data = wa()->getStorage()->get('shop/checkout');
        $this->view->assign('cart', array(
            'items' => $items,
            'total' => $total,
        ));
        $this->view->assign('coupon_code', isset($data['coupon_code']) ? $data['coupon_code'] : '');
        $this->view->assign('discount', $discount);

        $this->getResponse()->setTitle(_w('Cart'));
    }

}