<?php

class shopFrontendProductPageAction extends shopFrontendProductAction
{
    public function execute()
    {
        $this->setLayout(new shopFrontendLayout());

        $product_model = new shopProductModel();
        $product = $product_model->getByField('url', waRequest::param('product_url'));

        if (!$product) {
            throw new waException('Product not found', 404);
        }
        $product = new shopProduct($product);
        $this->view->assign('product', $product);

        $this->getBreadcrumbs($product);

        $page_model = new shopProductPagesModel();
        $page = $page_model->getByField(array('product_id' => $product['id'], 'url' => waRequest::param('page_url')));
        if (!$page) {
            throw new waException('Page not found', 404);
        }
        $page_params_model = new shopProductPageParamsModel();
        $page = $page + $page_params_model->getParams($page['id']);
        if (!$page['title']) {
            $page['title'] = $page['name'];
        }

        $this->view->assign('page', $page);

        $this->getResponse()->setTitle($product['name'].' - '.$page['title']);
        $this->getResponse()->setMeta(array(
            'keywords' => isset($page['keywords']) ? $page['keywords'] : '',
            'description' => isset($page['description']) ? $page['description'] : ''
        ));


        $this->setThemeTemplate('product_page.html');
    }
}