<?php
class shopBackendProductsSubmenuAction extends waViewAction
{
    public function execute()
    {
        ;//
    }
}
