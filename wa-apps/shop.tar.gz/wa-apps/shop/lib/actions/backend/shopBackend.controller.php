<?php

class shopBackendController extends waViewController
{
    public function execute()
    {
        $this->executeAction(new shopBackendOrdersAction());
    }
}