<?php
class shopBackendOrdersAction extends waViewAction
{
    public function execute()
    {
        $this->setLayout(new shopBackendLayout());
        $this->getResponse()->setTitle(_w('Orders'));

        $config = $this->getConfig();

        $order_model = new shopOrderModel();

        $this->view->assign(array(
            'states' => $this->getStates(),
            'contacts' => array()/*$order_model->getContacts()*/,
            'user_id' => $this->getUser()->getId(),
            'default_view' => $config->getOption('orders_default_view'),
            'state_counters' => $order_model->getStateCounters(),
            'contact_counters' => $order_model->getContactCounters()
        ));
    }

    public function getStates()
    {
        $workflow = new shopWorkflow();
        return $workflow->getAllStates();
    }
}
