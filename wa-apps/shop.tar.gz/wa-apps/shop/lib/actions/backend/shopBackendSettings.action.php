<?php
class shopBackendSettingsAction extends waViewAction
{
    public function execute()
    {
        //TODO get dynamic sections lists and verify users rights(?)
    }
}
