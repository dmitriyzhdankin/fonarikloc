<?php
class shopBackendProductsAction extends waViewAction
{
    public function execute()
    {

        $this->setLayout(new shopBackendLayout());

        $this->getResponse()->setTitle(_w('Products'));

        $category_model = new shopCategoryModel();
        $this->view->assign('categories', $category_model->getFullTree());

        $tag_model = new shopTagModel();
        $this->view->assign('cloud', $tag_model->getCloud());

        $set_model = new shopSetModel();
        $this->view->assign('sets', $set_model->getAll());

        $type_model = new shopTypeModel();
        $this->view->assign('types', $type_model->getAll());

        $product_model = new shopProductModel();
        $this->view->assign('count_all', $product_model->countAll());

        $review_model = new shopProductReviewsModel();
        $this->view->assign('count_reviews', array(
            'all' => $review_model->count(null, false),
            'new' => $review_model->countNew(true)
        ));

        $product_services = new shopServiceModel();
        $this->view->assign('count_services', $product_services->countAll());

        $config = $this->getConfig();
        $this->view->assign('default_view', $config->getOption('products_default_view'));

        /**
         * Extend backend sidebar
         * Add extra sidebar items (menu items, additional sections, system output)
         * @event backend_products_sidebar
         * @example #event handler example
         * public function productsSidebarAction()
         * {
         *     $output = array();
         *
         *     #add external link into sidebar menu
         *     $output['menu']='<li>
         *         <a href="http://www.webasyst.com">
         *             http://www.webasyst.com
         *         </a>
         *     </li>';
         *
         *     #add section into sidebar menu
         *     $output['section']='';
         *
         *     #add system link into sidebar menu
         *     $output['system']='';
         *
         *     return $output;
         * }
         * @return array[string][string]string $return[%plugin_id%]['menu'] Single menu items
         * @return array[string][string]string $return[%plugin_id%]['section'] Sections menu items
         */
        $this->view->assign('backend_products_sidebar', wa()->event('backend_products_sidebar'));

    }
}
