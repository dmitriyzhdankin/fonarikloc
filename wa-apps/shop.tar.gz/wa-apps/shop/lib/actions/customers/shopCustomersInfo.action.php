<?php

/**
 * Single customer details.
 */
class shopCustomersInfoAction extends waViewAction
{
    public function execute()
    {
        $id = waRequest::request('id');

        $scm = new shopCustomerModel();
        $customer = $scm->getById($id);

        try {
            $contact = new waContact($id);
            $contact->getName();
        } catch (waException $e) {
            // !!! What to do when shop_customer exists, but no wa_contact found?
            throw $e;
        }

        $ccsm = new waContactCategoriesModel();
        $contact_categories = $ccsm->getContactCategories($id);

        $contacts_url = wa()->getAppUrl('contacts');

        // Info above tabs
        $top = array();
        foreach (array('email', 'phone', 'im') as $f) {
            if ( ( $v = $contact->get($f, 'top,html'))) {
                $top[] = array(
                    'id' => $f,
                    'name' => waContactFields::get($f)->getName(),
                    'value' => is_array($v) ? implode(', ', $v) : $v,
                );
            }
        }

        // Customer orders
        $om = new shopOrderModel();
        $im = new shopOrderItemsModel();
        $orders = $om->getList('*,params', array( // shipping_name,shipping_plugin_id,payment_name,payment_plugin_id
            'where' => array('contact_id' => $id),
        ));
        shopHelper::workupOrders($orders);
        foreach($orders as &$o) {
            $o['items'] = array();
            foreach($im->getItems($o['id'], true) as $i) {
                $o['items'][] = array(
                    'name' => $i['item']['name'],
                    'quantity' => $i['item']['quantity'],
                );
            }
            $o['total_formatted'] = waCurrency::format('%{s}', $o['total'], $o['currency']);
            $o['shipping_name'] = ifset($o['params']['shipping_name'], '');
            $o['payment_name'] = ifset($o['params']['payment_name'], '');
            // !!! TODO: shipping and payment icons
        }

        $this->view->assign('top', $top);
        $this->view->assign('orders', $orders);
        $this->view->assign('contact', $contact);
        $this->view->assign('customer', $customer);
        $this->view->assign('contacts_url', $contacts_url);
        $this->view->assign('contact_categories', $contact_categories);
        $this->view->assign('fields', waContactFields::getAll('person'));
    }
}

