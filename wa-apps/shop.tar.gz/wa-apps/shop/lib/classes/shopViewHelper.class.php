<?php

class shopViewHelper extends waAppViewHelper
{
    protected $_cart;

    public function productSet($set_id, $offset = null, $limit = null)
    {
        if (!$limit && $offset) {
            $limit = $offset;
            $offset = 0;
        }
        if (!$offset && !$limit) {
            $offset = 0;
            $limit = 500;
        }
        $collection = new shopProductsCollection('set/'.$set_id);
        return $collection->getProducts('*', $offset, $limit, true);
    }

    public function cart()
    {
        if (!$this->_cart) {
            $this->_cart = new shopCart();
        }
        return $this->_cart;
    }

    public function currency($full_info = false)
    {
        $currency = $this->wa->getConfig()->getCurrency(false);
        if ($full_info) {
            return waCurrency::getInfo($currency);
        } else {
            return $currency;
        }
    }

    public function getImageBadgeHtml($image)
    {
        return shopHelper::getImageBadgeHtml($image);
    }

    public function getProductImgHtml($product, $size, $attributes = array())
    {
        if (!$product['image_id']) {
            return '';
        }
        $html = '<img';
        foreach ($attributes as $k => $v) {
            $html .= ' '.$k.'="'.$v.'"';
        }
        $html .= ' src="'.shopImage::getUrl(array(
            'product_id' => $product['id'], 'id' => $product['image_id'], 'ext' => $product['ext']), $size).'">';
        return $html;
    }

    public function __get($name)
    {
        if ($name == 'cart') {
            return $this->cart();
        }
    }


    public function categories()
    {
        $category_model = new shopCategoryModel();
        $cats = $category_model->getFullTree();
        foreach ($cats as &$c) {
            $c['url'] = $this->wa->getRouteUrl('shop/frontend/category', array('category_url' => $c['full_url']));
        }
        unset($c);
        return $cats;
    }

    public function tags()
    {
        $tag_model = new shopTagModel();
        return $tag_model->getCloud();
    }

    public function payment()
    {
        return array();
    }

    public function orderId($id)
    {
        return shopHelper::encodeOrderId($id);
    }

    public function icon16($url_or_class)
    {
        // Hack to hide icon that is common for all customers
        $app_icon = '/wa-apps/shop/img/shop16.png';
        if (substr($url_or_class, -strlen($app_icon)) == $app_icon) {
            return '';
        }

        if (substr($url_or_class, 0, 7) == 'http://') {
            return '<i class="icon16" style="background-image:url('.htmlspecialchars($url_or_class).')"></i>';
        } else {
            return '<i class="icon16 '.htmlspecialchars($url_or_class).'"></i>';
        }
    }
}
