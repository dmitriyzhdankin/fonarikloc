<?php
class shopPayment extends waAppPayment
{

    public function __construct($merchant_id)
    {
        parent::__construct($merchant_id);
        $this->app_id = 'shop';
    }
    /**
     *
     * @param string $plugin plugin identity string (e.g. PayPal/WebMoney)
     * @param int $plugin_id plugin instance id
     * @return waPayment
     */
    public static function getPlugin($plugin, $plugin_id = null)
    {

        if (!$plugin && $plugin_id) {
            $model = new shopPluginModel();
            $info = $model->getById($plugin_id);

            if (!$info) {
                throw new waException("Payment plugin {$plugin_id} not found", 404);
            }

            if ($info['type'] != shopPluginModel::TYPE_PAYMENT) {
                throw new waException("Payment plugin {$plugin_id} has invalid type", 404);
            }
            $plugin = $info['plugin'];
        }
        return waPayment::factory($plugin, new shopPluginSettingsModel(), $plugin_id);
    }

    public static function getPluginInfo($id)
    {
        if ($plugin_id = max(0, intval($id))) {

            $model = new shopPluginModel();
            $info = $model->getById($plugin_id);

            if (!$info) {
                throw new waException("Payment plugin {$plugin_id} not found", 404);
            }
        } else {
            $info = array(
                'plugin' => $id,
                'status' => 1,
            );
        }

        $plugin = self::getPlugin($info['plugin'], $plugin_id);
        $default_info = array(
            'name'        => $plugin->getName(),
            'description' => $plugin->getDescription(),

        );
        return array_merge($default_info, $info);
    }

    public static function savePlugin($plugin)
    {
        $model = new shopPluginModel();
        if (!empty($plugin['id']) && ($id = max(0, intval($plugin['id']))) && ($row = $model->getByField(array('id' => $id, 'type' => shopPluginModel::TYPE_PAYMENT)))) {
            $plugin['plugin'] = $row['plugin'];
            $model->updateById($plugin['id'], $plugin);
        } elseif (!empty($plugin['plugin'])) {
            $plugin['type'] = shopPluginModel::TYPE_PAYMENT;
            $plugin['id'] = $model->insert($plugin);
        }
        if (!empty($plugin['id']) && isset($plugin['settings'])) {
            $settings_model = new shopPluginSettingsModel();
            foreach ($plugin['settings'] as $name => $value) {
                $settings_model->set($plugin['id'], $name, is_array($value) ? json_encode($value) : $value);
            }
        }
        return $plugin;
    }

    public static function getList()
    {
        if (!class_exists('waPayment')) {
            throw new waException(_wp('Payment plugins not installed yet'));
        }
        return waPayment::enumerate(array('logo' => true));
    }

    public function getOrderData()
    {

    }

    public function getMerchantData($payment_id, $merchant_key)
    {
        $model = new shopPluginSettingsModel();
        return $model->get($merchant_key);
    }

    public function callbackPaymentHandler($transaction_data, $payment_id, $merchant_id = null, $order_data = null, $customer_data = null)
    {

    }

    public function cancel()
    {

    }

    public function refund()
    {

    }

    public function auth()
    {

    }

    public function capture()
    {

    }

    public function payment()
    {

    }

    public function void()
    {

    }

    public function paymentForm()
    {
        //TODO
        $success_back_url = wa()->getRouteUrl('shop/checkout/success', true);
    }
}
