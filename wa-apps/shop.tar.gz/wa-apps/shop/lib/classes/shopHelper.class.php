<?php
class shopHelper
{
    /**
     *
     * Get HTML icon view
     * @param string $icon type
     * @param string $default icon type
     * @param int $size 10|16
     * @return string HTML
     */
    public static function getIcon($icon, $default = null, $size = 16, $params = array())
    {
        if (!$icon && $default) {
            $icon = $default;
        }
        $class = isset($params['class'])? ' '.htmlentities($params['class'], ENT_QUOTES,'utf-8') : '';

        if ($icon) {
            if (preg_match('/^icon\.([\d\w_\-]+)$/', $icon, $matches)) {
                $size = ($size == 16) ? 16 : 10;
                $icon = "<i class='icon{$size} {$matches[1]}{$class}'></i>";
            } else if(preg_match('@[\\/]+@',$icon)) {
                $size = max(10, min(16, $size));
                $icon = "<i class='icon{$size} {$class}' style='background: url({$icon})'></i>";
            } else {
                $size = ($size == 16) ? 16 : 10;
                $icon = "<i class='icon{$size} {$icon}{$class}'></i>";
            }
        }
        return $icon;
    }

    public static function getPaymentMethods()
    {
        $plugin_model = new shopPluginModel();
        return $plugin_model->listPlugins('payment');
    }

    public static function getShippingMethods($address = null, $items = array())
    {
        $plugin_model = new shopPluginModel();
        $methods = $plugin_model->listPlugins('shipping');
        if ($address !== null) {
            $result = array();
            foreach ($methods as $m) {
                $plugin = shopShipping::getPlugin($m['plugin'], $m['id']);
                $rates = $plugin->getRates($items, $address ? $address : array());
                if (is_array($rates)) {
                    foreach ($rates as $rate_id => $info) {
                        if (is_array($info)) {
                            $result[$m['id'].'.'.$rate_id] = array(
                                'plugin' => $m['plugin'],
                                'name' => $m['name'].(!empty($info['name']) ? ' ('.$info['name'].')' : ''),
                                'rate' => is_array($info['rate']) ? max($info['rate']) : $info['rate']
                            );
                        }
                    }
                }
            }
            return $result;
        } else {
            return $methods;
        }
    }

    public static function getImageBadgeHtml($image)
    {
        if (!isset($image['badge_type'])) {
            return '';
        }
        if (shopProductImagesModel::isCustomBadgeType($image['badge_type'])) {
            return isset($image['badge_code']) ? $image['badge_code'] : '';
        }
        return shopProductImagesModel::getBadgeCode($image['badge_type']);
    }

    public static function workupOrders(&$orders, $single = false)
    {
        if ($single) {
            $orders = array($orders);
        }

        $items_count = 4;
        $currency = wa('shop')->getConfig()->getCurrency();

        $workflow = new shopWorkflow();
        $states = $workflow->getAllStates();
        foreach ($orders as &$order) {
            $order['id_str'] = self::encodeOrderId($order['id']);
            $order['total_str'] = wa_currency($order['total'], $order['currency']);
            if (!empty($order['create_datetime'])) {
                $order['create_datetime_str'] = wa_date('humandatetime', $order['create_datetime']);
            }
            $state = isset($states[$order['state_id']]) ? $states[$order['state_id']] : null;

            if (!empty($order['items'])) {
                $items_str = '';
                $i = 0;
                foreach ($order['items'] as $item) {
                    if ($i >= $items_count) {
                        break;
                    }
                    $items_str .= ', '.$item['name'];
                    if ($item['type'] == 'product') {
                        $items_str .= ' x '.$item['quantity'];
                    }
                    $i += 1;
                }
                $order['items_str'] = substr($items_str, 2);
            }
            if (!$single && isset($order['items'])) {
                unset($order['items']);
            }

            $icon = '';
            $style = '';
            if ($state) {
                $icon = $state->getOption('icon');
                $style = $state->getStyle();
            }
            $order['icon'] = $icon;
            $order['style'] = $style;

            if (isset($order['params'])) {
                // shipping_address_formatted
                $shipping_address = self::getOrderAddress($order['params'], 'shipping');
                $formatter = new waContactAddressOneLineFormatter();
                $order['shipping_address_formatted'] = $formatter->format(array('data' => $shipping_address));
                $order['shipping_address_formatted'] = $order['shipping_address_formatted']['value'];

                // Shipping and payment method names
                if (isset($order['params']['shipping_name'])) {
                    $order['shipping_name'] = htmlspecialchars($order['params']['shipping_name']);
                } else {
                    $order['shipping_name'] = '<span class="hint">'._w('not specified').'</span>';
                }
                if (isset($order['params']['payment_name'])) {
                    $order['payment_name'] = htmlspecialchars($order['params']['payment_name']);
                } else {
                    $order['payment_name'] = '<span class="hint">'._w('not specified').'</span>';
                }
            }
        }

        if ($single) {
            $orders = $orders[0];
            return $orders;
        }
    }

    public static function getOrderAddress($order_params, $addr_type)
    {
        $address = array();
        foreach(waContactFields::get('address')->getFields() as $k => $v) {
            $address[$k] = ifset($order_params[$addr_type.'_address.'.$k]);
        }
        return $address;
    }

    public static function encodeOrderId($id)
    {
        return str_replace('%id%', $id, wa('shop')->getConfig()->getOrderFormat());
    }

    public static function decodeOrderId($id)
    {
        $format = wa('shop')->getConfig()->getOrderFormat();
        $format = '/^'.str_replace('%id%', '(\d+)', preg_quote($format)).'$/';
        if (preg_match($format, $id, $m)) {
            return $m[1];
        }
        return '';
    }

    public static function getCustomerForm($id = null)
    {
        $settings = wa('shop')->getConfig()->getCheckoutSettings();
        if (!isset($settings['contactinfo'])) {
            $settings = wa('shop')->getConfig()->getCheckoutSettings(true);
        }
        $form = waContactForm::loadConfig($settings['contactinfo']['fields'], array(
            'namespace' => 'customer'
        ));
        if ($id) {
            $form->setValue(new waContact($id));
        }
        return $form;
    }

    /**
     * Suggest url from string
     * @param string $str
     * @param boolean $strict
     * @return string
     */
    public static function transliterate($str, $strict = true)
    {
        $str = preg_replace('/\s+/', '-', $str);
        if ($str) {
            foreach (waLocale::getAll() as $lang) {
                $str = waLocale::transliterate($str, $lang);
            }
        }
        $str = preg_replace('/[^a-zA-Z0-9_-]+/', '', $str);
        if ($strict && !$str) {
            $str = date('Ymd');
        }
        return strtolower($str);
    }
}
