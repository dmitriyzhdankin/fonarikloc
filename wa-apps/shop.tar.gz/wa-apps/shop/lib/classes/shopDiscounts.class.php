<?php

class shopDiscounts
{
    /**
     * @param array $order items, total
     * @return float total discount value in currency of the order
     */
    public static function calculate(&$order, $apply = false)
    {
        $applicable_discounts = array();
        $contact = self::getContact($order);

        // Discount by contact category applicable?
        if (self::isEnabled('category')) {
            $applicable_discounts[] = self::byCategory($order, $contact, $apply);
        }

        // Discount by coupon applicable?
        if (self::isEnabled('coupons')) {
            $applicable_discounts[] = self::byCoupons($order, $contact, $apply);
        }

        // !!! TODO: Plugin hook for discounts

        // Select max discount or sum depending on global setting.
        if ($applicable_discounts = array_filter($applicable_discounts, 'is_numeric')) {
            if (wa()->getSetting('discounts_combine') == 'sum') {
                return (float) array_sum($applicable_discounts);
            } else {
                return (float) max($applicable_discounts);
            }
        }
    }

    /**
     * @param array $order
     * @return float total discount value in currency of the order
     */
    public static function apply(&$order)
    {
        return self::calculate($order, true);
    }

    public static function isEnabled($discount_type)
    {
        return !empty($discount_type) && wa()->getSetting('discount_'.$discount_type);
    }

    /** Discounts by category implementation. */
    protected static function byCategory($order, $contact, $apply)
    {
        if (!$contact) {
            return 0;
        }

        $ccdm = new shopContactCategoryDiscountModel();
        return $ccdm->getByContact($contact->getId()) * $order['total'] / 100.0;
    }

    /** Coupon discounts implementation. */
    protected static function byCoupons(&$order, $contact, $apply)
    {
        $checkout_data = wa()->getStorage()->read('shop/checkout');
        if (empty($checkout_data['coupon_code'])) {
            return 0;
        }

        $cm = new shopCouponModel();
        $coupon = $cm->getByField('code', $checkout_data['coupon_code']);
        if (!$coupon || !shopCouponsAction::isEnabled($coupon)) {
            return 0;
        }

        switch ($coupon['type']) {
            case '$FS':
                // 'Free shipping' coupons are processed elsewhere in checkout.
                $order['shipping'] = 0;
                $result = 0;
                break;
            case '%':
                $result = ((float) $coupon['value']) * $order['total'] / 100.0;
                break;
            default:
                // Flat value in currency
                if (wa()->getConfig()->getCurrency() == $coupon['type']) {
                    return (float) $coupon['value'];
                }
                $crm = new shopCurrencyModel();
                $result = (float) $crm->convert((float) $coupon['value'], $coupon['type'], wa()->getConfig()->getCurrency());
                break;
        }

        if ($apply) {
            $cm->useOne($coupon['id']);
            if (empty($order['params'])) {
                $order['params'] = array();
            }
            $order['params']['coupon_id'] = $coupon['id'];
            $order['params']['coupon_discount'] = $result;
        }

        return $result;
    }

    /** Helper for apply() and calculate() to get customer's waContact from order data. May return null for new customers. */
    protected static function getContact($order)
    {
        if (isset($order['contact']) && $order['contact'] instanceof waContact) {
            return $order['contact'];
        } elseif (!empty($order['contact_id'])) {
            return new waContact($order['contact_id']);
        } elseif (wa()->getEnv() == 'frontend') {
            return wa()->getUser();
        }
        return null;
    }
}
