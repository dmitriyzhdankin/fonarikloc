<?php

class shopSearch
{
    protected $options;

    public function __construct($options = array())
    {
        $this->options = $options;
    }

    public function onAdd($product_id)
    {
        // nothing
    }

    public function onUpdate($product_id)
    {
        // nothing
    }

    public function onDelete($product_id)
    {
        // nothing
    }

    public function search($query)
    {
        $model = new waModel();
        return array(
            'where' => array("p.name LIKE '".$model->escape($query, 'like')."'")
        );
    }
}