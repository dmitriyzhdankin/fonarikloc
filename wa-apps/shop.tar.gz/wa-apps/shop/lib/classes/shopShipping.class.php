<?php
class shopShipping
{
    /**
     *
     * @param string $plugin
     * @param int $plugin_id
     * @return waShipping
     */
    public static function getPlugin($plugin, $plugin_id = null)
    {
        if (!$plugin && $plugin_id) {
            $model = new shopPluginModel();
            $info = $model->getById($plugin_id);

            if (!$info) {
                throw new waException("Shipping plugin {$plugin_id} not found", 404);
            }
            if ($info['type'] != shopPluginModel::TYPE_SHIPPING) {
                throw new waException("Shipping plugin {$plugin_id} has invalid type", 404);
            }
            $plugin = $info['plugin'];
        }
        return waShipping::factory($plugin, new shopPluginSettingsModel(), $plugin_id);
    }

    public static function getPluginInfo($id)
    {
        if ($plugin_id = max(0, intval($id))) {

            $model = new shopPluginModel();
            $info = $model->getById($plugin_id);

            if (!$info) {
                throw new waException("Shipping plugin {$plugin_id} not found", 404);
            }
        } else {
            $info = array(
                'plugin' => $id,
                'status' => 1,
            );
        }
        $default_info = waShipping::info($info['plugin']);
        return array_merge($default_info, $info);
    }

    public static function savePlugin($plugin)
    {
        $model = new shopPluginModel();
        if (!empty($plugin['id']) && ($id = max(0, intval($plugin['id']))) && ($row = $model->getByField(array('id' => $id, 'type' => shopPluginModel::TYPE_SHIPPING)))) {
            $plugin['plugin'] = $row['plugin'];
            $model->updateById($plugin['id'], $plugin);
        } elseif (!empty($plugin['plugin'])) {
            $plugin['type'] = shopPluginModel::TYPE_SHIPPING;
            $plugin['id'] = $model->insert($plugin);
        }
        if (!empty($plugin['id']) && isset($plugin['settings'])) {
            $settings_model = new shopPluginSettingsModel();
            foreach ($plugin['settings'] as $name => $value) {
                $settings_model->set($plugin['id'], $name, is_array($value) ? json_encode($value) : $value);
            }
        }
        return $plugin;
    }

    public static function getList()
    {
        if(!class_exists('waShipping')) {
            throw new waException(_wp('Shipping plugins not installed yet'));
        }
        return waShipping::enumerate();
    }
}
