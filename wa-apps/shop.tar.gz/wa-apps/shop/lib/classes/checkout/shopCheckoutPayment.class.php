<?php

class shopCheckoutPayment extends shopCheckout
{
    protected $step_id = 'payment';

    public function display()
    {
        $plugin_model = new shopPluginModel();
        $methods = $plugin_model->listPlugins('payment');

        $view = wa()->getView();
        $view->assign('checkout_payment_methods', $methods);
        $view->assign('payment_id', $this->getSessionData('payment'));
    }

    public function validate()
    {


    }

    public function execute()
    {
        if ($payment_id = waRequest::post('payment_id')) {
            $this->setSessionData('payment', $payment_id);
        }
        return true;
    }
}