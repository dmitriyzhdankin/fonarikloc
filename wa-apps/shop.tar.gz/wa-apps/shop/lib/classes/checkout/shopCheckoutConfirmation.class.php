<?php

class shopCheckoutConfirmation extends shopCheckout
{
    protected $step_id = 'confirmation';

    public function display()
    {
        $cart = new shopCart();
        $items = $cart->items();

        $subtotal = $cart->total(false);
        $order = array('contact' => $this->getContact(), 'total' => $subtotal);
        $order['discount'] = shopDiscounts::calculate($order);

        $contact = $this->getContact();

        $view = wa()->getView();
        if (!$contact) {
            $view->assign('error', _w('Not enough data in the contact information to place the order.'));
            return;
        }

        $shipping_address = $contact->getFirst('address.shipping');
        $billing_address = $contact->getFirst('address.billing');

        $taxes = shopTaxes::apply($items, array('shipping' => $shipping_address['data'], 'billing' => $billing_address['data']));
        $tax = 0;
        $tax_included = 0;
        foreach ($taxes as $t) {
            $tax += $t['sum'];
            $tax_included += $t['sum_included'];
        }

        if (!isset($order['shipping'])) {
            $shipping_step = new shopCheckoutShipping();
            $rate = $shipping_step->getRate();
            if ($rate) {
                $order['shipping'] = $rate['rate'];
            } else {
                $order['shipping'] = 0;
            }
        }

        $cart_items = array();
        foreach ($items as $item) {
            if (!empty($item['services'])) {
                $services = $item['services'];
                unset($item['services']);
                $cart_items[] = $item;
                foreach ($services as $service_item) {
                    unset($service_item['id']);
                    $cart_items[] = $service_item;
                }
            } else {
                $cart_items[] = $item;
            }
        }

        $view->assign(array(
            'contact' => $contact,
            'items' => $cart_items,
            'shipping' => $order['shipping'],
            'discount' => $order['discount'],
            'total' => $subtotal - $order['discount'] + $order['shipping'] + $tax,
            'tax' => $tax_included,
            'subtotal' => $subtotal,
            'shipping_address' => $shipping_address,
            'billing_address' => $billing_address,
        ));
    }


    public function execute()
    {
        if ($comment = waRequest::post('comment')) {
            $this->setSessionData('comment', $comment);
        }
        return true;
    }
}