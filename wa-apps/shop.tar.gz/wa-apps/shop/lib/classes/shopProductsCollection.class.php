<?php

class shopProductsCollection
{
    protected $hash;
    protected $info = array();

    protected $options = array(
        'check_rights' => true
    );
    protected $prepared = false;
    protected $title;

    protected $fields = array();
    protected $where;
    protected $count;
    protected $order_by = 'p.create_datetime DESC';
    protected $group_by;
    protected $joins;

    protected $post_fields = array();

    protected $models = array();

    /**
     * Constructor for collections of photos
     *
     * @param string|array $hash
     * @param array $options
     */
    public function __construct($hash = '', $options = array())
    {
        foreach ($options as $k => $v) {
            $this->options[$k] = $v;
        }
        $this->setHash($hash);
    }

    protected function setHash($hash)
    {
        if (is_array($hash)) {
            $hash = '/id/'.implode(',', $hash);
        }
        if (substr($hash, 0, 1) == '#') {
            $hash = substr($hash, 1);
        }
        $this->hash = trim($hash, '/');
        if ($this->hash == 'all') {
            $this->hash = '';
        }
        $this->hash = explode('/', $this->hash, 2);
    }

    protected function prepare($add = false, $auto_title = true)
    {
        if (!$this->prepared || $add) {
            $type = $this->hash[0];
            if ($type) {
                $method = strtolower($type).'Prepare';
                if (method_exists($this, $method)) {
                    $this->$method(isset($this->hash[1]) ? $this->hash[1] : '', $auto_title);
                }
            } else {
                if (!empty($this->options['sort'])) {

                }
                if ($auto_title) {
                    $this->addTitle(_w('All products'));
                }
            }

            if (wa()->getEnv() == 'frontend') {
                // add filters
                $this->filters(waRequest::get());
            }

            if ($this->prepared) {
                return;
            }
            $this->prepared = true;
        }
    }

    protected function filters($data)
    {
        $delete = array('page', 'sort');
        foreach ($delete as $k) {
            if (isset($data[$k])) {
                unset($data[$k]);
            }
        }

        if (isset($data['price_min']) && $data['price_min'] !== '') {
            $this->where[] = 'p.price >= '.(int)$data['price_min'];
            unset($data['price_min']);
        }
        if (isset($data['price_max']) && $data['price_max'] !== '') {
            $this->where[] = 'p.price <= '.(int)$data['price_max'];
            unset($data['price_max']);
        }
        $feature_model = new shopFeatureModel();
        $features = $feature_model->getByField('code', array_keys($data), 'code');
        $feature_join_index = 0;
        foreach ($data as $feature_id => $values) {
            if (isset($features[$feature_id])) {
                $feature_join_index++;
                $this->joins[] = array(
                    'table' => 'shop_product_features',
                    'alias' => 'filter'.$feature_join_index
                );
                foreach ($values as &$v) {
                    $v = (int)$v;
                }
                $this->where[] = 'filter'.$feature_join_index.".feature_value_id IN (".implode(',', $values).")";
                $this->group_by = 'p.id';
            }
        }

        if ($type_id = waRequest::param('type_id')) {
            foreach ($type_id as &$t) {
                $t = (int)$t;
            }
            $this->where[] = 'p.type_id IN ('.implode(',', $type_id).')';
        }
    }


    protected function relatedPrepare($hash, $auto_title = false)
    {
        list($type, $product_id) = explode('/', $hash, 2);
        $this->joins[] = array(
            'table' => 'shop_product_related',
            'alias' => 'pr',
            'on' => 'p.id = pr.related_product_id'
        );
        $this->where[] = "pr.type = '".$this->getModel()->escape($type)."'";
        $this->where[] = 'pr.product_id = '.(int)$product_id;
    }

    /**
     * @param int $id - ID of the category
     * @param bool $auto_title
     */
    protected function categoryPrepare($id, $auto_title = true)
    {
        $category_model = $this->getModel('category');
        $category = $category_model->getById($id);

        $this->info = $category;
        $this->info['hash'] = 'category';
        $this->info['frontend_url'] = wa()->getRouteUrl('shop/frontend/category', array('category_url' => $category['full_url']), true);

        // category not found
        if (!$category) {
            $this->where[] = '0';
            return;
        }

        if ($auto_title) {
            $this->addTitle($category['name']);
        }
        if ($this->info['type'] == shopCategoryModel::TYPE_DYNAMIC) {
            if ($category['conditions']) {
                $hash = $this->hash;
                $this->setHash('/search/'.$category['conditions']);
                $this->prepare(false, false);
                while ($category['parent_id'] && $category['conditions']) {
                    $category = $category_model->getByid($category['parent_id']);
                    if ($category['conditions']) {
                        $this->setHash('/search/'.$category['conditions']);
                        $this->prepare(true, false);
                    } else {
                        $this->joins['shop_category_products'] = array(
                                'table' => 'shop_category_products',
                                'alias' => 'cp',
                        );
                        $this->where[] = "cp.category_id = ".(int)$category['id'];
                    }
                }
                $this->setHash(implode('/', $hash));
            }
            if (!empty($this->info['sort_products'])) {
                $this->order_by = $this->info['sort_products'];
            }
        } else {
            $this->joins['shop_category_products'] = array(
                'table' => 'shop_category_products',
                'alias' => 'cp',
            );
            $this->where[] = "cp.category_id = ".(int)$id;
            $this->order_by = 'cp.sort ASC';
        }
    }

    /**
     * @param int $id - ID of the set
     * @param bool $auto_title
     */
    protected function setPrepare($id, $auto_title = true)
    {
        $set_model = new shopSetModel();
        $set = $set_model->getById($id);

        if (!$set) {
            $this->where[] = '0';
            return;
        }

        $this->info = $set;

        if ($auto_title) {
            $this->addTitle($set['name']);
        }

        if ($set['type'] == shopSetModel::TYPE_STATIC) {
            $this->joins['shop_set_products'] = array(
                'table' => 'shop_set_products',
                'alias' => 'sp'
            );
            $this->where[] = "sp.set_id = '".$set_model->escape($id)."'";
            $this->order_by = 'sp.sort ASC';
        } else {
            if (!empty($set['rule'])) {
                $this->order_by = $set['rule'];
            }
        }
    }

    protected function typePrepare($id, $auto_title = true)
    {
        $type_model = new shopTypeModel();
        $type = $type_model->getById($id);
        if (!$type) {
            $this->where[] = '0';
            return;
        }
        $this->info = $type;

        if ($auto_title) {
            $this->addTitle($type['name']);
        }

        $this->where[] = "p.type_id = ".(int)$id;
    }

    protected function tagPrepare($id, $auto_title = true)
    {
        $tag_model = new shopTagModel();
        $tag = false;
        if (is_numeric($id)) {
            $tag = $tag_model->getById($id);
        }
        if (!$tag) {
            $tag = $tag_model->getByName($id);
            $id = $tag['id'];
        }
        $this->joins['tags'] = array(
            'table' => 'shop_product_tags',
            'alias' => 'pt',
        );
        $this->where[] = "pt.tag_id = ".(int)$id;
        $this->addTitle( sprintf( _w('Tagged “%s”'), $tag['name'] ) );
    }

    public static function parseConditions($query)
    {
        $escapedBS = 'ESCAPED_BACKSLASH';
        while(false !== strpos($query, $escapedBS)) {
            $escapedBS .= rand(0, 9);
        }
        $escapedAmp = 'ESCAPED_AMPERSAND';
        while(false !== strpos($query, $escapedAmp)) {
            $escapedAmp .= rand(0, 9);
        }
        $query = str_replace('\\&', $escapedAmp, str_replace('\\\\', $escapedBS, $query));
        $query = explode('&', $query);
        $result = array();
        foreach ($query as $part) {
            if (! ( $part = trim($part))) {
                continue;
            }
            $part = str_replace(array($escapedBS, $escapedAmp), array('\\\\', '\\&'), $part);
            if ($temp = preg_split("/(\\\$=|\^=|\*=|==|!=|>=|<=|=|>|<)/uis", $part, 2, PREG_SPLIT_DELIM_CAPTURE)) {
                $name = array_shift($temp);
                if ($name == 'tag') {
                    $temp[1] = explode('||', $temp[1]);
                }
                $result[$name] = $temp;
            }
        }
        return $result;
    }

    protected function upsellingPrepare($product_id, $auto_title = false)
    {
        $model = $this->getModel();
        if (isset($this->options['product'])) {
            $product = $this->options['product'];
            $conditions = $this->options['conditions'];
        } else {
            $product = new shopProduct($product_id);
            $type_upselling_model = new shopTypeUpsellingModel();
            $conditions = $type_upselling_model->getByField('type_id', $product['type'], true);
        }

        $this->where[] = 'p.id != '.(int)$product_id;

        $sum = array();

        $feature_join_index = 0;
        foreach ($conditions as $row) {
            if ($row['feature'] == 'tag') {
                $tag_model = new shopTagModel();
                $tag = $tag_model->getByName($row['value']);
                if ($tag) {
                    $this->where[] = 'pt.tag_id = '.(int)$tag['id'];
                    $this->joins[] = array(
                        'table' => 'shop_product_tags',
                        'alias' => 'pt'
                    );
                }
                continue;
            }
            switch ($row['cond']) {
                case 'between':
                    list($min, $max) = explode(',', $row['value']);
                    if ($model->fieldExists($row['feature'])) {
                        $v = $product[$row['feature']];
                    } else {
                        $v = isset($product['features'][$row['feature']]) ? $product['features'][$row['feature']] : null;
                    }
                    if (!$v) {
                        continue;
                    }
                    $min = $v * (float)(100 + $min) / 100;
                    $max = $v * (float)(100 + $max) / 100;
                    $v = str_replace(',', '.', $v);
                    if ($model->fieldExists($row['feature'])) {
                        $this->where[] = 'p.'.$row['feature'].' > '.str_replace(',', '.', $min);
                        $this->where[] = 'p.'.$row['feature'].' < '.str_replace(',', '.', $max);
                        $sum[] = 'ABS(p.'.$row['feature'].' - '.$v.')/'.$v;
                    }
                    break;
                case 'is':
                    if ($model->fieldExists($row['feature'])) {
                        $this->where[] = 'p.'.$row['feture']." = '".$model->escape($row['value'])."'";
                    } else {
                        $feature_join_index++;
                        $this->joins[] = array(
                            'table' => 'shop_product_features',
                            'alias' => 'pf'.$feature_join_index
                        );
                        $this->where[] = 'pf'.$feature_join_index.".feature_value_id = ".(int)$row['value'];
                        $this->group_by = 'p.id';
                    }
                    break;
                case 'any':
                case 'all':
                if ($model->fieldExists($row['feature'])) {
                    //$this->where[] = 'p.'.$row['feture']." = '".$model->escape($row['value'])."'";
                } else {
                    $feature_join_index++;
                    $this->joins[] = array(
                        'table' => 'shop_product_features',
                        'alias' => 'pf'.$feature_join_index
                    );
                    $this->where[] = 'pf'.$feature_join_index.".feature_value_id IN (".$row['value'].")";
                    $this->group_by = 'p.id';
                }
                break;
            }
        }
        if ($sum) {
            $this->fields[] = '('.implode(' + ', $sum).') AS upselling_deviation';
            $this->order_by = 'upselling_deviation';
        }
    }

    protected function searchPrepare($query, $auto_title = true)
    {
        $query = urldecode($query);
        $i = $offset = 0;
        $query_parts = array();
        while (($j = strpos($query, '&', $offset)) !== false ) {
            // escaped &
            if ($query[$j - 1] != '\\') {
                $query_parts[] = substr($query, $i, $j - $i);
                $i = $j + 1;
            }
            $offset = $j + 1;
        }
        $query_parts[] = substr($query, $i);

        $model = $this->getModel();
        $title = array();
        foreach ($query_parts as $part) {
            if (!($part = trim($part))) {
                continue;
            }
            $parts = preg_split("/(\\\$=|\^=|\*=|==|!=|>=|<=|=|>|<)/uis", $part, 2, PREG_SPLIT_DELIM_CAPTURE);
            if ($parts) {
                if ($parts[0] == 'category_id') {
                    if (!isset($this->joins['shop_category_products'])) {
                        $this->joins['shop_category_products'] = array(
                            'table' => 'shop_category_products',
                            'alias' => 'cp'
                        );
                    }
                    $title[] = "category_id ".$parts[1].$parts[2];
                    $this->where[] = 'cp.category_id'.$this->getExpression($parts[1], $parts[2]);
                } elseif ($parts[0] == 'query') {
                    $word_model = new shopSearchWordModel();
                    $word_ids = $word_model->getByString($parts[2]);
                    if ($word_ids) {
                        $this->joins[] = array(
                            'table' => 'shop_search_index',
                            'alias' => 'si'
                        );
                        $this->where[] = 'si.word_id IN ('.implode(",", $word_ids).')';
                        if (count($word_ids) > 1) {
                            $this->fields[] = "SUM(si.weight) AS weight";
                            $this->order_by = 'weight DESC';
                            $this->group_by = 'p.id';
                        } else {
                            $this->fields[] = "si.weight";
                            $this->order_by = 'si.weight DESC';
                        }
                    } else {
                        $this->where[] = '0';
                    }
                    $this->prepared = true;
                    // if not found try find by name
                    if (!$this->count()) {
                        if (isset($this->joins['product_images'])) {
                            $this->joins = array('product_images' => $this->joins['product_images']);
                        } else {
                            $this->joins = array();
                        }
                        $this->where = $this->fields = array();
                        $this->order_by = 'p.create_datetime DESC';
                        $this->group_by = null;
                        $this->searchPrepare("name*=".$parts[2]);
                        return;
                    }
                    $title[] = $parts[0].$parts[1].$parts[2];
                } elseif ($parts[0] == 'tag') {
                    $this->joins['tags'] = array(
                        'table' => 'shop_product_tags',
                        'alias' => 'pt',
                    );
                    $tag_model = $this->getModel('tag');
                    if (strpos($parts[2], '||') !== false) {
                        $tags = explode('||', $parts[2]);
                        $tag_ids = $tag_model->getIds($tags);
                    } else {
                        $sql = "SELECT id FROM ".$tag_model->getTableName()." WHERE name".$this->getExpression($parts[1], $parts[2]);
                        $tag_ids = $tag_model->query($sql)->fetchAll(null, true);
                    }
                    if ($tag_ids) {
                        $this->where[] = "pt.tag_id IN ('".implode("', '", $tag_ids)."')";
                    }
                } elseif ($model->fieldExists($parts[0])) {
                    $title[] = $parts[0].$parts[1].$parts[2];
                    $this->where[] = 'p.'.$parts[0].$this->getExpression($parts[1], $parts[2]);
                }
            }
        }
        if ($title) {
            $title = implode(', ', $title);
            // Strip slashes from search title.
            $bs = '\\\\';
            $title = preg_replace("~{$bs}(_|%|&|{$bs})~", '\1', $title);
        }
        if ($auto_title) {
            $this->addTitle($title, ' ');
        }
    }

    /**
     * Returns expression for SQL
     *
     * @param string $op - operand ==, >=, etc
     * @param string $value - value
     * @return string
     */
    protected function getExpression($op, $value)
    {
        $model = $this->getModel();
        switch ($op) {
            case '>':
            case '>=':
            case '<':
            case '<=':
            case '!=':
                return " ".$op." '".$model->escape($value)."'";
            case "^=":
                return " LIKE '".$model->escape($value, 'like')."%'";
            case "$=":
                return " LIKE '%".$model->escape($value, 'like')."'";
            case "*=":
                return " LIKE '%".$model->escape($value, 'like')."%'";
            case "==":
            case "=";
            default:
                return " = '".$model->escape($value)."'";
        }
    }


    protected function getFields($fields)
    {
        $model = $this->getModel();
        if ($fields == '*') {
            return 'p.*'.($this->fields ? ",".implode(",", $this->fields) : '');
        }

        $required_fields = array('id' => 'p'); // field => table, to be added later in any case

        if (!is_array($fields)) {
            $fields = explode(",", $fields);
            $fields = array_map('trim', $fields);
        }

        // Add required fields to select and delete fields for getting data after query
        foreach ($fields as $i => $f) {
            if ($f == '*') {
                $fields[$i] = 'p.*';
                continue;
            }
            if (!$model->fieldExists($f)) {
                if ($f == 'images' || $f == 'image' || $f === 'frontend_url') {
                    $this->post_fields['_internal'][] = $f;
                }
                if (!in_array($f, array('pi.badge_type', 'pi.badge_code'))) {
                    unset($fields[$i]);
                }
                continue;
            }

            if (isset($required_fields[$f])) {
                $fields[$i] = ($required_fields[$f] ? $required_fields[$f]."." : '').$f;
                unset($required_fields[$f]);
            }
        }

        foreach ($required_fields as $field => $table) {
            $fields[] = ($table ? $table."." : '').$field;
        }
        if ($this->fields) {
            foreach ($this->fields as $f) {
                $fields[] = $f;
            }
        }

        return implode(",", $fields);
    }

    /**
     * Returns ORDER BY clause
     * @return string
     */
    protected function getOrderBy()
    {
        if ($this->order_by) {
            return " ORDER BY ".$this->order_by;
        } else {
            return "";
        }
    }


    /**
     * Returns GROUP BY clause
     * @return string
     */
    protected function getGroupBy()
    {
        if ($this->group_by) {
            return " GROUP BY ".$this->group_by;
        } else {
            return "";
        }
    }


    /**
     * Set order by clause for select
     *
     * @param string|array $field It is possible pass array with field and order
     * @param string $order
     * @return string
     */
    public function orderBy($field, $order = 'ASC')
    {
        if (is_array($field)) {
            if (count($field) > 1) {
                list($field, $order) = $field;
            } else {
                $field = $field[0];
            }
        }
        if (strtolower(trim($order)) == 'desc') {
            $order = 'DESC';
        } else {
            $order = 'ASC';
        }
        $field = trim($field);
        if ($field) {
            //$this->prepare();
            if (strpos($field, '.') === false) {
                $model = $this->getModel();
                if ($model->fieldExists($field)) {
                    $this->getSQL();
                    return $this->order_by = 'p.'.$field." ".$order;
                }
            } else {
                $this->getSQL();
                return $this->order_by = $field.' '.$order;
            }
        }
        return '';
    }

    public function getSQL()
    {
        $this->prepare();
        $sql = "FROM shop_product p";

        if ($this->joins) {
            foreach ($this->joins as $join) {
                $alias = isset($join['alias']) ? $join['alias'] : '';
                if (isset($join['on'])) {
                    $on = $join['on'];
                } else {
                    $on = "p.id = ".($alias ? $alias : $join['table']).".product_id";
                }
                $sql .= (isset($join['type']) ? " ".$join['type'] : '')." JOIN ".$join['table']." ".$alias." ON ".$on;
            }
        }

        $where = $this->where;

        if ($where) {
            $sql .= " WHERE ".implode(" AND ", $where);
        }
        return $sql;
    }

    public function count()
    {
        if ($this->count) {
            return $this->count;
        }
        $sql = $this->getSQL();
        $sql = "SELECT COUNT(".($this->joins ? 'DISTINCT ' : '')."p.id) ".$sql;
        $count = (int)$this->getModel()->query($sql)->fetchField();

        $type = $this->hash[0];
        if ($type == 'category') {
            if ($this->info['count'] != $count) {
                $this->getModel('category')->updateById($this->hash[1], array('count' => $count));
            }
        } else if ($type == 'set') {
            if ($this->info['type'] == shopSetModel::TYPE_DYNAMIC) {
                $count = min($this->info['count'], $count);
            } else if ($this->info['count'] != $count) {
                $this->getModel('set')->updateById($this->hash[1], array('count' => $count));
            }
        }
        return $this->count = $count;
    }

    public function getProducts($fields = "*", $offset = 0, $limit = null, $escape = true)
    {
        if (is_bool($limit)) {
            $escape = $limit;
            $limit = null;
        }
        if ($limit === null) {
            if ($offset) {
                $limit = $offset;
                $offset = 0;
            } else {
                $limit = 50;
            }
        }
        if (wa()->getEnv() == 'frontend' && $fields == '*') {
            $fields .= ',frontend_url,pi.badge_type,pi.badge_code';
            $this->joins['product_images'] = array(
                'table' => 'shop_product_images',
                'type' => 'left',
                'alias' => 'pi',
                'on' => 'p.image_id = pi.id'
            );
        }

        $sql = $this->getSQL();
        if ($this->hash[0] == 'set' && $this->count !== null) { // for dynamic sets
            if ($offset + $limit > $this->count) {
                $limit = $this->count - $offset;
            }
        }
        $sql = "SELECT ".($this->joins && !$this->group_by ? 'DISTINCT ' : '').$this->getFields($fields)." ".$sql;
        $sql .= $this->getGroupBy();
        $sql .= $this->getOrderBy();
        $sql .= " LIMIT ".($offset ? $offset.',' : '').(int)$limit;
        $data = $this->getModel()->query($sql)->fetchAll('id');
        if (!$data) {
            return array();
        }
        $this->workupProducts($data, $escape);
        return $data;
    }

    private function workupProducts(&$products = array(), $escape)
    {
        foreach ($products as &$p) {
            $p['min_price'] = (float)$p['min_price'];
            $p['max_price'] = (float)$p['max_price'];

            // escape
            if ($escape) {
                $p['name'] = htmlspecialchars($p['name']);
                $p['url']  = htmlspecialchars($p['url']);
            }
        }
        if ($this->post_fields) {
            $ids = array_keys($products);
            foreach ($this->post_fields as $table => $fields) {
                if ($table == '_internal') {
                    foreach ($fields as $i => $f) {
                        if ($f == 'images' || $f == 'image') {
                            if ($f == 'images') {
                                $product_images_model = new shopProductImagesModel();
                                $product_images = $product_images_model->getImages($ids, 'thumb', 'product_id');
                                foreach ($product_images as $product_id => $images) {
                                    $products[$product_id]['images'] = $images;
                                }
                            } else if ($f == 'image') {
                                $size = wa('shop')->getConfig()->getImageSize('thumb');
                                foreach ($products as &$p) {
                                    if ($p['image_id']) {
                                        $p['image']['thumb_url'] = shopImage::getUrl(array(
                                            'id' => $p['image_id'],
                                            'product_id' => $p['id'],
                                            'ext' => $p['ext'],
                                        ), $size);
                                    }
                                }
                            }
                        } elseif ($f == 'frontend_url') {
                            foreach ($products as &$p) {
                                $p['frontend_url'] = wa()->getRouteUrl('shop/frontend/product', array('product_url' => $p['url']));
                            }
                            unset($p);
                        }

                    }
                }
            }
        }
    }

    /**
     * @return shopProductModel
     */
    protected function getModel($name = 'product')
    {
        if (!isset($this->models[$name])) {
            if ($name == 'product') {
                $this->models[$name] = new shopProductModel();
            } elseif ($name == 'category') {
                $this->models[$name] = new shopCategoryModel();
            } else if ($name == 'set') {
                $this->models[$name] = new shopSetModel();
            } elseif ($name == 'tag') {
                $this->models[$name] = new shopTagModel();
            }
        }
        return $this->models[$name];
    }

    public function getTitle()
    {
        if ($this->title === null) {
            $this->prepare();
        }
        return $this->title;
    }

    public function getInfo()
    {
        if (empty($this->info)) {
            $this->prepare();
        }
        if (!isset($this->info['hash'])) {
            $this->info['hash'] = $this->hash[0];
        }
        return $this->info;
    }

    public function addTitle($title, $delim = ', ')
    {
        if (!$title) {
            return;
        }
        if ($this->title) {
            $this->title .= $delim;
        }
        $this->title .= $title;
    }
}
