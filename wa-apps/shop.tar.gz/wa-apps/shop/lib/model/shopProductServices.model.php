<?php

class shopProductServicesModel extends waModel
{
    protected $table = 'shop_product_services';

    const STATUS_FORBIDDEN = '0';
    const STATUS_PERMITTED = '1';    // default in table
    const STATUS_DEFAULT   = '2';

    private $product;
    private $service;
    /**
     * @var shopProductModel
     */
    private $product_model;

    /**
     * @var shopServiceModel
     */
    private $service_model;

    /**
     * @param array $products
     */
    public function deleteByProducts(array $products)
    {
        $this->deleteByField('product_id', $products);
    }

    public function getServiceIds($product_id)
    {
        $sql = "SELECT DISTINCT(service_id) FROM ".$this->table." WHERE product_id = i:product_id";
        return $this->query($sql, array('product_id' => $product_id))->fetchAll(null, true);
    }

    public function getByProducts($product_ids, $hierarchy = false)
    {
        if (!$product_ids) {
            return array();
        }
        $sql = "SELECT * FROM ".$this->table." WHERE product_id IN (i:ids) ORDER BY sku_id, service_variant_id";
        $rows = $this->query($sql, array('ids' => $product_ids))->fetchAll();
        if (!$hierarchy) {
            return $rows;
        }
        $result = array();
        foreach ($rows as $row) {
            $s_id = $row['service_id'];
            $v_id = $row['service_variant_id'];
            if (!$v_id) {
                if (!$row['sku_id']) {
                    $result[$row['product_id']][$row['service_id']] = $row;
                } else {
                    if ($row['price'] === null && isset($result[$row['product_id']][$row['service_id']])) {
                        $row['price'] = $result[$row['product_id']][$row['service_id']]['price'];
                    }
                    $result[$row['product_id']]['skus'][$row['sku_id']][$row['service_id']] = $row;
                }
            } else {
                if (!$row['sku_id']) {
                    if ($row['price'] === null && isset($result[$row['product_id']][$s_id])) {
                        $row['price'] = $result[$row['product_id']][$s_id]['price'];
                    }
                    $result[$row['product_id']][$row['service_id']]['variants'][$v_id] = $row;
                } else {
                    if ($row['price'] === null && isset($result[$row['product_id']][$s_id]['variants'][$v_id])) {
                        $row['price'] = $result[$row['product_id']][$s_id]['variants'][$v_id]['price'];
                    }
                    $result[$row['product_id']]['skus'][$row['sku_id']][$s_id]['variants'][$v_id] = $row;
                }
            }
        }
        return $result;
    }

    public function save($product_id, $service_id, $data)
    {
        $data_for_save = array(
            'update' => array(),
            'insert' => array()
        );
        $product_id = (int)$product_id;
        $service_id = (int)$service_id;
        $key = array('product_id' => $product_id, 'service_id' => $service_id);

        $old_data = $this->getProductService($product_id, $service_id);
        if (!$old_data['variants']) {
            $this->prepareItemForSave($data[$service_id], $old_data['service'],
                $key, $data_for_save
            );
            $this->prepareSkusForSave($data[$service_id]['skus'], $old_data['service']['skus'],
                $key, $data_for_save
            );
        } else {
            foreach ($old_data['variants'] as $variant_id => $variant) {
                $key['service_variant_id'] = $variant_id;
                $this->prepareItemForSave($data[$variant_id], $variant,
                    $key, $data_for_save
                );
                $this->prepareSkusForSave($data[$variant_id]['skus'], $variant['skus'],
                    $key, $data_for_save
                );
            }
        }
        if ($data_for_save['insert'] && $old_data['service']['fake']) {
            $has_already = false;
            foreach ($data_for_save['insert'] as $item) {
                if ($item['sku_id'] === null && $item['service_variant_id'] === null) {  //has already (product_id, service_id) for
                    $has_already = true;
                    break;
                }
            }
            if (!$has_already) {
                $data_for_save['insert'][] = $this->formatKey(array(
                    'product_id' => $product_id,
                    'service_id' => $service_id)
                ) + $this->extractItem();
            }
        }
        foreach ($data_for_save['update'] as $item) {
            $this->updateByField($item['where'], $item['data']);
        }
        $this->multiInsert($data_for_save['insert']);

        $this->correctProductStatus($product_id, $service_id);
        $this->converPrimaryPrices($product_id, $service_id);
    }

    private function correctProductStatus($product_id, $service_id)
    {
        // if all items to this product_id and service_id have status 0,
        //      than make this product with status 0
        // otherwise make this product with status 1

        $sql = "SELECT MAX(status) status FROM `{$this->table}`
                WHERE product_id = $product_id AND service_id = $service_id
                    AND !(sku_id IS NULL AND service_variant_id IS NULL)";
        $status = $this->query($sql)->fetchField('status');
        if ($status !== false) {
            $this->updateByField(
                $this->formatKey("product_id=$product_id,service_id=$service_id"),
                array('status' => (int)($status > 0))
            );
        }
    }

    public function getProductStatus($product_id, $service_id)
    {
        $item = $this->getByField($this->formatKey("product_id=$product_id,service_id=$service_id"));
        return $item['status'];
    }

    private function converPrimaryPrices($product_id, $service_id)
    {
        // conver inner pirce (primary_price) of itself
        $sql = "UPDATE `{$this->table}` ps
            JOIN `shop_service` ss ON ss.id = ps.service_id
            JOIN `shop_currency` c ON c.code = ss.currency
            SET ps.primary_price = ps.price*c.rate
            WHERE ps.product_id = $product_id AND ps.service_id = $service_id AND ps.price IS NOT NULL";
        $this->exec($sql);
    }

    private function extractItem($data = array())
    {
        $item = array();
        $item['price'] = isset($data['price']) ? $data['price'] : null;
        if (isset($data['fake']) && $data['fake']) {
            $item['status'] = null;
        } else {
            $item['status'] = isset($data['status']) ? $data['status'] : self::STATUS_PERMITTED;
        }
        return $item;
    }

    private function parseStringKey($str)
    {
        $key = array();
        foreach (explode(',', $str) as $value) {
            $v = explode('=', $value);
            $key[trim($v[0])] = trim($v[1]);
        }
        return $key;
    }

    private function formatKey($key)
    {
        if (is_string($key)) {
            $key = $this->parseStringKey($key);
        }
        $formatted = array(
            'product_id' => $key['product_id'],
            'sku_id' => null,
            'service_id' => $key['service_id'],
            'service_variant_id' => null
        );
        if (isset($key['sku_id'])) {
            $formatted['sku_id'] = $key['sku_id'];
        }
        if (isset($key['service_variant_id'])) {
            $formatted['service_variant_id'] = $key['service_variant_id'];
        }
        return $formatted;
    }

    private function prepareSkusForSave($skus, $old_skus, $key, &$context_for_save)
    {
        foreach ($old_skus as $sku_id => $sku) {
            $key['sku_id'] = $sku_id;
            $this->prepareItemForSave($skus[$sku_id], $sku, $key, $context_for_save);
        }
    }

    private function prepareItemForSave($item, $old_item, $key, &$context_for_save)
    {
        $key  = $this->formatKey($key);
        $item = $this->extractItem($item);
        $diff = array_diff_assoc($item, $this->extractItem($old_item));
        if ($diff) {
            if ($old_item['fake']) {
                $context_for_save['insert'][] = $key + $item;
            } else {
                $context_for_save['update'][] = array('data' => $diff, 'where' => $key);
            }
        }
    }

    private function getProduct($product_id) {
        if (!$this->product || $this->product['id'] != $product_id) {
            $this->product = $this->getProductModel()->getById($product_id);
        }
        return $this->product;
    }

    private function countServicesQuery($product_id)
    {
        $product_id = (int)$product_id;
        $product = $this->getProduct($product_id);
        if (!$product) {
            return false;
        }
        return "SELECT COUNT(s.id) AS cnt
            FROM `shop_service` s
                LEFT JOIN `{$this->table}` ps ON s.id = ps.service_id AND product_id = $product_id
                LEFT JOIN `shop_type_services` ts ON s.id = ts.service_id AND type_id ".($product['type_id'] ? " = {$product['type_id']}" : " IS NULL")."
            WHERE ps.service_variant_id IS NULL AND ps.sku_id IS NULL AND
                (ps.product_id IS NOT NULL OR ts.type_id IS NOT NULL) AND
                (ps.status IS NULL OR ps.status != ".self::STATUS_FORBIDDEN.")";
    }

    private function getServicesQuery($product_id, $service_id, $just_own = false)
    {
        $product_id = (int)$product_id;
        $service_id = (int)$service_id;
        $product = $this->getProduct($product_id);
        if (!$product) {
            return false;
        }
        return "SELECT s.id, s.name, s.variant_id, s.price AS base_price, s.currency".(!$just_own ? ', ps.product_id, ps.price, ps.status' : '').", ts.type_id
            FROM `shop_service` s
                LEFT JOIN `{$this->table}` ps ON s.id = ps.service_id AND product_id = $product_id
                LEFT JOIN `shop_type_services` ts ON s.id = ts.service_id AND type_id ".($product['type_id'] ? " = {$product['type_id']}" : " IS NULL")."
            WHERE ps.service_variant_id IS NULL AND ps.sku_id IS NULL ".
                ($service_id ? "AND s.id = $service_id" : "").
                ($just_own ? "(AND ps.product_id IS NOT NULL OR ts.type_id IS NOT NULL)" : '');
    }

    private function getProductService($product_id, $service_id)
    {
        $product = $this->getProduct($product_id);
        if (!$product) {
            return array();
        }
        $service = $this->getService($product_id, $service_id);
        if (!$service) {
            return array();
        }
        $service['fake'] = !$service['product_id'];

        $product_skus_model = new shopProductSkusModel();
        $skus = $product_skus_model->getByField('product_id', $product_id, 'id');

        $variants = $this->getVariants($product_id, $service_id);
        if (!$variants) {
            $service['skus'] = $this->getSkus($product_id, $service_id);
            foreach ($skus as $sku_id => $sku) {
                if (empty($service['skus'][$sku_id])) {
                    $service['skus'][$sku_id] = array(
                        'id' => $service['id'], 'sku_id' => $sku_id, 'price' => null, 'fake' => true
                    );
                } else {
                    $service['skus'][$sku_id]['fake'] = false;
                }
                $service['skus'][$sku_id]['name'] = $sku['name'];
            }
        } else {
            foreach ($variants as &$variant) {
                $variant['fake'] = !($variant['product_id'] && !$variant['sku_id']);
                foreach ($skus as $sku_id => $sku) {
                    if (empty($variant['skus'][$sku_id])) {
                        $variant['skus'][$sku_id] = array(
                            'id' => $variant['id'], 'sku_id' => $sku_id, 'price' => null, 'fake' => true
                        );
                    } else {
                        $variant['skus'][$sku_id]['fake'] = false;
                    }
                    $variant['skus'][$sku_id]['name'] = $sku['name'];
                }
                unset($variant);
            }
        }
        return array('service' => $service, 'variants' => $variants);
    }

    public function getProductServicesFullInfo($product_id, $sku_id = null)
    {
        $product_id = (int)$product_id;
        $product = $this->getProduct($product_id);
        if (!$product) {
            return array();
        }
        $sql = "SELECT s.id, s.name, s.variant_id, s.price AS base_price, s.currency, ps.product_id, ps.price, ps.status, ts.type_id
                FROM `shop_service` s
                    LEFT JOIN `{$this->table}` ps ON s.id = ps.service_id AND product_id = $product_id
                    LEFT JOIN `shop_type_services` ts ON s.id = ts.service_id AND type_id ".($product['type_id'] ? " = {$product['type_id']}" : " IS NULL")."
                WHERE ps.sku_id IS NULL AND ps.service_variant_id IS NULL
                    AND !(ps.product_id IS NULL AND ts.type_id IS NULL) AND (ps.status IS NULL OR ps.status != 0)
                    ORDER BY s.id, ps.product_id, ps.service_variant_id";
        $services = $this->query($sql)->fetchAll('id');
        if (empty($services)) {
            return array();
        }

        foreach ($services as &$service) {
            $service['price'] = $service['price'] ? $service['price'] : $service['base_price'];
            $service['price'] = (float) $service['price'];
        }

        $product_id = (int)$product_id;
        $sku_id = (int)$sku_id;

        $sql = "SELECT
                sv.id, sv.service_id, sv.name, sv.price AS base_price, ps.product_id, ps.sku_id, ps.price, ps.status
            FROM `shop_service_variants` sv
            LEFT JOIN `{$this->table}` ps ON sv.id = ps.service_variant_id AND ps.product_id = $product_id
            WHERE
                sv.service_id IN (".implode(',', array_keys($services)).") AND ".
                ($sku_id ? "(ps.sku_id IS NULL OR ps.sku_id = $sku_id)" : "ps.sku_id IS NULL")."
                ORDER BY sv.service_id, sv.id, ps.sku_id";
        $service_id = 0;
        foreach ($this->query($sql) as $item) {
            if ($item['service_id'] != $service_id) {
                $service_id = $item['service_id'];
                if (!$item['status'] && $item['status'] !== null) {
                    continue;
                }
                $services[$service_id]['variants'] = array(
                    $item['id'] => array(
                        'id' => $item['id'],
                        'name' => $item['name'],
                        'price' => (float) ($item['price'] !== null ? $item['price'] : $item['base_price']),
                        'status' => $item['status']
                    )
                );
                continue;
            }
            if ($item['sku_id'] === null) {
                $services[$service_id]['variants'][$item['id']] = array(
                    'id' => $item['id'],
                    'name' => $item['name'],
                    'price' => (float) ($item['price'] !== null ? $item['price'] : $item['base_price']),
                    'status' => $item['status']
                );
            } else if (isset($services[$service_id]['variants'][$item['id']])) {
                if ($item['status'] !== null && $item['status'] == 0) {
                    unset($services[$service_id]['variants'][$item['id']]);
                } else {
                    $services[$service_id]['variants'][$item['id']]['price'] = (float) ($item['price'] !== null ? $item['price'] : $item['base_price']);
                }
            }
        }
        return $services;
    }

    public function getProductServiceFullInfo($product_id, $service_id)
    {
        $data = $this->getProductService($product_id, $service_id);
        $service  = &$data['service'];
        $variants = &$data['variants'];

        if ($service['status'] === null) {
            if ($service['product_id'] || $service['type_id']) {
                $service['status'] = self::STATUS_PERMITTED;
            } else {
                $service['status'] = self::STATUS_FORBIDDEN;
            }
        }

        if (!$variants) {
            foreach ($service['skus'] as $sku_id => &$item) {
                $item['base_price'] = $service['price'] !== null ? $service['price'] : $service['base_price'];
                if ($item['fake']) {
                    $item['status'] = $service['status'] ? self::STATUS_PERMITTED : self::STATUS_FORBIDDEN;
                }
                unset($item);
            }
        } else {
            foreach ($variants as &$variant) {
                $variant['base_price'] = $variant['base_price'] !== null ? $variant['base_price'] : $service['base_price'];
                if ($variant['status'] === null) {
                    $variant['status'] = $service['type_id'] ? self::STATUS_PERMITTED : self::STATUS_FORBIDDEN;
                }
                foreach ($variant['skus'] as $sku_id => &$item) {
                    $item['base_price'] = $variant['price'] !== null ? $variant['price'] : $variant['base_price'];
                    if ($item['fake']) {
                        $item['status'] = $service['type_id'] ? self::STATUS_PERMITTED : self::STATUS_FORBIDDEN;
                    } else {
                        if (!$variant['status']) {
                            $item['status'] = self::STATUS_FORBIDDEN;
                        }
                    }
                    unset($item);
                }
                unset($variant);
            }
            $this->setDefaultVariant($variants, $service['variant_id']);

        }
        return $data;
    }
    private function setDefaultVariant(&$variants, $default_variant_id)
    {
        $default = 0;
        $overridden = 0;
        foreach ($variants as $variant_id => &$variant) {
            if ($variant_id == $default_variant_id) {
                $default = $default_variant_id;
            }
            if ($variant['status'] == self::STATUS_DEFAULT) {
                $overridden = $variant_id;
                break;
            }
        }
        unset($variant);

        if (!$overridden) {
            if ($default && $variants[$default]['status'] == self::STATUS_PERMITTED) {
                $variants[$default]['status'] = self::STATUS_DEFAULT;
            } else {
                foreach ($variants as &$variant) {
                    if ($variant['status'] == self::STATUS_PERMITTED) {
                        $variant['status'] = self::STATUS_DEFAULT;
                        break;
                    }
                }
            }
        }
    }

    public function countServices($product_id)
    {
        $sql = $this->countServicesQuery($product_id);
        return $sql ? $this->query($sql)->fetchField('cnt') : 0;
    }

    public function getServices($product_id, $just_own = false)
    {
        $sql = $this->getServicesQuery($product_id, null, $just_own);
        return $sql ? $this->query($sql)->fetchAll('id') : array();
    }

    public function getService($product_id, $service_id)
    {
        if (!$this->service || $this->service['id'] != $service_id) {
            $sql = $this->getServicesQuery($product_id, $service_id, false);
            if (!$sql) {
                return false;
            }
            $this->service = $this->query($sql)->fetchAssoc();
        }
        $primary_currency = wa('shop')->getConfig()->getCurrency();
        $this->service['currency'] = $this->service['currency'] !== null ? $this->service['currency'] : $primary_currency;
        return $this->service;
    }

    public function getVariants($product_id, $service_id, $just_own = false, $just_product = false)
    {
        $product_id = (int)$product_id;
        $service_id = (int)$service_id;

        $join = !$just_own ? ' LEFT JOIN' : ' JOIN';

        $sql = "SELECT sv.id, sv.service_id, sv.name, sv.price AS base_price ".(!$just_own ? ', ps.product_id, ps.sku_id, ps.price, ps.status' : '')."
            FROM `shop_service_variants` sv
            $join `{$this->table}` ps ON sv.id = ps.service_variant_id AND ps.product_id = $product_id
            WHERE sv.service_id = $service_id";

        if ($just_product) {
            $sql .= " AND ps.sku_id IS NULL";
        }
        $sql .= " ORDER BY sv.id";
        if ($just_product) {
            return $this->query($sql)->fetchAll('sv.id');
        } else {
            $sku_id = 0;
            $variant_id = 0;
            $data = array();
            foreach ($this->query($sql.", ps.sku_id") as $item) {
                if ($variant_id != $item['id']) {
                    $variant_id = $item['id'];
                    $data[$variant_id] = $item;
                    $data[$variant_id]['skus'] = array();
                    if ($item['sku_id'] === null) {
                        $sku_id = 0;
                        continue;
                    }
                }
                if ($sku_id != $item['sku_id']) {
                    $sku_id = $item['sku_id'];
                }
                $data[$variant_id]['skus'][$sku_id] = $item;
            }
            return $data;
        }
    }

    public function getProducts($service_id, $status = self::STATUS_PERMITTED)
    {
        $service_id = (int)$service_id;
        $status = (int)$status;
        return $this->query("
            SELECT p.* FROM `{$this->table}` ps
            JOIN `shop_product` p ON p.id = ps.product_id
            WHERE ps.service_id = $service_id AND service_variant_id IS NULL AND ps.sku_id IS NULL
                AND ps.status = $status
            ORDER BY ps.product_id
        ")->fetchAll();
    }

    public function getSkus($product_id, $service_id)
    {
        $service_id = (int)$service_id;
        $product_id = (int)$product_id;
        return $this->query("
            SELECT ps.* FROM `{$this->table}` ps
            WHERE ps.service_id = $service_id AND ps.product_id = $product_id AND ps.sku_id IS NOT NULL AND ps.service_variant_id IS NULL
            ORDER BY ps.product_id
        ")->fetchAll('sku_id');
    }

    /**
     * @return shopProductModel
     */
    private function getProductModel()
    {
        if (!$this->product_model) {
            $this->product_model = new shopProductModel();
        }
        return $this->product_model;
    }

    /**
     * @retrun getServiceModel
     */
    private function getServiceModel()
    {
        if (!$this->service_model) {
            $this->service_model = new shopServiceModel();
        }
        return $this->service_model;
    }
}
