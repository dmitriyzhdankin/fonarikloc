<?php

class shopTaxModel extends waModel
{
    protected $table = 'shop_tax';
}

