<?php

class shopOrderItemsModel extends waModel
{
    protected $table = 'shop_order_items';

    private $currency;

    /*
     * Get items with correct order:
     *  prodct item, related services items, product items, related services items and so on
     * */
    private function _getItems($order_id)
    {
        $items = array();

        // important: order metters!

        $product_items = $this->query("
            SELECT * FROM `{$this->table}`
            WHERE order_id = ".(int)$order_id." AND type='product'
            ORDER BY id
        ")->fetchAll('id');

        $parent_id = 0;
        foreach ($this->query("
            SELECT * FROM `{$this->table}`
            WHERE order_id = ".(int)$order_id." AND type='service'
            ORDER BY parent_id, id
        ") as $item) {
            if ($parent_id != $item['parent_id']) {
                $parent_id = $item['parent_id'];
                $items[$parent_id] = $product_items[$parent_id];
                unset($product_items[$parent_id]);
            }
            $items[$item['id']] = $item;
        }
        return $items + $product_items;
    }

    public function getItems($order_id, $extend = false)
    {
        if (!$extend) {
            return $this->_getItems($order_id);
        }

        $data = array();
        $type = null;
        foreach ($this->_getItems($order_id) as $item) {
            if ($item['type'] == 'product') {
                $sku_id = $item['sku_id'];
                $product = &$data[];
                $product = $this->getProductInfo($item['product_id'], $sku_id);

                if (empty($product)) {
                    $product = array('id' => $item['product_id'], 'fake' => true, 'skus' => array());
                }

                if (!isset($product['skus'][$sku_id])) {
                    unset($product['skus']);
                    $product['skus'][$sku_id] = array('id' => $sku_id, 'fake' => true);
                } else {
                    $product['skus'][$sku_id] = array_merge(
                        $product['skus'][$sku_id],
                        $this->squeeze($item)
                    );
                }
                $product['item'] = $this->formatItem($item);
            }
            $service_id = $item['service_id'];
            $service_variant_id = $item['service_variant_id'];

            if ($service_id !== null) {
                if ($service_variant_id === null) {
                    if (!isset($product['services'][$service_id])) {
                        $product['services'][$service_id] = array(
                            'id' => $service_id,
                            'fake' => true,
                            'variants' => array()
                        );
                    }
                    $product['services'][$service_id]['item'] = $this->formatItem($item);

                } else {
                    if (!isset($product['services'][$service_id]['variants'][$service_variant_id])) {
                        $product['services'][$service_id] = array(
                            'id' => $service_id,
                            'fake' => true,
                            'variants' => array()
                        );
                    }
                    $product['services'][$service_id]['item'] = $this->formatItem($item);
                }
            }
            if (empty($product['fake'])) {
                $this->workupProduct($product);
            }
        }
        return $data;
    }

    private function getProductInfo($product_id, $sku_id = null, $order_id = null)
    {
        $product = new shopProduct($product_id);

        $data = $product->getData();
        if (!$data) {
            return array();
        }
        $data['price'] = (float)$data['price'];
        $data['max_price'] = (float)$data['max_price'];
        $data['min_price'] = (float)$data['min_price'];
        $data['skus'] = $product->skus;

        if ($sku_id === null) {
            $sku_id = count($data['skus']) > 1 ? $product->sku_id : null;
        }

        $data['services'] = $this->getModel('service')->
            getProductServicesFullInfo($product_id, $sku_id);
        return $data;
    }

    public function getProduct($product_id, $order_id = null)
    {
        $data = $this->getProductInfo($product_id, $order_id);
        $this->workupProduct($data);
        return $data;
    }

    private function workupProduct(&$product)
    {
        $primary = $this->getCurrency();
        $currency = $product['currency'];
        if ($product['min_price'] == $product['max_price']) {
            $product['price_str'] = wa_currency($product['min_price'], $primary);
        } else {
            $product['price_str'] = wa_currency($product['min_price'], $primary).'...'.wa_currency($product['max_price'], $primary);
        }
        if (!empty($product['skus']) && is_array($product['skus'])) {
            foreach ($product['skus'] as &$sku) {
                if (isset($sku['price'])) {
                    $sku['price_str'] = wa_currency($sku['price'], $currency);
                }
            }
            unset($sku);
        }
        if (!empty($product['services'])) {
            $this->workupServices($product['services']);
        }
    }

    private function workupServices(&$services)
    {
        foreach ($services as &$service) {
            if (!empty($service['variants'])) {
                $default_price = null;
                foreach ($service['variants'] as &$variant) {
                    $variant['price_str'] = ($variant['price'] >= 0 ? '+' : '-').wa_currency($variant['price'], $service['currency']);
                    if ($variant['status'] == shopProductServicesModel::STATUS_DEFAULT) {
                        $default_price = $variant['price'];
                    }
                }
                if ($default_price === null) {
                    if (isset($service['variants'][$service['variant_id']])) {
                        $default_price = $service['variants'][$service['variant_id']]['price'];
                    } else {
                        reset($service['variants']);
                        $first = current($service['variants']);
                        $default_price = $first['price'];
                    }
                }
                $service['price'] = $default_price;
                unset($variant);
            }
            if (isset($service['price'])) {
                $service['price_str'] = ($service['price'] >= 0 ? '+' : '-').wa_currency($service['price'], $service['currency']);
            }
        }
        unset($service);
    }

    public function getSku($sku_id, $order_id = null)
    {
        $data = $this->getModel('sku')->getById($sku_id);
        $data['price'] = (float)$data['price'];
        $data['price_str'] = wa_currency($data['price'], $this->getModel('product')->getCurrency($data['product_id']));
        $data['services'] = $this->getModel('service')->getProductServicesFullInfo($data['product_id'], $sku_id);
        $this->workupServices($data['services']);
        return $data;
    }

    private function getModel($name)
    {
        if ($name == 'product') {
            return new shopProductModel();;
        } else if ($name == 'sku') {
            return new shopProductSkusModel();
        } else if ($name == 'service') {
            return new shopProductServicesModel();
        } else {
            return $this;
        }
    }

    public function saveItems($items, $order_id)
    {
        $old_items = $this->getByField('order_id', $order_id, 'id');
        $add = array();
        $update = array();
        foreach ($items as $item) {
            if (empty($item['id']) || empty($old_items[$item['id']])) {

                if (!empty($item['id']) && empty($old_items[$item['id']])) {
                    unset($old_items[$item['id']]);
                }
                $add[] = $item;
            } else {
                $item_id = $item['id'];
                $item['price'] = (float)$item['price'];
                $old_items[$item_id]['price'] = (float)$old_items[$item_id]['price'];
                $diff = array_diff_assoc($item, $old_items[$item_id]);
                if (!empty($diff)) {
                    $update[$item_id] = $diff;
                }
                unset($old_items[$item_id]);
            }
        }
        foreach ($update as $item_id => $item) {
            $this->updateById($item_id, $item);
        }
        if ($add) {
            foreach ($add as &$item) {
                ksort($item);
                $item['order_id'] = $order_id;
            }
            unset($item);
            $this->multiInsert($add);
        }
        if ($old_items) {
            $this->deleteById(array_keys($old_items));
        }
    }

    public function getCurrency()
    {
        if ($this->currency === null) {
            $this->currency = wa('shop')->getConfig()->getCurrency();
        }
        return $this->currency;
    }

    public function formatItem($item)
    {
        $item['price'] = (float)$item['price'];
        return $item;
    }

    public function squeeze($item)
    {
        unset($item['product_id'], $item['sku_id'], $item['service_id'], $item['service_variant_id']);
        return $item;
    }
}