<?php

class shopCategoryProductsModel extends waModel implements shopProductStorageInterface
{
    protected $table = 'shop_category_products';
    protected $id = array('product_id', 'category_id');

    public function add($product_ids, $category_ids)
    {
        if (!$product_ids || !$category_ids) {
            return false;
        }

        $ignore = array();
        foreach (
        $this->query("
                SELECT category_id, product_id FROM {$this->table}
                WHERE " . $this->getWhereByField('product_id', $product_ids))
        as $item)
        {
            $ignore[$item['category_id']][$item['product_id']] = true;
        }

        $add = array();
        $counts = array();
        foreach ((array)$category_ids as $category_id) {
            $category_id = (int)$category_id;
            $add[$category_id] = array();
            $counts[$category_id] = 0;
            foreach ((array)$product_ids as $product_id) {
                $product_id = (int)$product_id;
                if (!isset($ignore[$category_id][$product_id])) {
                    $add[$category_id][] = array(
                        'category_id' => $category_id,
                        'product_id' => $product_id
                    );
                    $counts[$category_id] += 1;
                }
            }
            if (empty($add[$category_id])) {
                unset($add[$category_id]);
                unset($counts[$category_id]);
            }
        }

        if (!empty($add)) {
            $data = array();
            $last_sort = array();
            foreach ($this->query("
                        SELECT category_id, MAX(sort) AS sort FROM {$this->table}
                        WHERE ".$this->getWhereByField('category_id', array_keys($add))."
                        GROUP BY category_id")
            as $item)
            {
                $last_sort[$category_id] = $item['sort'];
            }
            foreach ($add as $category_id => &$products) {
                $sort = isset($last_sort[$category_id]) ? $last_sort[$category_id] + 1 : 0;
                foreach ($products as &$product) {
                    $product['sort'] = $sort;
                    $data[] = $product;
                    $sort += 1;
                }
                unset($product);
            }
            unset($products);

            $this->multiInsert($data);
            // update counts
            foreach ($counts as $category_id => $count) {
                $this->query("UPDATE `shop_category` SET count = count + $count WHERE id = $category_id");
            }
        }
    }

    public function move($product_ids, $before_id, $category_id = null)
    {
        if (!$product_ids || !$category_id) {
            return false;
        }
        $product_ids = (array)$product_ids;
        $before_id   = (int)$before_id;
        $category_id = (int)$category_id;

        if ($before_id) {
            $sort = $this->query("
                SELECT sort FROM {$this->table}
                WHERE product_id = $before_id AND category_id = $category_id"
            )->fetchField('sort');
            $this->exec("
                UPDATE {$this->table} SET sort = sort + ".count($product_ids)."
                WHERE sort >= $sort AND category_id = $category_id"
            );
        } else {
            $sort = $this->query("
                SELECT MAX(sort) sort FROM {$this->table}
                WHERE category_id = $category_id")->fetchField('sort')
            + 1;
        }
        foreach ($product_ids as $product_id) {
            $this->updateByField(array(
                'product_id'  => $product_id,
                'category_id' => $category_id
            ), array('sort' => $sort++));
        }
        return true;
    }

    public function deleteProducts($category_id, $count = null)
    {
        $sql = "SELECT product_id FROM {$this->table} WHERE category_id = $category_id ";
        if ($count) {
            $sql .= ' LIMIT '.(int)$count;
        }
        $product_ids = array_keys($this->query($sql)->fetchAll('product_id'));
        if ($product_ids) {
            $product_model = new shopProductModel();
            return $product_model->delete($product_ids);
        }
        return false;
    }

    public function deleteByProducts(array $product_ids)
    {
        $category_model = new shopCategoryModel();

        foreach ($this->query("SELECT category_id, count(product_id) cnt FROM {$this->table}
            WHERE product_id IN (".implode(',', $product_ids).")
            GROUP BY category_id") as
        $item)
        {
            $category_model->query(
                "UPDATE ".$category_model->getTableName()." SET count = count - {$item['cnt']}
                WHERE id = {$item['category_id']}"
            );
        }
        $this->deleteByField('product_id', $product_ids);
    }

    public function getData(shopProduct $product)
    {
        $sql = "SELECT c.* FROM ".$this->table." cp JOIN shop_category c ON cp.category_id = c.id
        WHERE cp.product_id = i:id ORDER BY cp.sort";
        return $this->query($sql, array('id' => $product['id']))->fetchAll('id');
    }

    public function setData(shopProduct $product, $data)
    {
        $data = array_unique(array_map('intval', $data));
        $key = array_search(0, $data, true);
        if ($key !== false) {
            unset($data[$key]);
        }

        $current = $this->getByField('product_id',$product->id, 'category_id');
        if ($obsolete = array_diff(array_keys($current), $data)) {
            $this->deleteByField(array('product_id'=>$product->id,'category_id'=>$obsolete));
        }
        if ($added = array_diff($data, array_keys($current))) {

            $this->add($product->id, $added);
        }
        return $data;
    }
}