<?php

class shopCurrencyModel extends waModel
{
    protected $table = 'shop_currency';

    protected $primary_currency;
    protected $currencies;
    protected $id = 'code';

    public function getAll($key = null, $normalize = false)
    {
        $data = $this->query("SELECT * FROM `{$this->table}` ORDER BY `sort`")->fetchAll($key, $normalize);
        foreach ($data as & $item) {
            $item['rate'] = (double) $item['rate'];
        }
        return $data;
    }

    public function getRate($currency)
    {
        $currency = $this->escape($currency);
        $rate = $this->query("SELECT rate FROM `{$this->table}` WHERE code = '$currency'")->fetchField('rate');
        return $this->castValue('double', $rate);
    }

    public function getById($code)
    {
        $currencies = $this->getCurrencies($code);
        if (!$currencies) {
            return false;
        }
        return (is_array($code)) ? $currencies : $currencies[$code];
    }

    public function getCurrencies($codes = null)
    {
        $cache = new waRuntimeCache('shop_currencies');
        if ($cache->isCached()) {
            $data = $cache->get();
        } else {
            $data = array();
            $primary = $this->getPrimaryCurrency();
            $currencies = waCurrency::getAll(true);
            foreach ($this->query("SELECT * FROM ".$this->table." ORDER BY sort") as $c) {
                $code = $c['code'];
                if (isset($currencies[$code])) {
                    $c['rate'] = (double) $c['rate'];
                    $data[$code] = $currencies[$code] + $c;
                    $data[$code]['is_primary'] = $primary == $code;
                }
            }
            $cache->set($data);
        }

        if ($codes) {
            $result = array();
            foreach ((array) $codes as $code) {
                if (isset($data[$code])) {
                    $result[$code] = $data[$code];
                }
            }
            return $result;
        } else {
            return $data;
        }
    }

    public function convert($price, $from, $to)
    {
        $price = $this->castValue('double', $price);
        $primary = $this->getPrimaryCurrency();
        if ($from == $to) {
            return $price;
        }
        $currencies = $this->getCurrencies(array($from, $to));
        $this->existConvertCurrencies($currencies, $from, $to);

        $rate_from = $currencies[$from]['rate'];
        $rate_to = $currencies[$to]['rate'];
        if (!$rate_from) {
            throw new waException("Unknown rate of $from or rate is 0");
        }
        return ($price * $rate_from) / $rate_to;
    }

    /**
     * Remove currency with (or not) converting
     * @param string $code
     * @param string|null $convert_to If null than converting is omitted
     * @return boolean
     */
    public function removeCurrency($code, $convert_to)
    {
        if (!$convert_to) {
            return $this->deleteById($code);
        }

        if ($code == $convert_to) {
            return false;
        }
        $currencies = $this->getCurrencies(array($code, $convert_to));
        $this->existConvertCurrencies($currencies, $code, $convert_to);

        $rate = (double) $currencies[$code]['rate'];
        $rate_to = (double) $currencies[$convert_to]['rate'];
        if (!$rate) {
            return false;
        }

        $this->convertPrices($code, $rate, $convert_to, $rate_to);

        $convert_to = $this->escape($convert_to);
        $this->exec("UPDATE `shop_product` SET currency = '$convert_to' WHERE currency = '$code'");
        $this->exec("UPDATE `shop_service` SET currency = '$convert_to' WHERE currency = '$code'");

        $rate = $this->getRate($convert_to);
        $this->changeRatePrices($convert_to, $rate);

        return $this->deleteById($code);
    }

    public function getPrimaryCurrency()
    {
        if (!$this->primary_currency) {
            $this->primary_currency = wa('shop')->getConfig()->getCurrency();
        }
        return $this->primary_currency;
    }

    public function setPrimaryCurrency($code, $convert = true)
    {
        $primary = $this->getPrimaryCurrency();
        if ($code != $primary) {
            $currency = $this->getById($code);
            if (!$currency) {
                return false;
            }
            $rate = $currency['rate'];

            if ($convert) {
                $this->convertPrices($primary, 1, $code, $rate);
            }
            $this->exec("UPDATE `{$this->table}` SET rate = rate/".$this->castValue('double', $rate));
            $this->updateById($primary, array('sort' => $currency['sort']));
            $this->updateById($code, array('sort' => 0));

            $this->exec("UPDATE `shop_product` SET currency = '$code' WHERE currency = '$primary'");
            $this->exec("UPDATE `shop_service` SET currency = '$code' WHERE currency = '$primary'");

            if ($convert) {
                $this->changeRatePrices($code, 1);
            }

            wa('shop')->getConfig()->setCurrency($code);
            $this->primary_currency = $code;

        }
        return true;
    }

    /**
     * @param array $currencies
     * @param string $from
     * @param string $to
     * @throws waException
     */
    private function existConvertCurrencies($currencies, $from, $to)
    {
        $currencies = $this->getCurrencies(array($from, $to));
        if (!isset($currencies[$from])) {
            throw new waException("Unknown currency: $from");
        }
        if (!isset($currencies[$to])) {
            throw new waException("Unknown currency: $to");
        }
    }

    private function convertPrices($from, $rate_from, $to, $rate_to)
    {
        $this->convertProductPrices($from, $rate_from, $to, $rate_to);
        $this->convertServicePrices($from, $rate_from, $to, $rate_to);
    }

    private function convertProductPrices($from, $rate_from, $to, $rate_to)
    {
        $rate_from = $this->castValue('double', $rate_from);
        $rate_to = $this->castValue('double', $rate_to);
        $cond = "p.currency = '".$this->escape($from)."'";
        $sql = "UPDATE `shop_product_skus` ps
            JOIN `shop_product` p ON p.id = ps.product_id
            SET ps.price = (ps.price*$rate_from)/$rate_to
            WHERE $cond";
        $this->exec($sql);
    }

    private function convertServicePrices($from, $rate_from, $to, $rate_to)
    {
        $rate_from = $this->castValue('double', $rate_from);
        $rate_to = $this->castValue('double', $rate_to);

        $cond = "s.currency = '".$this->escape($from)."'";
        $sql = "UPDATE `shop_service_variants` sv
                JOIN `shop_service` s ON s.id = sv.service_id
                SET sv.price = (sv.price*$rate_from)/$rate_to
                WHERE sv.price IS NOT NULL AND $cond";
        $this->exec($sql);

        $sql = "UPDATE `shop_product_services` ps
                JOIN `shop_service` s ON s.id = ps.service_id
                SET ps.price = (ps.price*$rate_from)/$rate_to
                WHERE ps.price IS NOT NULL AND $cond";
        $this->exec($sql);

        $sql = "UPDATE `shop_service` s
                SET s.price = (price*$rate_from)/$rate_to, s.currency = '".$this->escape($to)."'
                WHERE $cond";
        $this->exec($sql);
    }

    public function add($code)
    {
        $code = $this->escape($code);
        if ($this->getById($code)) {
            return false;
        }
        $currencies = waCurrency::getAll(true);
        if (!isset($currencies[$code])) {
            return false;
        }
        $sort = $this->query("SELECT MAX(sort) sort FROM `{$this->table}`")->fetchField('sort') + 1;
        $result = $this->insert(array(
            'code' => $code,
            'sort' => $sort
        ));
        $cache = new waRuntimeCache('shop_currencies');
        $cache->delete();
        return $result;
    }

    public function changeRate($code, $rate)
    {
        $primary = $this->getPrimaryCurrency();
        if ($code == $primary) {
            return false;
        }
        $currency = $this->getById($code);
        if (!$currency) {
            return false;
        }
        $code = $this->escape($code);
        $rate = (double) $rate;
        $old_rate = (double) $currency['rate'];
        if ($rate < 0) {
            return false;
        }
        if ($rate != $old_rate) {
            $this->changeRatePrices($code, $rate);
            $result = $this->updateById($code, array('rate' => $rate));

            $cache = new waRuntimeCache('shop_currencies');
            $cache->delete();
            return $result;
        }
        return true;
    }

    private function changeRatePrices($code, $rate)
    {
        $this->changeRateProductPrices($code, $rate);
        $this->changeRateServicePrices($code, $rate);
    }

    private function changeRateProductPrices($code, $rate)
    {
        $rate = $this->castValue('double', $rate);
        $cond = "p.currency = '".$this->escape($code)."'";

        $sql = "UPDATE `shop_product` p2 JOIN
            (
                SELECT p.id, MIN(ps.price) AS min_price, MAX(ps.price) AS max_price
                FROM `shop_product` p
                JOIN `shop_product_skus` ps ON ps.product_id = p.id
                WHERE $cond
                GROUP BY p.id
            ) r ON p2.id = r.id
            SET p2.min_price = r.min_price*$rate, p2.max_price = r.max_price*$rate";
        $this->exec($sql);

        $sql = "UPDATE `shop_product` p
            JOIN `shop_product_skus` ps ON ps.product_id = p.id AND ps.id = p.sku_id
            SET p.price = ps.price*$rate
            WHERE $cond";
        $this->exec($sql);

        $sql = "UPDATE `shop_product` p
                JOIN `shop_product_skus` ps ON p.id = ps.product_id
                SET ps.primary_price = ps.price*$rate
                WHERE $cond";
        $this->exec($sql);
    }

    private function changeRateServicePrices($code, $rate)
    {
        $rate = $this->castValue('double', $rate);
        $cond = "s.currency = '".$this->escape($code)."'";

        $sql = "UPDATE `shop_service` s
                SET primary_price = price*$rate
                WHERE $cond";
        $this->exec($sql);

        $sql = "UPDATE `shop_service_variants` sv
                JOIN `shop_service` s ON s.id = sv.service_id
                SET sv.primary_price = sv.price*$rate
                WHERE $cond AND sv.price IS NOT NULL";
        $this->exec($sql);

        $sql = "UPDATE `shop_product_services` ps
                JOIN `shop_service` s ON s.id = ps.service_id
                SET ps.primary_price = ps.price*$rate
                WHERE $cond AND ps.price IS NOT NULL";
        $this->exec($sql);
    }

    public function move($code, $before_code = null)
    {
        $primary = $this->getPrimaryCurrency();
        if ($code == $primary) {
            return false;
        }
        if (!$before_code) {
            $item = $this->getById($code);
            if (!$item) {
                return false;
            }
            $sort = $this->query("SELECT MAX(sort) sort FROM {$this->table}")->fetchField('sort') + 1;
            $this->updateById($code, array('sort' => $sort));
        } else {
            $code = $this->escape($code);
            $before_code = $this->escape($before_code);
            $items = $this->query("SELECT * FROM {$this->table} WHERE code IN ('$code', '$before_code')")->fetchAll('code');
            if (!$items || count($items) != 2) {
                return false;
            }
            $sort = $items[$before_code]['sort'];
            $this->exec("UPDATE {$this->table} SET sort = sort + 1 WHERE sort >= $sort");
            $this->updateById($code, array('sort' => $sort));
        }
        return true;
    }

}
