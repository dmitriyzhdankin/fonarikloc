<?php

class shopServiceModel extends waModel
{
    protected $table = 'shop_service';

    public function delete($id)
    {
        if (!$this->getById($id)) {
            return false;
        }
        foreach (array(
            new shopServiceVariantsModel(),
            new shopTypeServicesModel(),
            new shopProductServicesModel()
        ) as $model) {
            $model->deleteByField('service_id', $id);
        }
        return $this->deleteById($id);
    }

    public function save($data, $id = 0)
    {
        $primary_currency = wa('shop')->getConfig()->getCurrency();
        if (empty($data['currency'])) {
            $data['currency'] = $primary_currency;
        }

        $just_inserted = false;
        if (!$id) {
            $id = $this->insert(array(
                'name'     => $data['name'],
                'price'    => !empty($data['price']) ? $data['price'] : 0,
                'currency' => $data['currency'],
                'tax_id'   => isset($data['tax_id']) ? $data['tax_id'] : ($data['tax_id'] === null ? null : 0),
            ));
            if (!$id) {
                return false;
            }
            $just_inserted = true;
        }
        if ($id) {
            $variants = $this->updateVariants($id, $data['variants']);
            $this->updateTypes($id, array('types' => $data['types'], 'variants' => $variants));
            $this->updateProducts($id, array('products' => $data['products'], 'variants' => $variants));

            if (!$just_inserted) {
                $update = array();
                $fields = array('name', 'currency', 'price', 'tax_id');
                foreach ($fields as $field) {
                    if (isset($data[$field])) {
                        $update[$field] = $data[$field];
                    } else {
                        if ($field === 'tax_id' && $data[$field] === null) {
                            $update[$field] = $data[$field];
                        }
                    }
                }
                if ($update) {
                    $this->updateById($id, $update);
                }
            }
        }

        // conver inner pirce (primary_price) of itself and relate items (variants, products)

        $currency_model = new shopCurrencyModel();
        $currency = $data['currency'];
        $rate = $currency_model->getRate($currency);
        $cond = "ss.id = $id";

        $sql = "UPDATE `shop_service` ss
                SET ss.primary_price = ss.price*$rate
                WHERE $cond";
        $this->exec($sql);

        $sql = "UPDATE `shop_service_variants` sv
                JOIN `shop_service` ss ON ss.id = sv.service_id
                SET sv.primary_price = sv.price*$rate
                WHERE $cond AND sv.price IS NOT NULL";
        $this->exec($sql);

        $sql = "UPDATE `shop_product_services` ps
                JOIN `shop_service` ss ON ss.id = ps.service_id
                SET ps.primary_price = ps.price*$rate
                WHERE $cond AND ps.price IS NOT NULL";
        $this->exec($sql);

        return $id;
    }

    private function updateVariants($service_id, $data)
    {

        $add = array();
        $update = array();

        $model = new shopServiceVariantsModel();
        $old_variants = $model->getByField('service_id', $service_id, 'id');

        foreach ($data as $item) {
            if (empty($item['id']) || empty($old_variants[$item['id']])) {
                $item['service_id'] = $service_id;
                $add[] = $item;
            } else {
                $variant_id = $item['id'];
                $item = array_diff_assoc($item, $old_variants[$variant_id]);
                if (!empty($item)) {
                    $update[$variant_id] = $item;
                }
                unset($old_variants[$variant_id]);
            }
        }

        $default_id = null;

        foreach ($add as $item) {
            if (!empty($item['default'])) {
                $default_id = $model->insert($item);
                continue;
            }
            $model->insert($item);
        }
        foreach ($update as $id => $item) {
            if (!empty($item['default'])) {
                $default_id = $id;
            }
            $model->updateById($id, $item);
        }
        if ($old_variants) {
            $model->deleteById(array_keys($old_variants));
        }

        if (!$default_id) {
            $default_id = $this->query("
                SELECT id FROM `shop_service_variants`
                WHERE service_id = ".(int) $service_id." LIMIT 1
            ")->fetchField('id');
            $default_id = $default_id ? $default_id : null;
        }

        $this->updateById($service_id, array('variant_id' => $default_id));

        return array_keys($model->getByField('service_id', $service_id, 'id'));
    }

    private function updateTypes($service_id, $data)
    {
        $model = new shopTypeServicesModel();
        $where = $model->getWhereByField(array('service_id' => $service_id));
        if (!$where) {
            return false;
        }

        $old_data = array_keys($model->getByField('service_id', $service_id, 'type_id'));

        $add = array();
        foreach (array_diff($data['types'], $old_data) as $type_id) {
            $add[] = array('type_id' => $type_id, 'service_id' => $service_id);
        }

        if ($add) {
            $model->multipleInsert($add);
        }

        $delete = array_diff($old_data, $data['types']);
        if ($delete) {
            $model->deleteByField(array('type_id' => $delete, 'service_id' => $service_id));
        }
    }

    private function updateProducts($service_id, $data)
    {
        $model = new shopProductServicesModel();
        $where = $model->getWhereByField(array('service_id' => $service_id));
        if (!$where) {
            return false;
        }

        $old_data = array();
        foreach ($this->query("
                SELECT * FROM `".$model->getTableName()."`
                WHERE $where ORDER BY `service_id`, `service_variant_id`") as $item) {
            $old_data[$item['product_id']][(int) $item['service_variant_id']] = $item;
        }

        $add = array();

        $data['variants'][] = null; // means service_variant_id IS NULL
        foreach ($data['products'] as $product_id) {
            // check variants
            foreach ($data['variants'] as $variant_id) {
                $variant_id = (int) $variant_id;
                if (isset($old_data[$product_id][$variant_id])) {
                    unset($old_data[$product_id][$variant_id]);
                } else {
                    $add[] = array('product_id' => $product_id, 'service_id' => $service_id, 'service_variant_id' => $variant_id ? $variant_id : null);
                }
            }
        }

        $delete = array(
            'product_id'         => array(),
            'service_variant_id' => array()
        );

        foreach ($old_data as $product_id => $items) {
            if (!empty($items)) {
                $delete['product_id'][] = $product_id;
                foreach ($items as $variant_id => $item) {
                    $delete['service_variant_id'][] = $variant_id ? $variant_id : null;
                }
            }
        }

        if (!empty($add)) {
            $model->multiInsert($add);
        }

        if ($delete['product_id'] && $delete['service_variant_id']) {
            $where = $model->getWhereByField(array('product_id' => $delete['product_id'], 'service_id' => $service_id));
            if ($where) {
                $where .= $this->getServiceVariantsWhere(array_unique($delete['service_variant_id']));
                $model->query("DELETE FROM `".$model->getTableName()."` WHERE $where");
            }
        }
    }

    private function getServiceVariantsWhere($data, $and_prefix = true)
    {
        $cond = array('null' => false, 'in' => array());
        foreach ($data as $value) {
            if ($value !== null) {
                $cond['in'][] = $value;
            } else {
                $cond['null'] = true;
            }
        }
        $where = "";
        if (!empty($cond['in'])) {
            $where .= "`service_variant_id` IN ('".implode("','", $cond['in'])."')";
        }
        if ($cond['null']) {
            if (!$where) {
                $where = "`service_variant_id` IS NULL";
            } else {
                $where = "($where OR `service_variant_id` IS NULL)";
            }
        }
        if ($and_prefix && $where) {
            $where = " AND $where";
        }
        return $where;
    }

    public function getAll($key = null, $normalize = false)
    {
        return $this->query("SELECT * FROM `{$this->table}` ORDER BY id")->fetchAll($key, $normalize);
    }
}
