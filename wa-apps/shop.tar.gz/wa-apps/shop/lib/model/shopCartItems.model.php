<?php

class shopCartItemsModel extends waModel
{
    protected $table = 'shop_cart_items';

    public function total($code)
    {
        $sql = "SELECT SUM(s.primary_price * c.quantity) FROM ".$this->table." c
                JOIN shop_product_skus s ON c.sku_id = s.id
                WHERE c.code = s:code AND type = 'product'";
        $products_total = $this->query($sql, array('code' => $code))->fetchField();

        $services_total = 0;
        $sql = "SELECT c.*, s.primary_price AS price FROM ".$this->table." c JOIN
        shop_service s ON c.service_id = s.id WHERE c.code = s:code AND type = 'service'";
        $services = $this->query($sql, array('code' => $code))->fetchAll();
        if (!$services) {
            return shop_currency($products_total, wa()->getConfig()->getCurrency(true), null, false);
        }
        $variant_ids = array();
        $product_ids = array();
        foreach ($services as $s) {
            if ($s['service_variant_id']) {
                $variant_ids[] = $s['service_variant_id'];
            }
            $product_ids[] = $s['product_id'];
        }
        $variant_ids = array_unique($variant_ids);
        $product_ids = array_unique($product_ids);
        // get variant settings
        $variants_model = new shopServiceVariantsModel();
        $variants = $variants_model->getById($variant_ids);
        // get products/skus settings
        $product_services_model = new shopProductServicesModel();
        $products_services = $product_services_model->getByProducts($product_ids, true);

        foreach ($services as $s) {
            $p_id = $s['product_id'];
            $sku_id = $s['product_id'];
            $s_id = $s['service_id'];
            $v_id = $s['service_variant_id'];
            $p_services = isset($products_services[$p_id]) ? $products_services[$p_id] : array();

            if (!$v_id) {
                if (!empty($p_services['skus'][$sku_id][$s_id]['primary_price'])) {
                    $s['price'] = $p_services['skus'][$sku_id][$s_id]['primary_price'];
                } elseif (!empty($p_services[$s_id]['primary_price'])) {
                    $s['price'] = $p_services[$s_id]['primary_price'];
                }
            } else {
                // base price of variant
                if (!empty($variants[$v_id]['primary_price'])) {
                    $s['price'] = $variants[$v_id]['primary_price'];
                }
                // price variant for sku
                if (!empty($p_services['skus'][$sku_id][$s_id]['variants'][$v_id]['price'])) {
                    $s['price'] = $p_services['skus'][$sku_id][$s_id]['variants'][$v_id]['primary_price'];
                } elseif (!empty($p_services[$s_id]['variants'][$v_id]['primary_price'])) {
                    $s['price'] = $p_services[$s_id]['variants'][$v_id]['primary_price'];
                }
            }

            $services_total += $s['price'];
        }

        $total = $products_total + $services_total;
        $primary = wa()->getConfig()->getCurrency();
        $currency = wa()->getConfig()->getCurrency(false);
        if ($currency != $primary) {
            $currencies = wa()->getConfig()->getCurrencies(array($currency));
            $total = $total / $currencies[$currency]['rate'];
        }
        return $total;
    }

    public function count($code, $type = null)
    {
        $sql = "SELECT COUNT(*) FROM ".$this->table." WHERE code = s:code";
        if ($type) {
            $sql .= ' AND type = s:type';
        }
        return $this->query($sql, array(
            'code' => $code,
            'type' => $type
        ))->fetchField();
    }


    public function getByCode($code, $product_id = null, $sku_id = null, $full_info = false)
    {
        if ($product_id === true) {
            $full_info = true;
            $product_id = null;
        }
        $sql = "SELECT * FROM ".$this->table." WHERE code = s:code";
        if ($product_id && $sku_id) {
            $sql .= " AND product_id = i:product_id AND sku_id = i:sku_id";
        }
        $sql .= " ORDER BY parent_id";
        $items = $this->query($sql, array(
            'code' => $code, 'product_id' => $product_id, 'sku_id' => $sku_id))->fetchAll('id');

        if  ($full_info) {
            $product_ids = $sku_ids = $service_ids = $variant_ids = array();
            foreach ($items as $item) {
                $product_ids[] = $item['product_id'];
                $sku_ids[] = $item['sku_id'];
                if ($item['type'] == 'service') {
                    $service_ids[] = $item['service_id'];
                    if ($item['service_variant_id']) {
                        $variant_ids[] = $item['service_variant_id'];
                    }
                }
            }

            $product_model = new shopProductModel();
            $products = $product_model->getByField('id', $product_ids, 'id');
            
            $sku_model = new shopProductSkusModel();
            $skus = $sku_model->getByField('id', $sku_ids, 'id');

            $service_model = new shopServiceModel();
            $services = $service_model->getByField('id', $service_ids, 'id');

            $service_variants_model = new shopServiceVariantsModel();
            $variants = $service_variants_model->getByField('id', $variant_ids, 'id');

            foreach ($items as &$item) {
                if ($item['type'] == 'product') {                    
                    $item['product'] = $products[$item['product_id']];
                    $sku = $skus[$item['sku_id']];
                    $item['sku_name'] = $sku['name'];
                    $item['currency'] = $item['product']['currency'];
                    $item['price'] = $sku['price'];
                    $item['name'] = $item['product']['name'];
                    if ($item['sku_name']) {
                        $item['name'] .= ' ('.$item['sku_name'].')';
                    }
                } else {
                    $item['name'] = $item['service_name'] = $services[$item['service_id']]['name'];
                    $item['price'] = $services[$item['service_id']]['price'];
                    $item['currency'] = $services[$item['service_id']]['currency'];
                    if ($item['service_variant_id']) {
                        $item['variant_name'] = $variants[$item['service_variant_id']]['name'];
                        if ($item['variant_name']) {
                            $item['name'] .= ' ('.$item['variant_name'].')';
                        }
                        if ($variants[$item['service_variant_id']]['price'] !== null) {
                            $item['price'] = $variants[$item['service_variant_id']]['price'];
                        }
                    }
                }
            }
            unset($item);
        }

        foreach ($items as $item_id => $item) {
            if ($item['parent_id']) {
                $items[$item['parent_id']]['services'][] = $item;
                unset($items[$item_id]);
            }
        }
        return $items;
    }

    public function getItem($code, $id)
    {
        $sql = "SELECT c.*, p.currency, s.price FROM ".$this->table." c
        JOIN shop_product p ON c.product_id = p.id JOIN shop_product_skus s ON c.sku_id = s.id
        WHERE c.code = s:code AND c.id = i:id";
        return $this->query($sql, array('code' => $code, 'id' => $id))->fetch();
    }
}
