<?php
class shopFeatureValuesVarcharModel extends shopFeatureValuesModel
{
    protected $table = 'shop_feature_values_varchar';

    protected function getSearchCondition()
    {
        return 'LIKE s:value';
    }

    protected function parseValue($value, $type)
    {
        return array('value' => trim($value));
    }
}
