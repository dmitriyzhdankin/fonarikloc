<?php
class shopFeatureValuesTextModel extends shopFeatureValuesModel
{
    protected $table = 'shop_feature_values_text';

    protected function getSearchCondition()
    {
        return 'LIKE s:value';
    }

    protected function parseValue($value, $type)
    {
        return array('value' => trim($value));
    }
}
