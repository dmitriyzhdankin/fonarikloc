<?php

class shopCartServicesModel extends waModel
{
    protected $table = 'shop_cart_services';
}