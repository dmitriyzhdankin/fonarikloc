<?php

class shopSearchIndexModel extends waModel
{
    protected $table = 'shop_search_index';

    /**
     * TODO: realize
     * @param array $product_ids
     */
    public function deleteByProducts(array $product_ids)
    {

    }
}