<?php
class shopProductStocksModel extends waModel
{
    protected $table = 'shop_product_stocks';
    protected $id = array('sku_id','stock_id');

    /**
     * TODO: realize
     * @param array $product_ids
     */
    public function deleteByProducts(array $product_ids)
    {
        $this->deleteByField('product_id', $product_ids);
    }

    /**
     * Delete stock with or not recounting total counter of skus
     *
     * @param int $stock_id
     * @param boolean $recount
     */
    public function deleteStock($stock_id, $recount = true)
    {
        $stock_id = (int)$stock_id;
        if ($stock_id) {
            if ($recount) {

                $sql = "UPDATE `shop_product_skus` s
                        JOIN `{$this->table}` ps ON s.id = ps.sku_id
                        SET s.count = s.count - ps.count
                        WHERE ps.stock_id = $stock_id";
                if (!$this->exec($sql)) {
                    return false;
                }

                $sql = "UPDATE `shop_product` p
                        JOIN (
                            SELECT product_id, SUM(count) count
                            FROM {$this->table}
                            WHERE stock_id = {$stock_id}
                            GROUP BY product_id
                        ) AS ps ON p.id = ps.product_id
                        SET p.count = p.count - ps.count";
                if (!$this->exec($sql)) {
                    return false;
                }
            }
            return $this->deleteByField('stock_id', $stock_id);
        }
        return false;
    }

    /**
     * Move skus from source stock to destination stock and REMOVE source stock
     *
     * @param int $src_id
     * @param int $dst_id
     */
    public function move($src_id, $dst_id)
    {
        // increase counts of destination stock for intersecting skus
        $sql = "UPDATE `{$this->table}` dst
                JOIN `{$this->table}` src ON src.sku_id = dst.sku_id
                SET dst.count = dst.count + src.count
                WHERE dst.stock_id = $dst_id AND src.stock_id = $src_id AND src.count IS NOT NULL AND dst.count IS NOT NULL";
        if (!$this->exec($sql)) {
            return false;
        }

        // and for that items which aren't in destination stock change stock_id to stock_id of source stock
        // ( in other words turn source items to desctination items )
        $sql = "UPDATE `{$this->table}` src
                LEFT JOIN `{$this->table}` dst ON dst.sku_id = src.sku_id AND dst.stock_id = $dst_id
                SET src.stock_id = {$dst_id}
                WHERE src.stock_id = $src_id AND dst.sku_id IS NULL";
        if (!$this->exec($sql)) {
            return false;
        }
        return $this->deleteStock($src_id, false);
    }

    /**
     * Transfer sku from one stock (src) to another (dst)
     *
     * @param int $src_id
     * @param int $dst_id
     * @param int $sku_id
     * @param int $count
     * @return boolean
     */
    public function transfer($src_id, $dst_id, $sku_id, $count = null) {
        $src_id = (int)$src_id;
        $dst_id = (int)$dst_id;
        $sku_id = (int)$sku_id;

        $stock_model = new shopStockModel();
        $data = $stock_model->getByField('id', array($src_id, $dst_id), true);
        if (count($data) < 2) {
            return false;
        }

        $data = $this->query("SELECT * FROM {$this->table} WHERE sku_id = $sku_id AND stock_id IN($src_id, $dst_id)")->fetchAll('stock_id');
        if (empty($data[$src_id])) {
            return false;
        }
        $src = $data[$src_id];
        $dst = isset($data[$dst_id]) ? $data[$dst_id] : array();
        $count = $count === null ? $src['count'] : min((int)$count, $src['count']);
        if (!$count) {
            return true;
        }

        if (empty($dst)) {
            if (!$this->insert(array(
                'sku_id' => $sku_id,
                'stock_id' => $dst_id,
                'product_id' => $src['product_id'],
                'count' => $count
            ))) {
                return false;
            }
        } else {
            if (!$this->updateByField(array(
                    'sku_id' => $sku_id,
                    'stock_id' => $dst_id
                ), array('count' => $dst['count'] + $count)))
            {
                return false;
            }
        }
        if (!$this->updateByField(array(
                'sku_id' => $sku_id,
                'stock_id' => $src_id
            ), array('count' => $src['count'] - $count)))
        {
            return false;
        }

        return true;
    }

    public function getStocksOfProduct($product_id, $stock_ids = null, $sku_order = 'count DESC', $stock_order = false)
    {
        if (!$product_id) {
            return false;
        }
        $where = array('product_id' => $product_id);
        if ($stock_ids) {
            $where['stock_id'] = $stock_ids;
        }
        $where = $this->getWhereByField($where, true);
        if (!$where) {
            return false;
        }

        $product_skus_model = new shopProductSkusModel();
        $skus_table = $product_skus_model->getTableName();

        if ($sku_order != 'count DESC' &&
            $sku_order != 'count ASC' &&
            $sku_order != 'sku.count DESC' &&
            $sku_order != 'sku.count ASC')
        {
            $sku_order = 'count DESC';
        }

        if (substr($sku_order, 0, 3) == 'sku') {
            $sku_order = $skus_table.substr($sku_order, 3);
        } else {
            $sku_order = $this->table.$sku_order;
        }

        $sql = "SELECT {$this->table}.*, {$skus_table}.name FROM {$this->table}
                JOIN {$skus_table} ON {$skus_table}.id = {$this->table}.sku_id";

        if ($stock_order) {
            $stock_model = new shopStockModel();
            $stock_table = $stock_model->getTableName();
            $sql .= " JOIN {$stock_table} ON {$stock_table}.id = {$this->table}.stock_id
                        WHERE $where ORDER BY {$stock_table}.sort, $sku_order";
        } else {
            $sql .= " WHERE $where ORDER BY {$this->table}.stock_id, $sku_order";
        }
        $data = array();
        $stock_id = 0;
        foreach ($this->query($sql) as $item) {
            if ($stock_id != $item['stock_id']) {
                $data[$item['stock_id']] = array();
                $stock_id = $item['stock_id'];
            }
            $data[$item['stock_id']][] = array(
                'id' => $item['sku_id'],
                'count' => $item['count'],
                'name' => $item['name']
            );
        }
        return $data;
    }
}
