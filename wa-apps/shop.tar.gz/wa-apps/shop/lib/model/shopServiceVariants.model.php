<?php


class shopServiceVariantsModel extends waModel
{
    protected $table = 'shop_service_variants';

    public function delete($id)
    {
        $item = $this->getById($id);
        if (!$item) {
            return false;
        }
        $service_id = $item['service_id'];

        if (!$this->deleteById($id)) {
            return false;
        }

        $type_services = new shopTypeServicesModel();
        $product_services = new shopProductServicesModel();
        $key = array('service_id' => $service_id, 'service_variant_id' => $id);
        $type_services->deleteByField($key);
        $product_services->deleteByField($key);

        return true;
    }

    public function get($service_id)
    {
        return $this->query("SELECT * FROM `{$this->table}`WHERE service_id = ".(int)$service_id." ORDER BY id")->fetchAll();
    }
}