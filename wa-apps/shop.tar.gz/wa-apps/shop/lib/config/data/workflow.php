<?php

return array(
    'states' => array(
        'new' => array (
            'name' => _w('New'),
            'options' => array (
                'icon' => 'icon16 ss new',
                'style' => array(
                    'color' => '#008800',
                    'font-weight' => 'bold'
                )
            ),
            'available_actions' => array(
                'process',
                'pay',
                'complete',
                'comment',
                'split',
                'edit',                
                'delete',
            )
        ),
        'processing' => array(
            'name' => _w('Processing'),
            'options' => array(
                'icon' => 'icon16 ss processing',
                'style' => array(
                    'color' => '#008800',
                )
            ),
            'available_actions' => array(
                'ship',                
                'pay',
                'complete',
                'comment',
                'split',                
                'edit',
                'delete'
            )
        ),
        'paid' => array(
            'name' => _w('Paid'),
            'options' => array(
                'icon' => 'icon16 ss paid',
                'style' => array(
                    'color' => '#0000FF',
                    'font-weight' => 'bold'
                )
            ),
            'available_actions' => array(
                'ship',
                'complete',
                'refund',
                'comment'
            )
        ),
        'shipped' => array(
            'name' => _w('Sent'),
            'options' => array(
                'icon' => 'icon16 ss sent',
                'style' => array(
                    'color' => '#0000CC',
                )
            ),
            'available_actions' => array(
                'complete',
                'comment',
                'delete'
            )
        ),
        'completed' => array(
            'name' => _w('Completed'),
            'options' => array (
                'icon' => 'icon16 ss completed',
                'style' => array(
                    'color' => '#555555',
                )
            ),
            'available_actions' => array(
                'comment',
                'refund'
            )
        ),
        'refunded' => array(
            'name' => _w('Refunded'),
            'options' => array(
                'icon' => 'icon16 ss refunded',
                'style' => array(
                    'color' => '#aa4444',
                )
            ),
            'available_actions' => array(
            )
        ),
        'deleted' => array(
            'name' => _w('Deleted'),
            'options' => array(
                'icon' => 'icon16 ss trash',
                'style' => array(
                    'color' => '#aaaaaa'
                )
            ),
            'available_actions' => array(
                'restore'
            )
        ),

    ),
    'actions' => array(
        'create' => array(
            'classname' => 'shopWorkflowCreateAction',
            'name' => _w('Create'),
            'state' => 'new'
        ),
        'process' => array(
            'classname' => 'shopWorkflowProcessAction',
            'name' => _w('Process'),
            'options' => array(
                'button_class' => 'green'
            ),
            'state' => 'processing'
        ),
        'ship' => array(
            'classname' => 'shopWorkflowShipAction',
            'name' => _w('Sent'),
            'options' => array(
                'button_class' => 'blue'
            ),
            'state' => 'shipped'
        ),
        'pay' => array(
            'classname' => 'shopWorkflowPayAction',
            'name' => _w('Paid'),
            'options' => array(
                'button_class' => 'blue'
            ),
            'state' => 'paid'
        ),
        'refund' => array(
            'classname' => 'shopWorkflowRefundAction',
            'name' => _w('Refund'),
            'state' => 'refunded'
        ),
/*
        'split' => array(
            'classname' => 'shopWorkflowSplitAction',
            'name' => _w('Split order'),
        ),
*/
        'edit' => array(
            'classname' => 'shopWorkflowEditAction',
            'name' => _w('Edit order'),
            'options' => array(
                'top' => true,
                'icon' => 'edit'
            )
        ),
        'delete' => array(
            'classname' => 'shopWorkflowDeleteAction',
            'name' => _w('Delete'),
            'state' => 'deleted',
            'options' => array(
                'top' => true,
                'icon' => 'delete'
            )
        ),
        'restore' => array(
            'classname' => 'shopWorkflowRestoreAction',
            'name' => _w('Restore'),
            'options' => array(
                'icon' => 'restore',
                'button_class' => 'green',
            )
        ),
        'comment' => array(
            'classname' => 'shopWorkflowCommentAction',
            'name' => _w('Add comment'),
        ),
        'complete' => array(
            'classname' => 'shopWorkflowCompleteAction',
            'name' => _w('Mark as Completed'),
            'state' => "completed"
        )
    )
);
