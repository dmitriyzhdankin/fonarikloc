<?php

wa('shop');
$type_model = new shopTypeModel();
$types = $type_model->select('id,name')->fetchAll('id', true);

$currencies = wa('shop')->getConfig()->getCurrencies();
foreach ($currencies as &$c) {
    $c = $c['title'];
}

$stock_model = new shopStockModel();
$stocks = $stock_model->select('id,name')->fetchAll('id', true);

return array(
    'params' => array(
        'title' => array(
            'name' => _w('Homepage title <title>'),
            'type' => 'input',
        ),
        'meta_keywords' => array(
            'name' => _w('Homepage META Keywords'),
            'type' => 'input'
        ),
        'meta_description' => array(
            'name' => _w('Homepage META Description'),
            'type' => 'textarea'
        ),
        'url_type' => array(
            'name' => _w('URLs'),
            'type' => 'radio_select',
            'items' => array(
                0 => array(
                    'name' => _w('Mixed'),
                    'description' => _w('<br>Product URLs: /<strong>product-name/</strong><br>Category URLs: /category/<strong>category-name/subcategory-name/subcategory-name/...</strong>'),
                ),
                1 => array(
                    'name' => _w('Plain').' (WebAsyst Shop-Script)',
                    'description' => _w('<br>Product URLs: /product/<strong>product-name/</strong><br>Category URLs: /category/<strong>category-name/</strong>'),
                ),
            )
        ),        
        'type_id' => array(
            'name' => _w('Published products'),
            'type' => 'radio_checkbox',
            'items' => array(
                0 => array(
                    'name' => _w('All product types'),
                    'description' => '',
                ),
                array (
                    'name' => _w('Selected only'),
                    'description' => '',
                    'items' => $types
                )
            )
        ),
        'currency' => array(
            'name' => _w('Default currency'),
            'type' => 'select',
            'items' => $currencies
        ),
        'stock_id' => array(
            'name' => _w('Default stock'),
            'description' => _w('Select primary stock to which this storefront is associated with. When you process orders from placed via this storefront, selected stock will be automatically offered for product stock update.'),
            'type' => 'select',
            'items' => $stocks
        )

    ),
    'vars'   => array(
        '$wa'        => array(
            '$wa->shop->cart()'       => _w('Returns cart'),
            '$wa->shop->productSet()' => _w('Product set'),
        ),
        'index.html' => array(

        ),
    ),
    'blocks' => array(

    ),
);
