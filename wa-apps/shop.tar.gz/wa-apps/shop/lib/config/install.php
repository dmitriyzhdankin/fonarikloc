<?php
$path = wa()->getDataPath('products', true, 'shop');
waFiles::write($path.'/thumb.php', '<?php
$file = realpath(dirname(__FILE__)."/../../../../")."/wa-apps/shop/lib/config/data/thumb.php";

if (file_exists($file)) {
    include($file);
} else {
    header("HTTP/1.0 404 Not Found");
}
');
waFiles::copy(wa()->getAppPath('lib/config/data/.htaccess', 'shop'), $path.'/.htaccess');
$currency_model = new shopCurrencyModel();
$currency_model->insert(array(
    'code' => 'USD',
    'rate' => 1.000,
    'sort' => 1,
), 2);

$model = new waAppSettingsModel();
$model->set('shop', 'currency', 'USD');

header("Location: ".waSystemConfig::getBackendUrl(true).'shop/?action=welcome');
