<?php
return array(
    // default
    // url to category: /category/categoryurl/
    // url to product: /producturl/
    0 => array(
        '' => 'frontend',
        'login/' => 'login',
        'forgotpassword/' => 'forgotpassword',
        'signup/' => 'signup',
        'search/' => 'frontend/search',
        'data/regions/' => 'frontend/regions',
        'cart/' => 'frontend/cart',
        'checkout/' => 'frontend/checkout',
        'checkout/<step:[^/]+>/?' => 'frontend/checkout',
        'cart/<action>/' => 'frontendCart',
        'compare/<id:[\d,]+>/' => 'frontend/compare',
        'tag/<tag>/' => 'frontend/tag',
        'category/<category_url>/' => 'frontend/category',
        '<product_url:[^/]+>/reviews/' => 'frontend/productReviews',
        '<product_url:[^/]+>/reviews/add/' => 'frontend/productReviewsAdd',
        '<product_url:[^/]+>/<page_url>/' => 'frontend/productPage',
        '<product_url:[^/]+>/' => 'frontend/product',
    ),

    1 => array(
        '' => 'frontend',
        'login/' => 'login',
        'forgotpassword/' => 'forgotpassword',
        'signup/' => 'signup',
        'search/' => 'frontend/search',
        'data/regions/' => 'frontend/regions',
        'cart/' => 'frontend/cart',
        'checkout/' => 'frontend/checkout',
        'checkout/<step:[^/]+>/?' => 'frontend/checkout',
        'cart/<action>/' => 'frontendCart',
        'compare/<id:[\d,]+>/' => 'frontend/compare',
        'tag/<tag>/' => 'frontend/tag',
        'category/<category_url>/' => 'frontend/category',
        'product/<product_url:[^/]+>/reviews/' => 'frontend/productReviews',
        'product/<product_url:[^/]+>/reviews/add/' => 'frontend/productReviewsAdd',
        'product/<product_url:[^/]+>/<page_url>/' => 'frontend/productPage',
        'product/<product_url:[^/]+>/' => 'frontend/product',
    ),
);