<?php
class shopFrontendLayout extends waLayout
{
    public function execute()
    {

        if (wa()->getEnv() == 'frontend' && ($currency = waRequest::get("currency"))) {
            if ($this->getConfig()->getCurrencies(array($currency))) {
                wa()->getStorage()->set('shop/currency', $currency);
                wa()->getStorage()->remove('shop/cart');
            }
            $url = $this->getConfig()->getCurrentUrl();
            $url = preg_replace('/[\?&]currency='.$currency.'/i', '', $url);
            $this->redirect($url);
        }


        $this->view->assign('action', waRequest::param('action', 'default'));
        $this->setThemeTemplate('index.html');

        /**
         * @event frontend_head
         */
        $this->view->assign('frontend_head', wa()->event('frontend_head'));

        $this->view->assign('currencies', $this->getConfig()->getCurrencies());
    }
}
