<?php

class shopWorkflowCommentAction extends shopWorkflowAction
{

    public function getDefaultOptions()
    {
        $options = parent::getDefaultOptions();
        $options['html'] = true;
        return $options;
    }

    public function execute($params = null)
    {
        return array(
            'text' => waRequest::post('text')
        );
    }

}
