<?php

class shopWorkflowCreateAction extends shopWorkflowAction
{
    public function execute($data = null)
    {
        $currency = wa()->getConfig()->getCurrency(false);
        $rate_model = new shopCurrencyModel();
        $row = $rate_model->getById($currency);
        $rate = $row['rate'];
        $order = array(
            'state_id' => 'new',
            'total' => $data['total'],
            'currency' => $currency,
            'rate' => $rate,
            'tax' => $data['tax'],
            'discount' => $data['discount'],
            'shipping' => $data['shipping'],
        );

        // Save contact
        if (isset($data['contact'])) {
            if (is_numeric($data['contact'])) {
                $contact = new waContact($data['contact']);
            } else {
                $contact = $data['contact'];
                if (!$contact->getId()) {
                    $contact->save();
                }
            }
        } else {
            $contact = wa()->getUser();
        }
        $order['contact_id'] = $contact->getId();

        // Add contact to 'shop' category
        $ccm = new waContactCategoryModel();
        $ccsm = new waContactCategoriesModel();
        $ccsm->add($order['contact_id'], $ccm->getBySystemId('shop'));

        // Save order
        $order_model = new shopOrderModel();
        $order_id = $order_model->insert($order);

        // Create record in shop_customer, or update existing record
        $scm = new shopCustomerModel();
        $scm->updateFromNewOrder($order['contact_id'], $order_id);
        $contact->addToCategory('shop');

        // save items
        $items_model = new shopOrderItemsModel();
        $parent_id = null;
        $currency = wa()->getConfig()->getCurrency(false);
        foreach ($data['items'] as $item) {
            if ($currency != $item['currency']) {
                $item['price'] = shop_currency($item['price'], $item['currency'], null, false);
            }
            $item['order_id'] = $order_id;
            if ($item['type'] == 'product') {
                $parent_id = $items_model->insert($item);
            } elseif ($item['type'] == 'service') {
                $item['parent_id'] = $parent_id;
                $items_model->insert($item);
            }
        }

        // save params
        if (!empty($data['params'])) {
            $params_model = new shopOrderParamsModel();
            $params_model->set($order_id, $data['params']);
        }

        return array(
            'order_id' => $order_id,
            'text' => isset($data['comment']) ? $data['comment'] : '',
            'contact_id' => wa()->getEnv() == 'frontend' ? $contact->getId() : wa()->getUser()->getId()
        );
    }

    public function postExecute($order_id = null, $result = null)
    {
        $order_id = $result['order_id'];

        $data = is_array($result) ? $result : array();
        $data['order_id'] = $order_id;
        $data['action_id'] = $this->getId();

        $data['before_state_id'] = '';
        $data['after_state_id'] = 'new';

        $order_log_model = new shopOrderLogModel();
        $order_log_model->add($data);

        return $order_id;
    }
}