<?php

class shopWorkflowRestoreAction extends shopWorkflowAction
{
    public function execute($oder_id = null)
    {
        $log_model = new shopOrderLogModel();
        $this->state_id = $log_model->getPreviousState($oder_id);

        return true;
    }

    public function postExecute($order_id = null, $result = null) {
        parent::postExecute($order_id, $result);

        if ($this->state_id != 'new' && $order_id != null) {
            $order_model = new shopOrderModel();
            $order_model->reduceProductsFromStocks($order_id);
        }
    }
}