<?php

class shopWorkflowEditAction extends shopWorkflowAction
{
    public function execute($data = null)
    {
        $order_model = new shopOrderModel();
        $order_model->save($data, $data['id']);
        return true;
    }

    public function postExecute($order = null, $result = null)
    {
        $order_id = $order['id'];
        return parent::postExecute($order_id, $result);
    }

    public function getButton()
    {
        return '<a href="#" class="s-edit-order"><i class="icon16 edit"></i>'.$this->getName().'</a>';
    }

}