<?php

class shopWorkflowDeleteAction extends shopWorkflowAction
{
    public function postExecute($order_id = null, $result = null) {
        $data = parent::postExecute($order_id, $result);
        if ($order_id != null && $data['before_state_id'] != 'new') {
            $order_model = new shopOrderModel();
            $order_model->returnProductsToStocks($order_id);
        }
        return $data;
    }
}