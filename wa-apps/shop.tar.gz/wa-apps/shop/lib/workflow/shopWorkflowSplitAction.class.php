<?php

class shopWorkflowSplitAction extends shopWorkflowAction
{
    public function execute($params = null)
    {

    }
}