<?php

class shopWorkflowProcessAction extends shopWorkflowAction
{
    public function postExecute($order_id = null, $result = null) {
        parent::postExecute($order_id, $result);
        if ($order_id != null) {
            $order_model = new shopOrderModel();
            $order_model->reduceProductsFromStocks($order_id);
        }
    }
}
