(function($) {

    var default_error_handler = function(r) {
        if (console) {
            if (r && r.errors) {
                console.error(r.errors);
            } else if (r && r.responseText) {
                console.error(r.responseText);
            } else if (r) {
                console.error(r);
            } else {
                console.error('Error on query');
            }
        }
    };

    $.shop = {
        options : {
            'debug' : true
        },
        time : {
            start : new Date(),
            /**
             * @return int
             */
            interval : function(relative) {
                var d = new Date();
                return (parseFloat(d - this.start) / 1000.0 - (parseFloat(relative) || 0)).toFixed(3);
            }
        },
        init : function(options) {
            this.options = $.extend(this.options, options || {});

            if (options.menu_floating) {
                var main_menu = $('#mainmenu');
                var top_offset = $('#wa-app').offset().top;
                var scroll_handler = function() {
                    if ($(this).scrollTop() > top_offset) {
                        main_menu.addClass('s-fixed');
                    } else {
                        main_menu.removeClass('s-fixed');
                    }
                };
                var recalc = function() {
                    top_offset = $('#wa-app').offset().top;
                    scroll_handler();
                };

                $(window).scroll(scroll_handler).resize(recalc);
                $('#wa-moreapps').click(function() {
                    setTimeout(function() {
                        recalc();
                    });
                });
            }
        },

        setTitle: function(title) {
            document.title = title;
        },

        /**
         * @param {Array} args
         * @param {object} scope
         * @param {String} name
         * @return {'name':{String},'params':[]}
         */
        getMethod : function(args, scope, name) {
            var chunk, callable;
            var method = {
                'name' : false,
                'params' : []
            };
            if (args.length) {
                $.shop.trace('$.getMethod', args);
                name = name || args.shift();
                while (chunk = args.shift()) {
                    name += chunk.substr(0, 1).toUpperCase() + chunk.substr(1);
                    callable = (typeof(scope[name]) == 'function');
                    $.shop.trace('$.getMethod try', [name, callable, args]);
                    if (callable === true) {
                        method.name = name;
                        method.params = args.slice(0);
                    }
                }
            }
            return method;
        },
        /**
         * Debug trace helper
         *
         * @param String message
         * @param {} data
         */
        trace : function(message, data) {
            var timestamp = null;
            if (this.options.debug && console) {
                timestamp = this.time.interval();
                console.log(timestamp + ' ' + message, data);
            }
            return timestamp;
        },

        /**
         * Handler error messages
         *
         * @param String message
         * @param {} data
         */
        error : function(message, data) {
            if (console) {
                console.error(message, data);
            }
        },

        jsonPost : function(url, data, success, error) {
            if (typeof data === 'function') {
                success = data;
                error = success;
            }
            var xhr = $.post(url, data, function(r) {
                if (r.status != 'ok') {
                    if (typeof error === 'function') {
                        if (error(r) !== false) {
                            default_error_handler(r);
                        }
                    } else {
                        default_error_handler(r);
                    }
                    return;
                }
                if (typeof success === 'function') {
                    success(r);
                }
            }, 'json');
            if (typeof error === 'function') {
                xhr.error(function(r) {
                    if (error(r) !== false) {
                        default_error_handler(r);
                    }
                });
            } else {
                xhr.error(default_error_handler);
            }
        },

        getJSON : function(url, data, success, error) {
            if (typeof data !== 'object') {
                success = data;
                error = success;
            }
            var xhr = $.ajax({
                url : url,
                dataType : 'json',
                data : data,
                success : function(r) {
                    if (r.status != 'ok') {
                        if (typeof error === 'function') {
                            if (error(r) !== false) {
                                default_error_handler(r);
                            }
                        } else {
                            default_error_handler(r);
                        }
                        return;
                    }
                    if (typeof success === 'function') {
                        success(r);
                    }
                }
            });
            if (typeof error === 'function') {
                xhr.error(function(r) {
                    if (error(r) !== false) {
                        default_error_handler(r);
                    }
                });
            } else {
                xhr.error(default_error_handler);
            }
        },

        getStockIndicator : function(count) {
            if (count !== null && count <= 0) {
                return 'status-red';
            } else if (count == 1) {
                return 'status-yellow';
            } else {
                return 'status-green';
            }
        },
        helper : {
            /**
             * @param {String} params
             * @return {object}
             */
            parseParams : function(params) {
                if (!params) {
                    return {};
                }
                var p = params.split('&');
                var result = {};
                for (var i = 0; i < p.length; i++) {
                    var t = p[i].split('=');
                    result[t[0]] = t.length > 1 ? t[1] : '';
                }
                return result;
            },
            /**
             * Number of items in key-value object
             * @param {Object}
             * @return Number
             */
            size: function(obj) {
                var counter = 0;
                for (var k in obj) {
                    if (obj.hasOwnProperty(k)) {
                        counter += 1;
                    }
                }
                return counter;
            }
        }
    };
})(jQuery);;
$.storage = new $.store();