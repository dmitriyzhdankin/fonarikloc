$.order = {

    /**
     * {Number}
     */
    id: 0,

    /**
     * {Number}
     */
    contact_id: null,

    /**
     * On/off edit mode
     * {Boolen}
     */
    edit_mode_on: false,

    /**
     * Jquery object related to order info container
     * {Object|null}
     */
    container: null,

    /**
     * {Object}
     * */
    options: {},

    init: function(options) {
        this.options = options || {};
        if (options.order) {
            this.id = parseInt(options.order.id, 10) || 0;
            this.contact_id = parseInt(options.order.contact_id, 10) || null;
        }
        this.container = $('#s-order');
        if (!this.container.length) {
            this.container = $('#s-content');
        }

        if (options.dependencies) {
            if (options.tmpls && options.dependencies.order_edit) {
                options.dependencies.order_edit.tmpls = options.tmpls;
            }
            this.initDependencies(options.dependencies);
        }
        if (options.add) {
            this.initAddView(options.add);
        } else {
            this.initView();
        }

        // workflow
        // action buttons click handler
        $('.wf-action').click(function() {
            var self = $(this);
            self.after('<i class="icon16 loading"></i>');
            $.post('?module=workflow&action=prepare', {action_id: self.data('action-id'), id: $.order.id}, function(response) {
                self.parent().find('.loading').remove();
                $('.workflow-actions').hide();
                $('#workflow-content').empty().html(response).show();
            });
            return false;
        });
    },

    initView: function() {
        //$.order_list.resize();

        this.container.off('click', '.s-edit-order').on('click', '.s-edit-order', function() {
            $.order.editAction();
            return false;
        });

        this.container.find('h1 .back.read-mode').click(function() {
            if ($.order.editMode(false)) {
                if ($.order.options.view == 'table') {
                    $.orders.dispatch($(this).attr('href'));
                } else {
                    $.order_list.dispatch('id='+$.order.id, true);
                }
            }
            return false;
        });

        if (this.options.order) {
            $.order_list.updateListItem(this.options.order, this.id);
        }
    },

    editAction: function() {
        $.when(
            $.getJSON('?module=order&action=getItems&id='+$.order.id),
            $.get('?action=contactForm&id='+$.order.contact_id)
        ).done(function(r1, r2) {
            if ((r1[0].status != 'ok' || !r2[0])) {
                if (console) {
                    console.log('Error occured!', r1, r2);
                }
                return;
            }
            var items = r1[0].data;
            var form_html  = r2[0];
            if (items.length) {
                $.order.editMode();

                var customer_content = $('#s-order-customer-edit').find('.field-group:first');
                var items_content = $('#s-order-items-edit').find('tbody:first');
                var tmpl_name = $.order.options.tmpls.product;

                customer_content.html(form_html);
                items_content.html('');
                for (var i = 0, n = items.length; i < n; i += 1) {
                    items_content.append(tmpl(tmpl_name, {
                        data: items[i], options: { price_edit: true, index: i }
                    }));
                    items_content.find('tr:last').find('.s-orders-services input[type=checkbox]:not(:checked)').each(function() {
                        var parent = $(this).parent();
                        parent.find('.s-orders-service-variant').trigger('change');
                    });
                }
                $('#s-customer-id').val($.order.contact_id);
                $.order_edit.update_total();
                $.order_edit.initCustomerForm('edit');
            }
        });
    },

    editSubmit: function() {
        var self = $(this);
        $.shop.jsonPost(self.attr('action'), self.serialize(),
            function(r) {
                if (r.data.order.id) {
                    $.order.editMode(false);
                    $.order_list.updateListItem(r.data.order, r.data.order.id);
                    $.order_list.dispatch('id='+r.data.order.id, true);
                }
            },
            function(r) {
                if (r && r.errors && !$.isEmptyObject(r.errors)) {
                    $.order_edit.showValidateErrors(r.errors);
                    return false;
                }
            }
        );
    },

    addSubmit: function() {
        var self = $(this);
        $.shop.jsonPost(self.attr('action'), self.serialize(),
            function(r) {
                if ($.order.editMode(false, true)) {
                    location.href = '#/orders/state_id=new&view=split&id='+r.data.order.id+'/';

                }
            },
            function(r) {
                if (r && r.errors && !$.isEmptyObject(r.errors)) {
                    $.order_edit.showValidateErrors(r.errors);
                    return false;
                }
            }
        );
    },

    editMode: function (on, add, done) {
        on = typeof on === 'undefined' ? true : on;   // on/off
        add = typeof add === 'undefined' ? false: add;
        var duration = this.options.duration || 200;
        var view = this.options.view;
        var deferreds = [];

        if (!this.edit_mode_on && on) { // make editable
            deferreds.push(
                $('#s-sidebar').animate({
                    'width': 0
                }, duration, function() {
                    $(this).hide();
                })
            );
            $('.s-level2').hide();
            deferreds.push(
                $('#maincontent').animate({
                    'margin-top' : 45
                }, duration)
            );
            if (view != 'table' && !add) {
                deferreds.push(
                    $('#s-content').animate({
                        'margin-left': 0
                    }, duration)
                );
            }
            deferreds.push(
                $('#s-orders').animate({
                    'width': 0
                }, duration, function() {
                    $(this).hide();
                })
            );
            deferreds.push(
                this.container.animate({
                    'margin-left': 0
                }, duration).find('>div:first').removeClass('double-padded, bordered-left').
                    find('h1 .back.order-list').hide().end().
                    find('h1 .back.read-mode').show()
            );
            this.edit_mode_on = true;
            $('.s-order-readable').hide();
            $('.s-order-editable').show();

            if (typeof done === 'function') {
                $.when(deferreds).done(done);
            }

            return true;
        } else if (this.edit_mode_on && !on) {  // make readable
            deferreds.push(
                this.container.animate({
                    'margin-left': view != 'table' && !add ? 300 : 200
                }, duration).find('>div:first').addClass('double-padded, bordered-left').
                   find('h1 .back.order-list').show().end().
                   find('h1 .back.read-mode').hide()
            );
            deferreds.push(
                $('#s-orders').animate({
                    'width': 300
                }, duration).show()
            );
            if (view != 'table' && !add) {
                deferreds.push(
                    $('#s-content').animate({
                        'margin-left': 200
                    }, duration)
                );
            }
            deferreds.push(
                $('#maincontent').animate({
                    'margin-top' : 90
                }, duration)
            );
            $('.s-level2').show();
            deferreds.push(
                $('#s-sidebar').animate({
                    'width': 200
                }, duration).show()
            );
            this.edit_mode_on = false;
            $('.s-order-editable').hide();
            $('.s-order-readable').show();

            if (typeof done === 'function') {
                $.when(deferreds).done(done);
            }

            return true;
        }
        return false;
    },

    initDependencies: function(options) {
        for (var n in options) {
            if (options.hasOwnProperty(n)) {
                if (!$[n]) {
                    var msg = "Can't find " + n;
                    if (console) {
                        console.log(msg);
                    } else {
                        throw msg;
                    }
                    return;
                }
                if (options[n] === true) {
                    options[n] = {};
                }
                $[n].init(options[n]);
            }
        }
    },

    initAddView: function(options) {
        $.order.editMode(true, true);
        var add_order_input = $("#orders-add-autocomplete");
        add_order_input.autocomplete({
            source: '?action=autocomplete&with_counts=1',
            minLength: 3,
            delay: 300,
            select: function(event, ui) {
                $.getJSON('?module=orders&action=getProduct&product_id='+ui.item.id, function(r) {
                    var table = $('#order-items');
                    var order_items_tr = table.find('.s-order-item');
                    var product = r.data;
                    var tmpl_name = $.order.options.tmpls.product;
                    product.skus[product.sku_id].checked = true;
                    var add_row = $('#s-orders-add-row');
                    add_row.before(tmpl(tmpl_name, {
                        data: r.data, options: { index: order_items_tr.length }
                    }));
                    add_row.prev().find('.s-orders-services .s-orders-service-variant').trigger('change');
                    $.order_edit.update_total();
                });
                add_order_input.val('');
                return false;
            }
        });

        $.order_edit.initCustomerForm(options);

        this.container.find('.back').click(function() {
            if ($.order.editMode(false, true)) {
                history.back();
            }
            return false;
        });
    },

    reload: function() {
        if (this.edit_mode_on) {
            this.editMode(false);
        }
        if (!$.order_list || ($.order_list && $.order_list.options && $.order_list.options.view == 'table')) {
            $.orders.dispatch();
        } else if ($.order_list) {
            $.order_list.dispatch('id='+$.order.id, true);
        }
    }
};