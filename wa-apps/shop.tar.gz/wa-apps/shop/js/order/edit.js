$.order_edit = {

    /**
     */
    container: null,
    form: null,

    customer_fields: null,
    customer_inputs: null,

    tmpls: {
        product:  'template-order',
        services: 'template-order-services'
    },

    /**
     * {Object}
     * */
    options: {},

    init: function(options) {
        this.options  = options;
        this.container = typeof options.container === 'string' ? $(options.container) : options.container;
        this.form = typeof options.form === 'string' ? $(options.form) : options.form;
        this.onSubmit = typeof options.onSubmit === 'function' ? options.onSubmit : null;

        this.customer_fields = $('#s-order-edit-customer');
        this.customer_inputs = this.customer_fields.find(':input');

        if (options.tmpls) {
            $.extend(this.tmpls, options.tmpls);
        }

        var price_edit = options.price_edit || false;

        this.container.off('change', '.s-orders-skus input[type=radio]').on('change', '.s-orders-skus input[type=radio]',
            function() {
                var tr = $(this).parents('tr:first');
                var sku_id = this.value;
                var product_id = tr.attr('data-product-id');
                var index = tr.attr('data-index');
                var url = '?module=orders&action=getProduct&product_id='+product_id+'&sku_id='+sku_id;
                var tmpl_name = $.order_edit.tmpls.services;
                $.getJSON(url, function(r) {
                    tr.find('.s-orders-services').replaceWith(
                        tmpl(tmpl_name, {
                            services: r.data.services,
                            product_id: product_id,
                            options: { price_edit: price_edit, index: index }
                        })
                    );
                    tr.find('.s-orders-services .s-orders-service-variant').trigger('change');
                    var quantity = tr.find('.s-orders-quantity').val();
                    if (quantity > 1) {
                        tr.find('.s-orders-quantity-service').show();
                    } else {
                        tr.find('.s-orders-quantity-service').hide();
                    }
                    tr.find('.s-orders-product-price').
                        find('span').text(r.data.price_str).end().
                        find('input').val(r.data.price).trigger('change');
                });
            }
        );

        this.container.off('change', '.s-orders-service-variant').on('change', '.s-orders-service-variant',
            function() {
                var self = $(this);
                var option = self.find('option:selected');
                var li = self.parents('li:first');
                li.find('.s-orders-service-price').val(option.attr('data-price'));
            }
        );

        this.container.off('click', '.s-order-item-delete').on('click', '.s-order-item-delete', function() {
            $(this).parents('tr:first').replaceWith(
                $.order_edit.container.find('.template-deleted').clone().show()
            );
            return false;
        });

        // calculations
        this.container.off('change', '.s-orders-services input').on('change', '.s-orders-services input', $.order_edit.update_total);
        this.container.off('change', '.s-orders-product-price input').on('change', '.s-orders-product-price input', $.order_edit.update_total);
        this.container.off('change', '.s-orders-services .s-orders-service-variant').on('change', '.s-orders-services .s-orders-service-variant', $.order_edit.update_total);

        $("#shipping_methods").change(function () {
            var rate = $(this).children(':selected').data('rate');
            $("#shipping-rate").val(rate);
            $.order_edit.update_total();
        }).change();

        $("#discount,#shipping-rate").change(function () {
            $.order_edit.update_total();
        });

        var validate = function(item) {
            var max_value = parseInt(item.attr('data-max-value'), 10);
            var val = parseInt(item.val(), 10);
            if (isNaN(max_value)) {
                return true;
            } else {
                if (isNaN(val)) {
                    return false;
                } else {
                    return val <= max_value;
                }
            }
        };

        this.container.off('keydown', '.s-orders-quantity').on('keydown', '.s-orders-quantity', function() {
            var self = $(this);
            var timer_id = self.data('timer_id');
            if (timer_id) {
                clearTimeout(timer_id);
            }
            self.data('timer_id', setTimeout(function() {
                var tr = self.parents('tr:first');
                if (self.val() > 1) {
                    tr.find('.s-orders-quantity-service').show();
                } else {
                    tr.find('.s-orders-quantity-service').hide();
                }
                if (!validate(self)) {
                    self.addClass('error');
                } else {
                    $.order_edit.update_total();
                    self.removeClass('error');
                }
            }, 450));
        });

        if (this.form && this.form.length) {
            this.form.unbind('sumbit').bind('submit', function() {
                if (!$.order_edit.container.find('.error').length) {
                    if (typeof $.order_edit.onSubmit === 'function') {
                        $.order_edit.onSubmit.call(this);
                    }
                }
                return false;
            });
        }

    },

    update_total: function () {
        var container = $.order_edit.container;
        if (!container.find('.s-order-item').length) {
            $("#subtotal").text(0);
            $("#total").text(0);
            return;
        }
        var subtotal = 0;
        container.find('.s-order-item').each(function () {
            var tr = $(this);
            var price = parseFloat(tr.find('.s-orders-product-price input').val());
            var quantity = parseFloat(tr.find('input.s-orders-quantity').val());
            subtotal += price * quantity;
            if (tr.find('.s-orders-services').length) {
                tr.find('.s-orders-services input:checkbox:checked').each(function () {
                    var li = $(this).closest('li');
                    price = parseFloat(li.find('input.s-orders-service-price').val());
                    quantity = parseFloat(li.find('input.s-orders-quantity-service').val());
                    subtotal += price * quantity;
                });
            }
        });
        $("#subtotal").text(subtotal);
        var shipping = parseFloat($("#shipping-rate").val().replace(',', '.')) || 0;
        var discount = parseFloat($("#discount").val() || 0);
        var total = subtotal + shipping - discount;
        $("#total").text(total);
    },

    showValidateErrors: function(validate_errors) {
        if (validate_errors.customer) {
            var errors = validate_errors.customer;
            $.order_edit.customer_fields.find('.field-group:first').html(errors.html);
            delete errors.html;
            for (var name in errors) {
                $.order_edit.customer_fields.find('.s-error-customer-' + name).each(function() {
                    var item = $(this);
                    if (this.tagName == 'EM') {
                        item.text(errors[name]);
                    } else {
                        item.addClass('error');
                    }
                });
            }
        }
        if (validate_errors.order) {
            $('.s-order-errors').html(validate_errors.order);
        }
    },

    bindValidateErrorPlaceholders: function() {
        // firstname, middlename, lastname mark as having one name of error
        var names = ['firstname', 'middlename', 'lastname'];
        for (var i = 0, n = names.length; i < n; i += 1) {
            var name = names[i];
            $.order_edit.customer_inputs.filter('[name='+$.order_edit.inputName(name)+']').addClass('s-error-customer-name');
        }
        $.order_edit.customer_fields.find('.s-error-customer-name:last').after('<em class="errormsg s-error-customer-name"></em>');
    },

    initCustomerForm: function(options, editing_mode) {
        if (typeof options === 'string') {
            editing_mode = options;
        }
        editing_mode = typeof editing_mode === 'undefined' ? 'add' : editing_mode;

        // editing mode (no autocomplete)
        if (editing_mode !== 'add') {
            $.order_edit.bindValidateErrorPlaceholders();
            return;
        }

        // adding mode (with autocomplete);
        var autocompete_input = $("#customer-autocomplete");
        var search_activate_button = $('#customer-search-activate');

        // utility-functions
        var disable = function(disabled) {
            disabled = typeof disabled === 'undefined' ? true : disabled;
            $('#s-customer-id').attr('disabled', disabled);
            if (disabled) {
                $.order_edit.customer_inputs.addClass('gray disabled');
                $.order_edit.customer_fields.addClass('gray');
            } else {
                $.order_edit.customer_inputs.removeClass('gray disabled');
                $.order_edit.customer_fields.removeClass('gray');
            }
        };
        var activate = function(activate) {
            activate = typeof activate === 'undefined' ? true : activate;
            if (activate) {
                disable(false);
                autocompete_input.val('').hide(200);
                search_activate_button.show();
            } else {
                disable();
                $.order_edit.customer_inputs.val('');
                autocompete_input.val('').show();
                search_activate_button.hide();
            }
        };
        var testPhone = function(str) {
            return parseInt(str, 10) || str.substr(0, 1) == '+' || str.indexOf('(') !== -1;
        };

        $.order_edit.bindValidateErrorPlaceholders();

        // mark whole form as disabled (disactivated) to user want use autocomplete
        activate(false);
        $.order_edit.customer_fields.off('focus', ':input').
            on('focus', ':input', function() {
                disable(false);
                return false;
            });
        search_activate_button.click(function() {
            activate(false);
            return false;
        });

        // autocomplete
        autocompete_input.autocomplete({
            source: function(request, response) {
                $.getJSON(options.customer_autocomplete, request, function(r) {
                    (r = r || []).push({
                        label: options.strs.new_customer,
                        value: 0
                    });
                    response(r);
                });
            },
            minLength: 3,
            select: function(event, ui) {
                var value = autocompete_input.val();
                var item = ui.item;
                if (item.value) {
                    $.get('?action=contactForm&id='+item.value, function(html) {
                        $.order_edit.customer_fields.find('.field-group:first').html(html);
                        $.order_edit.customer_inputs = $.order_edit.customer_fields.find(':input');
                        $('#s-customer-id').val(item.value);
                        activate();
                    });
                } else {
                    value = value.replace(/^\s*/, '').replace(/\s*$/, '');
                    $.order_edit.customer_inputs.filter('[name='+
                        $.order_edit.inputName(testPhone(value) ? 'phone' : 'email')+
                    ']').val(value);
                    $('#s-customer-id').val(0);
                    activate();
                }
                return false;
            },
            delay: 300
        });

        $('#order-add-form').submit(function() {
            disable(false);
        });
    },

    getWarnClass: function(count) {
        if (count !== null && count <= 0) {
            return 's-stock-warning-none';
        } else if (count == 1) {
            return 's-stock-warning-low';
        } else {
            return '';
        }
    },

    inputName: function(name) {
        return 'customer\\['+name+'\\]' + (['email', 'phone'].indexOf(name) !== -1 ? '\\[value\\]' : '');
    }
};